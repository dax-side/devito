# Rollout analysis: 112 agent runs over 4 tasks

Data: `runs.csv`, one row per run (verdict, grader category, failing tests, patch size), rebuilt by `harvest.py`.
Batches were graded on the tests of their time, so a task's rate mixes test versions.

| Task | Pass | Rate | Failed runs: share of tests failing (median) | What decided most fails |
|---|---|---|---|---|
| curvilinear | 1/16 | 6% | 2% | One test family: tensor divergence convergence (9 of 15 fails) |
| max_stable_dt | 12/53 | 22% | 3% | A few behaviours: backward scheme limit, frozen fields, 4-D grids |
| sparse_interp | 8/26 | 30% | 1% | One test: shifted row uses the loop step position (10 of 18 fails) |
| digest | 12/17 | 70% (before tightening) | — | Quoting, default MD5, later empty algorithm / spaces |

## Findings
1. **Failures are near-misses.** A failing run usually fails 1-3% of the tests. Agents build almost the whole feature; one behaviour decides pass or fail.
2. **One or two "traps" set the pass rate.** In each task a single behaviour accounts for most fails. Pass rate is roughly the share of agents that get the trap(s) right, multiplied together when there are several.
3. **Effort does not predict passing.** Passers and failers write the same amount of code (median production lines: 541 vs 527, 199 vs 179, 465 vs 408).
4. **Fails are agent coding errors, not environment.** 73 of 79 fails are "coding"; the rest are integration or test mismatch.
5. **Too-hard traps overshoot.** A numerically hard trap (curvilinear convergence) gave 6%; a subtle-but-stated edge (sparse shift, empty algorithm) lands at 20-40%.

## Rules for the next task
- Design 1-2 deliberate traps up front. Each must be **stated** in the description, since TQ and the FP panel reject unstated ones, but easy to get wrong by default: absent vs empty, an off-by-one position, a default value, a wiring path (retry/poll).
- Before the first rollout, write 3-4 alternative implementations or probes, and estimate each trap's hit rate. Target product = 20-30%.
- Avoid traps that depend on numerical tolerance (curvilinear); they read as unfair or land too hard.
- After the first batch, read only the failing-test column: if one test explains most fails, that trap is doing the work. Tighten or loosen there instead of adding scope.
