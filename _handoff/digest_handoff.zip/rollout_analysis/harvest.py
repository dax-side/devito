import json, os, re, glob, csv, xml.etree.ElementTree as E
S='/tmp/claude-0/-home-user-devito/12ecaab4-f93a-5047-9f9b-38107e07f883/scratchpad'
rows=[]
for ev in sorted(glob.glob(S+'/**/eval-result.json', recursive=True)):
    d=os.path.dirname(ev); batch=os.path.relpath(os.path.dirname(d),S); run=os.path.basename(d)
    r=json.load(open(ev)); det=r.get('details',{}) or {}
    patch=os.path.join(d,'solution-patch.patch'); files=[]; prod=tests=0; f=None
    if os.path.exists(patch):
        for l in open(patch,errors='ignore'):
            if l.startswith('+++ '): f=l[6:].strip(); files.append(f); continue
            if f and l.startswith('+') and not l.startswith('+++'):
                t=l[1:].strip()
                if not t or t.startswith(('#','//')): continue
                if re.search(r'(_test\.go|test_.*\.py|/tests?/|\.test\.)',f): tests+=1
                elif f.endswith(('.go','.py','.js','.ts')): prod+=1
    blob=' '.join(files)
    task=('digest' if 'digest' in blob or 'httpx' in blob else 'tabulate' if 'tabulate' in blob
          else 'curvilinear' if 'coordinates.py' in blob or batch.startswith('cv')
          else 'max_stable_dt' if 'stability' in blob
          else 'sparse_interp' if 'interpolators' in blob or 'sparse.py' in blob else 'other')
    nt=nf=0; fails=[]
    jn=os.path.join(d,'junit-new.xml')
    if os.path.exists(jn):
        try:
            for tc in E.parse(jn).getroot().iter('testcase'):
                nt+=1
                if tc.find('failure') is not None or tc.find('error') is not None: nf+=1; fails.append(tc.get('name'))
        except Exception: pass
    msgs=0; tj=os.path.join(d,'trajectory.json')
    if os.path.exists(tj):
        try:
            t=json.load(open(tj)); msgs=len(t) if isinstance(t,list) else len(t.get('messages',t.get('steps',[])) or [])
        except Exception: pass
    ea=r.get('environment_assessment',{}) or {}
    rows.append(dict(task=task,batch=batch,run=run,kind=det.get('kind'),
        category=det.get('primary_category',''),secondary=';'.join(det.get('secondary_factors',[]) or []) if isinstance(det.get('secondary_factors'),list) else det.get('secondary_factors',''),
        tests_total=nt,tests_failed=nf,failing=';'.join(fails[:15]),prod_lines=prod,test_lines=tests,files=len(files),messages=msgs,
        blocker=ea.get('blocker_type',''),quick=(r.get('quick_failure_summary') or '')[:300],
        reason=(det.get('reasoning') or r.get('summary') or '')[:600]))
out='/mnt/user-data/outputs/rollout_analysis/runs.csv'
with open(out,'w',newline='') as fh:
    w=csv.DictWriter(fh,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print(len(rows),'runs ->',out)
from collections import Counter
print(Counter((r['task'],r['kind']) for r in rows))
