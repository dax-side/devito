package fpprobe_test

import (
	"context"
	"net/http"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/unkn0wn-root/resterm/headless"
)

func TestProbe3(t *testing.T) {
	t.Run("empty_opaque_sent", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth", opaque=""`)
		run(t, s, digestAuth(user, pass), "GET", "/", "")
		if _, ok := answered(t, s, "MD5", "r")["opaque"]; !ok {
			t.Fatal("opaque not sent")
		}
	})
	t.Run("empty_algorithm_not_answered", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth", algorithm=""`)
		if got := run(t, s, digestAuth(user, pass), "GET", "/", ""); got != 401 || len(s.recorded()) != 1 {
			t.Fatalf("status %d hits %d", got, len(s.recorded()))
		}
	})
	t.Run("timeout_covers_both", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth"`)
		inner := s.srv.Config.Handler
		s.srv.Config.Handler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			time.Sleep(700 * time.Millisecond)
			inner.ServeHTTP(w, r)
		})
		f := filepath.Join(t.TempDir(), "r.http")
		_ = os.WriteFile(f, []byte("# @name r\n"+digestAuth(user, pass)+"# @timeout 1s\nGET "+s.srv.URL+"/\n"), 0o600)
		rep, err := headless.Run(context.Background(), headless.Options{Source: headless.Source{Path: f}})
		if err == nil && len(rep.Results) == 1 && rep.Results[0].HTTP != nil && rep.Results[0].HTTP.StatusCode == 200 {
			t.Fatal("got 200 after 1.4s with @timeout 1s")
		}
	})
}
