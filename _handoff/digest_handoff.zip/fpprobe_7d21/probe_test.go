package fpprobe_test

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

// Probes for stated behaviour the hidden tests do not pin.
func TestProbe(t *testing.T) {
	t.Run("empty_opaque_passed_along", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth", opaque=""`)
		run(t, s, digestAuth(user, pass), "GET", "/", "")
		if v, ok := answered(t, s, "MD5", "r")["opaque"]; !ok || v != "" {
			t.Fatalf("opaque = %q present=%v, want empty and present", v, ok)
		}
	})
	t.Run("auth_int_body_resent", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth-int"`)
		run(t, s, digestAuth(user, pass), "POST", "/x", "Content-Type: text/plain\n\nabc body\n")
		hits := s.recorded()
		answered(t, s, "MD5", "r")
		if hits[0].body == "" || hits[1].body != hits[0].body {
			t.Fatalf("bodies %q then %q", hits[0].body, hits[1].body)
		}
	})
	t.Run("password_with_spaces", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth"`)
		if got := run(t, s, "# @auth digest-auth Mufasa Circle Of Life\n", "GET", "/", ""); got != 200 {
			hits := s.recorded()
			t.Fatalf("status %d hits %d", got, len(hits))
		}
	})
	t.Run("variables", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth"`)
		if got := run(t, s, "@u = Mufasa\n@p = CircleOfLife\n\n# @auth digest-auth {{u}} {{p}}\n", "GET", "/", ""); got != 200 {
			t.Fatalf("status %d", got)
		}
		answered(t, s, "MD5", "r")
	})
	t.Run("lowercase_authorization_header", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth"`)
		s.challengeNonDigest = true
		got := run(t, s, digestAuth(user, pass), "GET", "/", "authorization: Bearer x\n")
		if h := s.recorded(); got != 401 || len(h) != 1 {
			t.Fatalf("status %d hits %d", got, len(h))
		}
	})
	t.Run("uri_keeps_encoded_query", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth"`)
		run(t, s, digestAuth(user, pass), "GET", "/a%20b/c?q=x%20y&z=1", "")
		answered(t, s, "MD5", "r")
	})
	t.Run("three_in_one_header", func(t *testing.T) {
		s := newServer(t, `Basic realm="x", Digest nonce="m", qop="auth-int, auth", Digest nonce="s", algorithm=SHA-256-sess, qop="auth-int"`)
		run(t, s, digestAuth(user, pass), "POST", "/", "Content-Type: text/plain\n\nz\n")
		if p := answered(t, s, "SHA-256-sess", ""); p["nonce"] != "s" || p["qop"] != "auth-int" {
			t.Fatalf("nonce/qop %q/%q", p["nonce"], p["qop"])
		}
	})
	t.Run("https_http_https_not_answered", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth"`)
		final := httptest.NewTLSServer(http.HandlerFunc(s.handle))
		t.Cleanup(final.Close)
		mid := redirector(t, final.URL+"/end")
		start := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			http.Redirect(w, r, mid.URL+"/mid", http.StatusFound)
		}))
		t.Cleanup(start.Close)
		forward := "# @setting forward-credentials-on-redirect true\n# @setting insecure true\n"
		if got := runURL(t, forward, digestAuth(user, pass), start.URL+"/start"); got != 401 {
			t.Fatalf("status %d hits %+v", got, s.recorded())
		}
	})
	t.Run("second_hop_401_answered_same_origin_after_answer", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth"`)
		s.okStatus = http.StatusCreated
		if got := run(t, s, digestAuth(user, pass), "PUT", "/k", "Content-Type: text/plain\n\nv\n"); got != 201 {
			t.Fatalf("status %d", got)
		}
	})
}
