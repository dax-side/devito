package fpprobe_test

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestProbe2(t *testing.T) {
	ok := func(t *testing.T, s *server, method, path, extra, alg, realm string) map[string]string {
		t.Helper()
		if got := run(t, s, digestAuth(user, pass), method, path, extra); got != 200 {
			t.Fatalf("status %d", got)
		}
		return answered(t, s, alg, realm)
	}
	none := func(t *testing.T, s *server, code int) {
		t.Helper()
		if got := run(t, s, digestAuth(user, pass), "GET", "/", ""); got != code {
			t.Fatalf("status %d, want %d", got, code)
		}
		if n := len(s.recorded()); n != 1 {
			t.Fatalf("hits %d, want 1", n)
		}
	}
	// Algorithms are case insensitive.
	t.Run("upper_sha256_sess", func(t *testing.T) {
		ok(t, newServer(t, `Digest realm="r", nonce="n", qop="auth", algorithm=SHA-256-SESS`), "GET", "/", "", "SHA-256-sess", "r")
	})
	t.Run("lower_md5_sess", func(t *testing.T) {
		ok(t, newServer(t, `Digest realm="r", nonce="n", qop="auth", algorithm=md5-sess`), "GET", "/", "", "MD5-sess", "r")
	})
	t.Run("quoted_algorithm", func(t *testing.T) {
		ok(t, newServer(t, `Digest realm="r", nonce="n", qop="auth", algorithm="SHA-256"`), "GET", "/", "", "SHA-256", "r")
	})
	// qop contains auth / only auth-int.
	t.Run("qop_list_spaces", func(t *testing.T) {
		if p := ok(t, newServer(t, `Digest realm="r", nonce="n", qop=" auth-int , auth "`), "GET", "/", "", "MD5", "r"); p["qop"] != "auth" {
			t.Fatalf("qop %q", p["qop"])
		}
	})
	t.Run("qop_unquoted_token", func(t *testing.T) {
		if p := ok(t, newServer(t, `Digest realm="r", nonce="n", qop=auth`), "GET", "/", "", "MD5", "r"); p["qop"] != "auth" {
			t.Fatalf("qop %q", p["qop"])
		}
	})
	t.Run("auth_int_no_body", func(t *testing.T) {
		if p := ok(t, newServer(t, `Digest realm="r", nonce="n", qop="auth-int"`), "GET", "/", "", "MD5", "r"); p["qop"] != "auth-int" {
			t.Fatalf("qop %q", p["qop"])
		}
	})
	t.Run("auth_int_sha256_post", func(t *testing.T) {
		ok(t, newServer(t, `Digest realm="r", nonce="n", qop="auth-int", algorithm=SHA-256`), "POST", "/p?x=1", "Content-Type: text/plain\n\nline1\nline2\n", "SHA-256", "r")
	})
	t.Run("custom_and_auth_int", func(t *testing.T) {
		if p := ok(t, newServer(t, `Digest realm="r", nonce="n", qop="custom, auth-int"`), "GET", "/", "", "MD5", "r"); p["qop"] != "auth-int" {
			t.Fatalf("qop %q", p["qop"])
		}
	})
	// One header, several challenges.
	t.Run("digest_then_basic_one_header", func(t *testing.T) {
		ok(t, newServer(t, `Digest realm="a, b", nonce="d", qop="auth", Basic realm="x"`), "GET", "/", "", "MD5", "a, b")
	})
	t.Run("bearer_token68_then_digest", func(t *testing.T) {
		ok(t, newServer(t, `Bearer abc==, Digest realm="r", nonce="n", qop="auth"`), "GET", "/", "", "MD5", "r")
	})
	t.Run("md5_sess_then_sha256_one_header", func(t *testing.T) {
		if p := ok(t, newServer(t, `Digest realm="r", nonce="m", qop="auth", algorithm=MD5-sess, Digest realm="r", nonce="s", qop="auth", algorithm=SHA-256`), "GET", "/", "", "SHA-256", "r"); p["nonce"] != "s" {
			t.Fatalf("nonce %q", p["nonce"])
		}
	})
	t.Run("sha_unusable_then_md5_one_header", func(t *testing.T) {
		if p := ok(t, newServer(t, `Digest realm="r", nonce="s", algorithm=SHA-256-sess, Digest realm="r", nonce="m", qop="auth"`), "GET", "/", "", "MD5", "r"); p["nonce"] != "m" {
			t.Fatalf("nonce %q", p["nonce"])
		}
	})
	t.Run("basic_header_then_digest_header", func(t *testing.T) {
		ok(t, newServer(t, `Basic realm="x"`, `Digest realm="r", nonce="n", qop="auth"`), "GET", "/", "", "MD5", "r")
	})
	t.Run("unquoted_nonce", func(t *testing.T) {
		if p := ok(t, newServer(t, `Digest realm="r", nonce=abc123, qop="auth"`), "GET", "/", "", "MD5", "r"); p["nonce"] != "abc123" {
			t.Fatalf("nonce %q", p["nonce"])
		}
	})
	t.Run("lowercase_scheme", func(t *testing.T) {
		ok(t, newServer(t, `digest realm="r", nonce="n", qop="auth"`), "GET", "/", "", "MD5", "r")
	})
	t.Run("upper_param_names", func(t *testing.T) {
		ok(t, newServer(t, `Digest REALM="r", NONCE="n", QOP="auth"`), "GET", "/", "", "MD5", "r")
	})
	t.Run("spaces_around_equals", func(t *testing.T) {
		ok(t, newServer(t, `Digest realm = "r" , nonce = "n" , qop = "auth"`), "GET", "/", "", "MD5", "r")
	})
	t.Run("comma_in_opaque_and_nonce", func(t *testing.T) {
		p := ok(t, newServer(t, `Digest realm="r", nonce="a,b", qop="auth", opaque="c, d"`), "GET", "/", "", "MD5", "r")
		if p["nonce"] != "a,b" || p["opaque"] != "c, d" {
			t.Fatalf("nonce/opaque %q/%q", p["nonce"], p["opaque"])
		}
	})
	// uri is path+query requested.
	t.Run("uri_root_only_query", func(t *testing.T) {
		if p := ok(t, newServer(t, `Digest realm="r", nonce="n", qop="auth"`), "GET", "?a=1&b=two", "", "MD5", "r"); p["uri"] != "/?a=1&b=two" {
			t.Fatalf("uri %q", p["uri"])
		}
	})
	t.Run("uri_encoded", func(t *testing.T) {
		ok(t, newServer(t, `Digest realm="r", nonce="n", qop="auth"`), "GET", "/a%20b/c?q=x%20y", "", "MD5", "r")
	})
	// No answer cases.
	t.Run("not_401_407", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth"`)
		s.firstStatus = http.StatusProxyAuthRequired
		none(t, s, 407)
	})
	t.Run("sha512_only", func(t *testing.T) {
		none(t, newServer(t, `Digest realm="r", nonce="n", qop="auth", algorithm=SHA-512`), 401)
	})
	t.Run("qop_auth_conf_only", func(t *testing.T) {
		none(t, newServer(t, `Digest realm="r", nonce="n", qop="auth-conf"`), 401)
	})
	t.Run("lowercase_own_authorization", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth"`)
		s.challengeNonDigest = true
		if got := run(t, s, digestAuth(user, pass), "GET", "/", "authorization: Bearer x\n"); got != 401 || len(s.recorded()) != 1 {
			t.Fatalf("status %d hits %d", got, len(s.recorded()))
		}
	})
	// Redirects.
	t.Run("https_http_https_not_answered", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth"`)
		final := httptest.NewTLSServer(http.HandlerFunc(s.handle))
		t.Cleanup(final.Close)
		mid := redirector(t, final.URL+"/end")
		start := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			http.Redirect(w, r, mid.URL+"/mid", http.StatusFound)
		}))
		t.Cleanup(start.Close)
		forward := "# @setting forward-credentials-on-redirect true\n# @setting insecure true\n"
		if got := runURL(t, forward, digestAuth(user, pass), start.URL+"/start"); got != 401 {
			t.Fatalf("status %d", got)
		}
	})
	t.Run("redirect_307_post_body", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth-int"`)
		mux := http.NewServeMux()
		mux.HandleFunc("/start", func(w http.ResponseWriter, r *http.Request) {
			http.Redirect(w, r, "/landing", http.StatusTemporaryRedirect)
		})
		mux.HandleFunc("/landing", s.handle)
		s.srv.Config.Handler = mux
		if got := run(t, s, digestAuth(user, pass), "POST", "/start", "Content-Type: text/plain\n\nkeep me\n"); got != 200 {
			t.Fatalf("status %d", got)
		}
		hits := s.recorded()
		answered(t, s, "MD5", "r")
		if hits[1].body != hits[0].body || hits[0].body == "" {
			t.Fatalf("bodies %q %q", hits[0].body, hits[1].body)
		}
	})
	// Credentials like basic auth.
	t.Run("variables_creds", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth"`)
		if got := run(t, s, "@u = Mufasa\n@p = CircleOfLife\n\n# @auth digest-auth {{u}} {{p}}\n", "GET", "/", ""); got != 200 {
			t.Fatalf("status %d", got)
		}
		answered(t, s, "MD5", "r")
	})
	t.Run("retry_when_401", func(t *testing.T) {
		s := newServer(t, `Digest realm="r", nonce="n", qop="auth"`)
		s.answerStatuses = []int{http.StatusUnauthorized}
		if got := run(t, s, digestAuth(user, pass)+"# @retry count=1\n# @retry-when response.statusCode == 401\n", "GET", "/", ""); got != 200 {
			t.Fatalf("status %d hits %d", got, len(s.recorded()))
		}
		checkAnswers(t, s, 4)
	})
}
