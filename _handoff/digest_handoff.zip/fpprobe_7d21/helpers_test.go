package fpprobe_test

import (
	"context"
	"crypto/md5"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"hash"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"testing"

	"github.com/unkn0wn-root/resterm/headless"
)

const (
	user = "Mufasa"
	pass = "CircleOfLife"
)

type hit struct {
	method string
	uri    string
	authz  string
	digest string
	body   string
}

// server answers a request without Authorization with the given challenges
// and checks a Digest answer against them. After a correct answer it replies
// with okStatus.
type server struct {
	t          *testing.T
	challenges []string
	okStatus   int
	// firstStatus, when set, answers a request without Authorization with
	// this status and no challenge.
	firstStatus        int
	challengeNonDigest bool
	// answerStatuses, when set, are used in turn for correct answers before
	// okStatus.
	answerStatuses []int
	mu             sync.Mutex
	hits           []hit
	srv            *httptest.Server
}

func newServer(t *testing.T, challenges ...string) *server {
	s := &server{t: t, challenges: challenges, okStatus: http.StatusOK}
	s.srv = httptest.NewServer(http.HandlerFunc(s.handle))
	t.Cleanup(s.srv.Close)
	return s
}

func (s *server) handle(w http.ResponseWriter, r *http.Request) {
	body, _ := io.ReadAll(r.Body)
	s.mu.Lock()
	s.hits = append(
		s.hits,
		hit{
			method: r.Method,
			uri:    r.URL.RequestURI(),
			authz:  r.Header.Get("Authorization"),
			digest: r.Header.Get("Digest"),
			body:   string(body),
		},
	)
	s.mu.Unlock()
	if r.Header.Get("Authorization") == "" && s.firstStatus != 0 {
		for _, c := range s.challenges {
			w.Header().Add("WWW-Authenticate", c)
		}
		w.Header().Set("X-Response", "first")
		w.WriteHeader(s.firstStatus)
		_, _ = io.WriteString(w, "first")
		return
	}
	if r.Header.Get("Authorization") == "" {
		for _, c := range s.challenges {
			w.Header().Add("WWW-Authenticate", c)
		}
		w.Header().Set("X-Response", "challenge")
		w.WriteHeader(http.StatusUnauthorized)
		_, _ = io.WriteString(w, "challenge")
		return
	}
	if s.challengeNonDigest && !strings.HasPrefix(r.Header.Get("Authorization"), "Digest ") {
		for _, c := range s.challenges {
			w.Header().Add("WWW-Authenticate", c)
		}
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	status := s.okStatus
	s.mu.Lock()
	if len(s.answerStatuses) > 0 {
		status, s.answerStatuses = s.answerStatuses[0], s.answerStatuses[1:]
	}
	s.mu.Unlock()
	w.Header().Set("X-Response", "answered")
	w.WriteHeader(status)
	_, _ = io.WriteString(w, "answered")
}

func (s *server) recorded() []hit {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([]hit(nil), s.hits...)
}

// run executes one request through the public headless API and returns the
// status code it ended with.
func run(t *testing.T, s *server, auth, method, path, extra string) int {
	t.Helper()
	src := fmt.Sprintf("# @name r\n%s%s %s%s\n%s", auth, method, s.srv.URL, path, extra)
	file := filepath.Join(t.TempDir(), "r.http")
	if err := os.WriteFile(file, []byte(src), 0o600); err != nil {
		t.Fatal(err)
	}
	rep, err := headless.Run(context.Background(), headless.Options{Source: headless.Source{Path: file}})
	if err != nil {
		t.Fatalf("run: %v", err)
	}
	if len(rep.Results) != 1 || rep.Results[0].HTTP == nil {
		t.Fatalf("no HTTP result: %+v", rep.Results)
	}
	return rep.Results[0].HTTP.StatusCode
}

// runShowing runs the request like run and also requires the result to be the
// response that sent the given body and X-Response marker.
func runShowing(t *testing.T, s *server, auth, method, path, extra, marker string) int {
	t.Helper()
	asserts := fmt.Sprintf(
		"# @assert response.text() == %q\n# @assert response.header(\"X-Response\") == %q\n",
		marker, marker,
	)
	src := fmt.Sprintf("# @name r\n%s%s%s %s%s\n%s", auth, asserts, method, s.srv.URL, path, extra)
	file := filepath.Join(t.TempDir(), "r.http")
	if err := os.WriteFile(file, []byte(src), 0o600); err != nil {
		t.Fatal(err)
	}
	rep, err := headless.Run(context.Background(), headless.Options{Source: headless.Source{Path: file}})
	if err != nil {
		t.Fatalf("run: %v", err)
	}
	if len(rep.Results) != 1 || rep.Results[0].HTTP == nil {
		t.Fatalf("no HTTP result: %+v", rep.Results)
	}
	res := rep.Results[0]
	if len(res.Tests) != 2 {
		t.Fatalf("assertions = %+v, want 2", res.Tests)
	}
	for _, tc := range res.Tests {
		if !tc.Passed {
			t.Fatalf("result is not the %q response: %s %s", marker, tc.Name, tc.Message)
		}
	}
	return res.HTTP.StatusCode
}

func digestAuth(u, p string) string {
	return fmt.Sprintf("# @auth digest-auth %s %s\n", u, p)
}

// RFC 7616 section 3.4: these are always sent as quoted strings, and
// algorithm, qop and nc never are.
var (
	quotedParams = map[string]bool{
		"username": true, "realm": true, "nonce": true, "uri": true,
		"response": true, "cnonce": true, "opaque": true,
	}
	tokenParams = map[string]bool{"algorithm": true, "qop": true, "nc": true}
)

// parseAuthz reads `Digest a="b", c=d`, unescaping quoted values, and checks
// each parameter uses the form RFC 7616 requires.
func parseAuthz(t *testing.T, v string) map[string]string {
	t.Helper()
	scheme, rest, ok := strings.Cut(strings.TrimSpace(v), " ")
	if !ok || !strings.EqualFold(scheme, "digest") {
		t.Fatalf("Authorization is not a Digest answer: %q", v)
	}
	out := map[string]string{}
	for rest = strings.TrimSpace(rest); rest != ""; {
		name, after, ok := strings.Cut(rest, "=")
		if !ok {
			t.Fatalf("bad Digest parameter in %q", v)
		}
		name = strings.ToLower(strings.TrimSpace(name))
		after = strings.TrimSpace(after)
		var val string
		quoted := strings.HasPrefix(after, `"`)
		if quoted && tokenParams[name] {
			t.Fatalf("%s must not be a quoted string in %q", name, v)
		}
		if !quoted && quotedParams[name] {
			t.Fatalf("%s must be a quoted string in %q", name, v)
		}
		if quoted {
			var b strings.Builder
			i := 1
			for ; i < len(after) && after[i] != '"'; i++ {
				if after[i] == '\\' && i+1 < len(after) {
					i++
				}
				b.WriteByte(after[i])
			}
			if i < len(after) {
				i++ // skip the closing quote
			}
			val, after = b.String(), after[i:]
		} else {
			end := strings.IndexByte(after, ',')
			if end < 0 {
				end = len(after)
			}
			val, after = strings.TrimSpace(after[:end]), after[end:]
		}
		out[name] = val
		rest = strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(after), ","))
	}
	return out
}

func hasher(alg string) func() hash.Hash {
	if strings.HasPrefix(strings.ToUpper(alg), "SHA-256") {
		return sha256.New
	}
	return md5.New
}

func hx(alg string, parts ...string) string {
	h := hasher(alg)()
	_, _ = io.WriteString(h, strings.Join(parts, ":"))
	return hex.EncodeToString(h.Sum(nil))
}

// expected recomputes the response from the answer's own nonce, cnonce, nc,
// qop and uri, so it holds for any valid cnonce.
func expected(alg, realm string, p map[string]string, h hit) string {
	ha1 := hx(alg, user, realm, pass)
	if strings.HasSuffix(strings.ToLower(alg), "-sess") {
		ha1 = hx(alg, ha1, p["nonce"], p["cnonce"])
	}
	ha2 := hx(alg, h.method, p["uri"])
	if p["qop"] == "auth-int" {
		ha2 = hx(alg, h.method, p["uri"], hx(alg, h.body))
	}
	if p["qop"] == "" {
		return hx(alg, ha1, p["nonce"], ha2)
	}
	return hx(alg, ha1, p["nonce"], p["nc"], p["cnonce"], p["qop"], ha2)
}

var nonceParam = regexp.MustCompile(`(?i)(?:^|[\s,])nonce\s*=\s*(?:"((?:[^"\\]|\\.)*)"|([^\s,]+))`)

// challengeNonces returns the unescaped nonces of the server's challenges.
func challengeNonces(s *server) map[string]bool {
	out := map[string]bool{}
	for _, c := range s.challenges {
		for _, m := range nonceParam.FindAllStringSubmatch(c, -1) {
			if m[1] != "" {
				out[regexp.MustCompile(`\\(.)`).ReplaceAllString(m[1], "$1")] = true
			} else {
				out[m[2]] = true
			}
		}
	}
	return out
}

// answered checks the run was one challenge and one correct Digest answer
// and returns the answer's parameters.
func answered(t *testing.T, s *server, alg, realm string) map[string]string {
	t.Helper()
	hits := s.recorded()
	if len(hits) != 2 {
		t.Fatalf("server saw %d requests, want 2", len(hits))
	}
	if hits[0].authz != "" {
		t.Fatalf("first request carried Authorization %q", hits[0].authz)
	}
	p := parseAuthz(t, hits[1].authz)
	if !challengeNonces(s)[p["nonce"]] {
		t.Fatalf("nonce %q is not from a challenge the server sent", p["nonce"])
	}
	if p["username"] != user || p["realm"] != realm {
		t.Fatalf("username/realm = %q/%q", p["username"], p["realm"])
	}
	if p["uri"] != hits[1].uri {
		t.Fatalf("uri = %q, want %q", p["uri"], hits[1].uri)
	}
	if !strings.EqualFold(p["algorithm"], alg) {
		t.Fatalf("algorithm = %q, want %q", p["algorithm"], alg)
	}
	if want := expected(alg, realm, p, hits[1]); p["response"] != want {
		t.Fatalf("response = %q, want %q", p["response"], want)
	}
	return p
}

// answersUsableChallenge runs the same credentials against a server with a
// usable challenge, so a case that expects no answer also shows the request
// would have been answered when it could be.
func answersUsableChallenge(t *testing.T) {
	t.Helper()
	s := newServer(t, `Digest realm="r", nonce="usable", qop="auth"`)
	if got := run(t, s, digestAuth(user, pass), "GET", "/", ""); got != 200 {
		t.Fatalf("usable challenge: status %d, want 200", got)
	}
	answered(t, s, "MD5", "r")
}

func checkAnswers(t *testing.T, s *server, want int) {
	t.Helper()
	hits := s.recorded()
	if len(hits) != want {
		t.Fatalf("server saw %d requests, want %d", len(hits), want)
	}
	for i := 0; i < len(hits); i += 2 {
		if hits[i].authz != "" {
			t.Fatalf("request %d carried Authorization %q", i, hits[i].authz)
		}
		p := parseAuthz(t, hits[i+1].authz)
		if p["nonce"] != "n" {
			t.Fatalf("answer %d nonce = %q, want n", i+1, p["nonce"])
		}
		if want := expected("MD5", "r", p, hits[i+1]); p["response"] != want {
			t.Fatalf("answer %d response = %q, want %q", i+1, p["response"], want)
		}
	}
}

func redirector(t *testing.T, target string) *httptest.Server {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, target, http.StatusFound)
	}))
	t.Cleanup(srv.Close)
	return srv
}

func runURL(t *testing.T, extra, auth, target string) int {
	t.Helper()
	src := fmt.Sprintf("# @name r\n%s%sGET %s\n", extra, auth, target)
	file := filepath.Join(t.TempDir(), "r.http")
	if err := os.WriteFile(file, []byte(src), 0o600); err != nil {
		t.Fatal(err)
	}
	rep, err := headless.Run(context.Background(), headless.Options{Source: headless.Source{Path: file}})
	if err != nil {
		t.Fatalf("run: %v", err)
	}
	if len(rep.Results) != 1 || rep.Results[0].HTTP == nil {
		t.Fatalf("no HTTP result: %+v", rep.Results)
	}
	return rep.Results[0].HTTP.StatusCode
}

