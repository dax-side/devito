# Digest contest notes (ready to paste)

## S1: empty Authorization header (Auto Review solution finding)
Hello <@reviewer>, I'm only disputing the S1 finding (empty `Authorization:` header). All other findings have been addressed, the description is 3/3, and SQ passed 3/3 on this exact solution.

The description says "If a request already contains an Authorization header digest-auth will not be used." It never says an empty header counts. The repo already defines what a present header means: `header.Present` is documented as "reports whether name carries a non-blank value", and the base code's Basic and Bearer auth use that same check (`internal/protocol/httpx/auth.go`). An empty `Authorization:` line doesn't block Basic or Bearer today, so Digest follows exactly what the repo does for every other auth kind. Changing it for Digest alone would make the auth kinds behave inconsistently.

Asking to drop S1 as it follows the repo's existing convention. Thanks.

## Run 7 environment blocker (accepted, run scratched)
Run 7 is not an environment or verifier blocker. The failing check requires `response` to be quoted, which is a MUST in RFC 7616 §3.4, and the task title names RFC 7616. Run 3 failed the same assertion, and its grader called it "reasonably knowable" from the RFC reference. TQ also rated this check fair ("Standard external semantics"). The base suite had 0 failures, and 3 runs passed all 55 tests.

## Ready answers
- cnonce randomness: TQ marked a randomness test unfair twice (random values can repeat); no fair black-box test exists.
- qop order (auth,auth-int / auth-int, auth): valid Medium; two quick test cases if a revision round happens anyway.
