"""FP screen probes for max_stable_dt: the SQ probes plus stated features in new combinations and extremes."""
import os
import sys

import numpy as np
import sympy

import devito
from devito import (Constant, Eq, Function, Grid, TimeFunction, VectorTimeFunction,
                    TensorTimeFunction, div, grad)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sq_probes import PROBES as SQ, random_field as SQ_random  # noqa: E402

rng = np.random.default_rng(1)


def g(shape=(60,), extent=None, dtype=np.float64):
    return Grid(shape=shape, extent=extent or (1.0,) * len(shape), dtype=dtype)


def damped(limit):
    def f():
        gr = g(); u = TimeFunction(name='u', grid=gr); dt = gr.time_dim.spacing
        return devito.max_stable_dt(Eq(u.forward, (1 - (2 + 1e-4) / limit * dt) * u))
    return f


def wave(shape, so, c=1.5, spacing_extent=None, save=None, backward=False):
    def f():
        gr = g(shape, spacing_extent); dt = gr.time_dim.spacing
        u = TimeFunction(name='u', grid=gr, space_order=so, time_order=2, save=save)
        if backward:
            return devito.max_stable_dt(Eq(u.backward, 2 * u - u.forward + dt**2 * c**2 * u.laplace))
        return devito.max_stable_dt(Eq(u.forward, 2 * u - u.backward + dt**2 * c**2 * u.laplace))
    return f


def diffusion(shape, nu=0.3):
    def f():
        gr = g(shape); dt = gr.time_dim.spacing
        u = TimeFunction(name='u', grid=gr, space_order=2)
        return devito.max_stable_dt(Eq(u.forward, u + dt * nu * u.laplace))
    return f


def upwind(sign):
    def f():
        gr = g(); x, = gr.dimensions; t = gr.stepping_dim; dt = gr.time_dim.spacing; h = x.spacing
        u = TimeFunction(name='u', grid=gr)
        a = 2.0 * sign
        diff = (u - u[t, x - 1]) / h if sign > 0 else (u[t, x + 1] - u) / h
        return devito.max_stable_dt(Eq(u.forward, u - dt * a * diff))
    return f


def gridless(size):
    def f():
        gr = g(); x, = gr.dimensions; dt = gr.time_dim.spacing
        u = TimeFunction(name='u', grid=gr, space_order=2)
        c = Function(name='c', dimensions=(x,), shape=(size,)); c.data[:] = 1.0
        return devito.max_stable_dt(Eq(u.forward, u + dt * c * u.dx2))
    return f


def staggered_2d():
    gr = g((16, 16)); dt = gr.time_dim.spacing
    v = VectorTimeFunction(name='v', grid=gr, space_order=4)
    p = TimeFunction(name='p', grid=gr, space_order=4, staggered=None)
    vp = Function(name='vp', grid=gr); vp.data[:] = 1.5 + rng.random((16, 16))
    return devito.max_stable_dt([Eq(v.forward, v - dt * grad(p)),
                                 Eq(p.forward, p - dt * vp**2 * div(v.forward))])


def elastic_2d():
    gr = g((24, 24)); dt = gr.time_dim.spacing
    v = VectorTimeFunction(name='v', grid=gr, space_order=2)
    tau = TensorTimeFunction(name='tau', grid=gr, space_order=2)
    lam, mu = 2.0, 1.0
    e = grad(v.forward) + grad(v.forward).transpose(inner=False)
    return devito.max_stable_dt([Eq(v.forward, v + dt * div(tau)),
                                 Eq(tau.forward, tau + dt * (lam * sympy.eye(2) * div(v.forward)
                                                             + mu * e))])


def constant_coefficient():
    gr = g(); dt = gr.time_dim.spacing
    k = Constant(name='k', value=0.7)
    u = TimeFunction(name='u', grid=gr, space_order=2)
    return devito.max_stable_dt(Eq(u.forward, u + dt * k * u.dx2))


def nan_constant():
    gr = g(); dt = gr.time_dim.spacing
    k = Constant(name='k', value=np.nan)
    u = TimeFunction(name='u', grid=gr, space_order=2)
    return devito.max_stable_dt(Eq(u.forward, u + dt * k * u.dx2))


def exp_form():
    gr = g(); dt = gr.time_dim.spacing
    u = TimeFunction(name='u', grid=gr, space_order=2)
    return devito.max_stable_dt(Eq(u.forward, u + (1 - sympy.exp(-dt)) * u.dx2 / 1000))


def source_ignored():
    gr = g(); dt = gr.time_dim.spacing
    u = TimeFunction(name='u', grid=gr, space_order=2)
    s = Function(name='s', grid=gr); s.data[:] = 5.0
    return devito.max_stable_dt(Eq(u.forward, u + dt * u.dx2 + dt * s))


def tuple_two():
    gr = g(); dt = gr.time_dim.spacing
    u = TimeFunction(name='u', grid=gr, space_order=2)
    w = TimeFunction(name='w', grid=gr, space_order=2)
    return devito.max_stable_dt((Eq(u.forward, u + dt * w.dx2), Eq(w.forward, w + dt * u.forward.dx2)))


def all_stable():
    gr = g(); u = TimeFunction(name='u', grid=gr)
    return devito.max_stable_dt(Eq(u.forward, u))


def never_stable():
    gr = g(); u = TimeFunction(name='u', grid=gr)
    return devito.max_stable_dt(Eq(u.forward, 1.5 * u))


def layered_field():
    gr = g((40, 30)); dt = gr.time_dim.spacing
    u = TimeFunction(name='u', grid=gr, space_order=4, time_order=2)
    c = Function(name='c', grid=gr); c.data[:] = 1.0; c.data[:, 20:] = 3.0; c.data[7, 3] = 4.2
    return devito.max_stable_dt(Eq(u.forward, 2 * u - u.backward + dt**2 * c**2 * u.laplace))


def complex_rotation():
    gr = g((16,), dtype=np.complex128); dt = gr.time_dim.spacing
    u = TimeFunction(name='u', grid=gr, dtype=np.complex128, space_order=2)
    return devito.max_stable_dt(Eq(u.forward, u + dt * (0.1 + 1j) * u.dx2 / 100))


PROBES = dict(SQ)
PROBES.update({
    'limit 1e10 (window end)': (damped(1e10), None),
    'limit 1e-10 (window end)': (damped(1e-10), None),
    'limit 1e13 (past window, may be inf)': (damped(1e13), None),
    'limit 1e30 (past window, may be inf)': (damped(1e30), None),
    'limit 1e-13 (past window, may be 0)': (damped(1e-13), None),
    'limit 1e-301 (past window, may be 0)': (damped(1e-301), None),
    'gridless field, grid size (silent)': (gridless(60), None),
    'gridless field, wrong size (silent)': (gridless(8), None),
    'wave 2D so8 anisotropic': (wave((32, 24), 8, spacing_extent=(1.0, 3.0)), None),
    'wave 3D so2 saved': (wave((12, 12, 12), 2, save=5), None),
    'wave 2D backward': (wave((32, 32), 4, backward=True), None),
    'diffusion 1D': (diffusion((60,)), None),
    'diffusion 3D': (diffusion((12, 12, 12)), None),
    'upwind positive': (upwind(1), None),
    'upwind negative': (upwind(-1), None),
    'staggered acoustic 2D random vp': (staggered_2d, None),
    'Constant coefficient': (constant_coefficient, None),
    'NaN Constant (refuse)': (nan_constant, None),
    'exp(-dt) form': (exp_form, None),
    'source ignored': (source_ignored, None),
    'tuple of two, sequential': (tuple_two, None),
    'all steps stable': (all_stable, None),
    'no step stable': (never_stable, None),
    'layered field with spike': (layered_field, None),
    'complex coefficient': (complex_rotation, None),
})

for _name in ('random field 64x64, space order 4', 'random field 16^3, space order 4',
              'random field 8^4, space order 2'):
    PROBES.pop(_name)
PROBES['random field 20x20, space order 4'] = (lambda: SQ_random((20, 20), 4), None)
PROBES['random field 8^3, space order 2'] = (lambda: SQ_random((8, 8, 8), 2), None)
