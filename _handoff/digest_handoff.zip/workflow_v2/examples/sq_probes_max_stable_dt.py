"""SQ lint probes for max_stable_dt: stated features in pairs, and bounds at their limits."""
import numpy as np

import devito
from devito import (Constant, Dimension, Eq, Function, Grid, TimeFunction,
                    VectorTimeFunction, div, grad)

rng = np.random.default_rng(0)


def grid(shape=(60,), **kw):
    return Grid(shape=shape, extent=(1.0,) * len(shape), dtype=np.float64, **kw)


def positive(v):
    return 0 < v < np.inf


def index_x_weights():
    g = grid(); x, = g.dimensions; dt = g.time_dim.spacing
    slot = Dimension(name='slot')
    w = Function(name='w', grid=g, dimensions=(x, slot), shape=(60, 3)); w.data[:] = 4.0
    u = TimeFunction(name='u', grid=g)
    return devito.max_stable_dt(Eq(u.forward, (1 - dt * w[x, 0]) * u))


def index_x_backward():
    g = grid(); x, = g.dimensions; t = g.stepping_dim; dt = g.time_dim.spacing
    u = TimeFunction(name='u', grid=g)
    return devito.max_stable_dt(Eq(u.backward, u - dt * (u - u[t, x + 1]) / x.spacing))


def index_x_saved():
    g = grid(); x, = g.dimensions; time = g.time_dim; dt = time.spacing
    u = TimeFunction(name='u', grid=g, save=10)
    return devito.max_stable_dt(Eq(u.forward, u - dt * (3 * u - u[time - 1, x]) / 2))


def index_x_constant_dt():
    step = Constant(name='dt', value=0.1)
    from devito.types import TimeDimension
    time = TimeDimension(name='time', spacing=step)
    g = Grid(shape=(60,), extent=(1.0,), time_dimension=time, dtype=np.float64)
    x, = g.dimensions; t = g.stepping_dim
    u = TimeFunction(name='u', grid=g)
    return devito.max_stable_dt(Eq(u.forward, u - 2 * step * (u - u[t, x - 1]) / x.spacing))


def index_x_staggered_backward():
    g = grid(); x, = g.dimensions; t = g.stepping_dim; dt = g.time_dim.spacing; h = x.spacing
    v = TimeFunction(name='v', grid=g, staggered=x); p = TimeFunction(name='p', grid=g)
    return devito.max_stable_dt([
        Eq(v.backward, v - dt * (p[t, x + 1] - p[t, x]) / h),
        Eq(p.backward, p - dt * 2.25 * (v[t - 1, x] - v[t - 1, x - 1]) / h)])


def weights_x_backward():
    g = grid(); x, = g.dimensions; dt = g.time_dim.spacing
    u = TimeFunction(name='u', grid=g, space_order=2, time_order=2)
    op = u.dx2(weights=[1.0, -2.0, 1.0])
    return devito.max_stable_dt(Eq(u.backward, 2 * u - u.forward + dt**2 * op))


def order4_intermediate_x_backward():
    g = grid(); t = g.stepping_dim; dt = g.time_dim.spacing
    u = TimeFunction(name='u', grid=g, time_order=4)
    return devito.max_stable_dt(Eq(u.backward, (1 + 0.01 * dt) * u.subs(t, t - dt)))


def history_at_bound_order6():
    g = grid(); t = g.stepping_dim; dt = g.time_dim.spacing
    u = TimeFunction(name='u', grid=g, time_order=6)
    return devito.max_stable_dt(Eq(u.forward, u.subs(t, t - 5 * dt)))


def history_past_bound_order6():
    g = grid(); t = g.stepping_dim; dt = g.time_dim.spacing
    u = TimeFunction(name='u', grid=g, time_order=6)
    return devito.max_stable_dt(Eq(u.forward, u.subs(t, t - 6 * dt)))


def complex_x_partial_field():
    g = Grid(shape=(16, 16), extent=(1.0, 1.0), dtype=np.complex128)
    x, y = g.dimensions; dt = g.time_dim.spacing
    a = Function(name='a', grid=g, dimensions=(y,), shape=(16,), dtype=np.complex128)
    a.data[:] = 1j
    u = TimeFunction(name='u', grid=g, dtype=np.complex128)
    return devito.max_stable_dt(Eq(u.forward, u + dt * a * u))


def vector_x_backward():
    g = grid((16, 16))
    v = VectorTimeFunction(name='v', grid=g, space_order=2)
    p = TimeFunction(name='p', grid=g, space_order=2, staggered=None)
    dt = g.time_dim.spacing
    return devito.max_stable_dt([Eq(v.backward, v - dt * grad(p)),
                                 Eq(p.backward, p - dt * div(v.backward))])


def forcing_next_level_index():
    g = grid(); x, = g.dimensions; t = g.stepping_dim
    u = TimeFunction(name='u', grid=g); w = TimeFunction(name='w', grid=g)
    return devito.max_stable_dt(Eq(u.forward, u + w[t + 1, x]))


def half_step_index():
    g = grid(); x, = g.dimensions; t = g.stepping_dim; dt = g.time_dim.spacing
    u = TimeFunction(name='u', grid=g)
    return devito.max_stable_dt(Eq(u.forward, u - dt * u[t, x - 0.5]))


def symbolic_slot_index():
    g = grid(); x, = g.dimensions; dt = g.time_dim.spacing
    slot = Dimension(name='slot')
    w = Function(name='w', grid=g, dimensions=(x, slot), shape=(60, 3)); w.data[:] = 1.0
    u = TimeFunction(name='u', grid=g)
    return devito.max_stable_dt(Eq(u.forward, (1 - dt * w[x, slot]) * u))


def limit_at_low_bound():
    g = Grid(shape=(60,), extent=(1e3,), dtype=np.float64); dt = g.time_dim.spacing
    u = TimeFunction(name='u', grid=g)
    return devito.max_stable_dt(Eq(u.forward, (1 - (2 + 1e-4) / 1e-6 * dt) * u))


def limit_at_high_bound():
    g = Grid(shape=(60,), extent=(1e-3,), dtype=np.float64); dt = g.time_dim.spacing
    u = TimeFunction(name='u', grid=g)
    return devito.max_stable_dt(Eq(u.forward, (1 - (2 + 1e-4) / 1e6 * dt) * u))


def random_field(shape, so):
    g = grid(shape); dt = g.time_dim.spacing
    u = TimeFunction(name='u', grid=g, space_order=so, time_order=2)
    c = Function(name='c', grid=g); c.data[:] = 1 + rng.random(shape)
    return devito.max_stable_dt(Eq(u.forward, 2 * u - u.backward + dt**2 * c**2 * u.laplace))


PROBES = {
    'index x function weights': (index_x_weights, lambda v: abs(v - 0.5) < 1e-3),
    'index x backward': (index_x_backward, positive),
    'index x saved history': (index_x_saved, positive),
    'index x Constant time step': (index_x_constant_dt, positive),
    'index x staggered x backward': (index_x_staggered_backward, positive),
    'numeric weights x backward': (weights_x_backward, positive),
    'time order 4 intermediate x backward': (order4_intermediate_x_backward, positive),
    'history at the 8-level bound (order 6)': (history_at_bound_order6, 'ok'),
    'history past the bound (order 6)': (history_past_bound_order6, 'refuse'),
    'complex x partial-dimension field': (complex_x_partial_field, positive),
    'vector x backward system': (vector_x_backward, positive),
    'forcing reads next level via index': (forcing_next_level_index, 'refuse'),
    'half-step index on unstaggered field': (half_step_index, 'refuse'),
    'symbolic slot index': (symbolic_slot_index, 'refuse'),
    'limit at 1e-6': (limit_at_low_bound, lambda v: abs(v / 1e-6 - 1) < 1e-4),
    'limit at 1e6': (limit_at_high_bound, lambda v: abs(v / 1e6 - 1) < 1e-4),
    'random field 64x64, space order 4': (lambda: random_field((64, 64), 4), positive),
    'random field 16^3, space order 4': (lambda: random_field((16, 16, 16), 4), positive),
    'random field 8^4, space order 2': (lambda: random_field((8, 8, 8, 8), 2), positive),
}
