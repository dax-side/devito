# CLAUDE.md: Shipd task rules (v2)


## PRE-UPLOAD GATE (mandatory, every upload, no exceptions; added after CBOR: 10 platform fails)
Do not tell the user to upload until every line below is done and shown in the reply.
1. Sentence split: list every claim each sentence makes (each "either/or/both/any/(or X)" multiplies claims). Every claim has a test, or the word is cut. No partial-making sentence goes out.
2. Every guard/limit/refusal in the solution is (a) in the description, (b) tested, in the same round. TDD order: sentence, failing test, code. Never add a guard during an SQ fix without both.
3. Pre-SQ review (step 5b) on the final solution, Opus model, before the FIRST SQ upload. Fix every reproduced finding in one bundle.
4. Repo linter run and diffed against a clean worktree: 0 new findings.
5. New behaviour sits in the repo's existing shared mechanism (e.g. the built-in tag check), not per destination/path.
6. Harness: base run reports every new test by name as failed (no single "[build failed]"); test names identical across 3 runs per mode (strip pointers/addresses); 3 runs base + 3 runs solution all as expected.
7. Pre-TQ check (fairness + coverage), Opus, on the exact files. 0 unfair; every non-ok row closed by a value change or the word cut.
8. After a check PASSes, do not chase it for the CHECK's sake. But TQ coverage suggestions are the official early FP warning (Olympus note 7/16/26): triage each one BEFORE rollouts. Real gap = a stated requirement where a plausible agent shortcut passes (prove it: write the test, run it on the reference and, if available, on agent patches; it must pass the reference and catch a real or plausible shortcut) -> add it as a value/row in an existing test. Noise = no stated requirement, or 0 agents/probes fail it -> log and skip. Never add a test for an unstated behaviour.
9. Before ANY FP panel: run probe_default, probe_feature and fuzz_stated on every passer (runner/<task>/). Any S-line or fuzz difference on a stated sentence = add the test first. When the reference side shows PANIC/TIMEOUT, re-check the input with a cheap comparison before dismissing (lesson 97).
10. Before the first upload: (a) run every CI workflow gate (coverage threshold, lint) on the reference; (b) skip any solution-side test in test.sh base mode; (c) list every guard/option check in the reference that the description does not state, and remove it or state+test it (lessons 99-101).

These rules apply to every session on a Shipd Olympus task. A mentor or official-guide ruling beats them; record it in `rulings.md`. v2 replaces v1: the v1 rules "test every sentence on every kind", "mirror every probe row with a test" and "clear every bulb" were the ones that inflated scope, and they are gone.

## Before anything: pick the task, set the budget (v3, after tabulate was dropped)
tabulate took 50 versions and 116 agent runs, and was dropped with 0 clean passes. The full study is `postmortems/tabulate.md`. Its main rules:
- **Five questions; any "no" means pick another task.**
  1. Can every behaviour be shown as `input -> exact value or error type`?
  2. Can it be built without touching code that every existing call goes through?
  3. Can it be described in about 10 behaviours?
  4. Do the tests run in seconds?
  5. Would an agent that runs the description's examples catch its own mistakes?
- **Also hard rejects, after the five questions:**
  - A lean prototype measures under 200 effective lines.
  - An open or merged PR already implements the feature. When the search API is blocked, fetch the PR refs and grep each PR's diff (lesson 85).
  - python-semver ranges passed all five questions and failed both of these: 101 lean lines, two open PRs.
- **The 200-line floor still applies.** Questions 3 and the 200-line floor pull against each other. Look for about 10 behaviours that each need real code (a parser, a resolver, a spec with rules), not 25 small behaviours spread over many formats. Go's verbosity helps here.
- **Avoid:**
  - Output where the layout is the result: tables, terminal output, colour codes, wide characters, many output formats.
  - Byte-identical compatibility with buggy legacy output.
  - Behaviour that must be *better* than an existing helper the agent will reuse.
- **Budget on day one:** for example, 15 versions or 40 agent runs. At each budget point, Claude says plainly **continue, cut (name what) or drop**, with evidence. Claude also makes that call when a gate gives a new finding on unchanged code, or when 8 fresh runs share one blocker. G13 already existed and was ignored for 40 versions; the budget is what makes it bite (lesson 84).
- **Measure the pass rate early:** probe the first 4-8 runs of **one** description version, per behaviour. Any behaviour under 30% is a blocker. If the product of the rates is under 5%, redesign or drop now (postmortem 8.2).
- **Agents follow the text literally, and nothing else** (82 runs):
  - Stated behaviour fails 4% of the time, unstated 54%, contradicted 100%.
  - Words like after, raise, may and every decide the implementation.
  - An open sentence splits agents 50/50.
  - Agents don't generalise past the example. The example must be a case that the naive approach, or the base helper, gets **wrong**.
- **Agents always touch shared code:** 98% did, and only 4 of 82 kept the default path identical, even when told "nothing changes". Only a test stops it.
- **Agents' self-reports mean nothing:** 82 of 82 said "tests pass"; 0 of 82 passed.
- **Freeze the description and the tests together before collecting runs.** Runs made against an older text are not evidence that a test is fair.

## The contract
- Description, solution and tests are one contract. Never edit one without checking the other two in the same change.
- One sentence, one requirement. If a sentence joins two promises with "and", split it or cut one.
- A universal word (any, every, all, whichever, always, never, exactly) is allowed only when the code enforces it on every entry route and a test samples it. Otherwise name the tested cases instead ("with the nearest and linear schemes").
- Every refusal or guard the solution implements is stated in the description, and the code enforces it on every entry route SQ can build: a plain array, a pre-built object, rebuild, pickle, copy, subs, and shapes that happen to match a legacy layout. Tests only sample these routes; the code must hold on all of them.
- Never restate legacy behaviour as a new requirement ("behaves exactly as it does now"). Point at it instead ("is accepted as it is today"). The repo's own suite already guards it.
- To scope something out, narrow the sentence that implied it ("for points that stay inside the domain"). Never write a list of exclusions, and never describe behaviour outside the promise. Remove the code that served a dropped promise in the same round.

## Who owns a finding (decide before any edit)
| Finding | Owner and action |
|---|---|
| TQ FAIL or an unfair test | Description states it, or the test is loosened or deleted |
| TQ PASS, "partial" row, gap kind "single point" | Accept. A test samples a rule; no wording removes this |
| TQ PASS, "partial" row, gap kind "not discriminating" | Reword the sentence narrower or point it at today's behaviour. Never add a test |
| TQ coverage suggestions (bulbs) | Advisory, and avoidable: a task written to the coverage patterns below got zero bulbs on three versions. Once the tests are frozen for rollouts, log them and act only if the platform blocks on one. Before that, apply the patterns below, which cost parameter values, not new tests |
| SQ defect on a stated promise | Fix the solution on every route. Retarget an existing test case if one fits (change a value, not add a test) |
| SQ demand for behaviour the description never states | Narrow or cut the sentence it extrapolated from, or contest with a verifiable harness fact |
| Verify Solution `before_f2p_unexpectedly_passing` | Give that test a case that fails on base for the right reason, or delete it |
| DQ finding of any kind | Fix it. DQ can no longer be contested (lesson 47). DQ also fails over 400 words (`\w+` count; budget 385) and runs a blocking AI-text detector, so the author writes the prose and Claude only checks it (lessons 53, 64, 66) |
| FP panel finding | Judged against **base** behaviour as well as the text: a passer that differs from base on an existing path, or on a value base already handles in data cells, is an FP even if the text is silent (lesson 63). Turn every finding into a test, then check the passer fails exactly those |
| Advisory note on a PASS (TQ partial, SQ medium, coverage bulb) | Not a blocker. Fix only on a FAIL. SQ re-samples every run, so a medium on unchanged code is noise (lesson 74) |
| Lint (ruff, flake8) | Fix. Check the repo config first: E226 is ignored in devito, so an "E225" claim on `(1,)*(n)` is wrong |
| The same sentence, code path or test touched in two rounds | Stop patching it. Narrow the sentence or cut the feature |

## Coverage patterns (from a task that got full coverage and zero bulbs on three versions)
- Every universal word ranges over a finite, named set, and the tests walk the whole set: "an even fd_order of 2, 4, 6 or 8" with a test over all five pairs; "every Operator optimization level" with a test over all three modes; "every explicit side" with left, right and centered.
- Where the set is open (for example "anything else raises a ValueError"), sample it across value classes, not a handful: strings, None, 0 and 1, floats, empty and non-empty containers, tuples, numpy bools and integers. Eight or more classes read as covered; five read as a single point.
- Refusals are an enumerated list of named categories (in prose, since lists are banned for us), and each category gets its own parametrised case, often from two routes.
- Every numeric boundary is stated as a formula and tested from both sides: the minimum size is rejected at needed - 1 and accepted at needed.
- Every quality claim is stated as its observable check: "refining the grid has to keep driving the edge error down" is a sentence the test executes directly.
- Out-of-scope items are stated as non-requirements ("is not required to work, and an implementation may reject it"), never as refusals. That creates no requirement, so it cannot create a partial row. It is different from an exclusion list that says something "is refused".
- For a constant the tests fix (such as the number of steps), vary it in at least one parametrised case, or TQ flags it as hardcodable.
- Promise few independent dimensions. Every list in the description (dimensions, precisions, schemes, operations, declaration routes, shift directions) multiplies the promised cells, and a reviewer hunts for the unsampled cell. Attach a list to the one central sentence that needs it and give that sentence one full cross-product test; state every other rule once, at one representative configuration.
- Bulbs come in two kinds. "Single point": an open rule is sampled once (fix with a finite named set or wider sampling). "Not discriminating": the sentence is stricter than the assertion, so a wrong implementation would still pass (fix by deleting the stricter claim, or by making the assertion exactly as strict). The v2 of the reference task got 4 bulbs, all of the second kind, all from two sentences: error-message content ("the message names the offending value as a standalone word") and error timing checked with construction inside pytest.raises. v3 and v4 dropped the message rule and built the object outside pytest.raises, and the bulbs went to zero.
- Never state error-message content. Name the exception type only.
- When a sentence says when an error happens (built versus lowered), the test must build the object outside pytest.raises and assert something about it first, then put only the lowering call inside.

## Description
- **At most 385 words, counted by `\w+`.** DQ fails over 400. Write it like a prompt to an agent: about 10 behaviours and 1-2 examples, with no steps and no laundry list.
- **Write it fresh.** Claude drafts a fact list. The author writes the prose in their own voice. Claude checks every fact against the tests and counts the words. Never cut a long text down by deleting; the leftover rule sentences score as AI.
- **Decide every open question.** State it and test it, or keep it out of both the text and the tests.
- **Don't state cosmetic choices** (padding, which border). Whatever isn't stated isn't tested.
- No headings, no lists. Plain paragraphs of at most ~150 words each, one idea per paragraph, ASCII only, no em-dashes, no hard wrapping.
- Observable behaviour only. Never name files, functions, classes, algorithms or data structures. Never dictate error wording; name the exception type only.
- A hint names the trap or its consequence, never the method, and only for a requirement an existing test already pins. Once a hint is accepted, keep it verbatim.
- After any rewrite, diff old and new sentence by sentence. Every requirement you meant to keep must survive, and every requirement you dropped must also be gone from the code and the tests.

## Tests
- **Permissive.** Check behaviour and values: where things go, and what value is shown. Use exact strings only at the value level, never for whole tables or documents (lesson 69).
- **Find rows by their content, never by a fixed index** like `out[-2]` (lesson 77).
- **Pin "nothing changes" with the exact old output.** Back it with a default-path differential before every upload: the new arguments omitted AND passed as None, over a wide matrix, with 0 differences (`runner/templates_tabulate/default_path.py`).
- **Graded checks go in new test files only.** Agents edit existing test files, and the platform merges test.patch into their copy (lesson 46).
- **Before any FP panel:** run the 10 pre-FP targets (postmortem section 4) and `FP_GAP_PROMPT.md`.
- Fewer, sharper tests. One parametrised test per requirement row. The test count is never a goal.
- Test a sentence on the declaration routes it names (for example coordinates and self-built), at one representative configuration. Only add breadth (dimensions, precisions, schemes) where the sentence itself lists that breadth.
- Every new test must fail, error or skip on clean base. Otherwise Verify Solution fails the whole check (`before_f2p_unexpectedly_passing`). Every refusal test needs a valid control that fails on base, placed before the `pytest.raises` block.
- No comments in test files or test.sh. Never assert message text (`match=`), private attributes (including `getattr(obj, '_x')`), Dimension identity, internal layout, timing, ordering, randomness or environment.
- Construction and setup go outside `pytest.raises`; only the refused call goes inside.
- Parametrise with single values or named constants, never lists of tuples.
- Use exact float equality only where the description says "exactly". Everywhere else, compare with a tolerance that matches "up to floating-point rounding".
- A test helper must never map a tested value to "omitted" (for example `moving=None` treated as "no argument").
- Derive shapes and expected values by running code, never by hand.
- New tests are appended only. Existing tests are edited only when a finding names them.

## Solution
- **Gate every behaviour change behind the new arguments.** With them omitted, the default path must give byte-identical output.
- **When new code calls a base helper,** crash-fuzz each new value kind against the existing options and formats (`runner/templates_tabulate/crash_fuzz.py`). Each crash class is one bug: fix the class, not the case.
- **Meet the repo's own gates** from the first version: lint, type check, docstrings, signature test, docs or README example (lessons 50, 55).
- Effective LOC floor: 200, counted by `runner/effloc.py`, which skips docstrings, comments, imports and bracket-only lines. Before cutting scope, measure each feature group's LOC so the cut can be chosen.
- Lint with both `ruff check` and `flake8` on the repo config.
- Before removing a helper, grep every caller, including subclasses.
- If the description promises "up to floating-point rounding", remove any code that exists only to make results bit-exact.

## Mutants
- One mutant per promise and per route (per operation, per declaration kind). Build them with `runner/mkmut.py` from a spec, never by hand.
- A mutant that survives is one of three things:
  1. The mutant hits a path the program never runs, so move it to the path that runs. Example: interpolation read host tables, not the symbolic coordinates.
  2. The code is redundant for the inputs the tests use. Before deleting it, try every entry route SQ can build. Delete only if it is redundant on all of them. Otherwise keep it and record it as untested by design. (Round 5 deleted two such checks and SQ failed on exactly those routes.)
  3. A real coverage gap on a stated promise. Retarget an existing test case to cover it, or accept the gap and record it.
- Save every mutant patch in `mutants/`. Rebuild any mutant that no longer applies; never swap in a different one silently.

## Process
- Validate only on fresh worktrees at the pinned commit, with the patches applied in platform order. `runner/prove.sh` must print `RESULT GO` before any platform spend.
- Always pass `--maxfail=100000` to pytest (devito's config sets 5).
- Back every claim in a report with a command that was run. Tag anything else SIMULATED. Never say a platform check "will pass".
- Revision tokens are scarce (500 per task, starting after submission). Prefer test-only or solution-only fixes. Stop description changes when the reserve would drop below one full round (~75).
- A description edit stales every platform check. A test edit stales Verify Tests, Verify Solution, TQ and Task Quality. A solution edit stales Verify Solution and SQ.
- Run blind solves only when asked, and time-box them.
- Deliver files in a directory the user can open, and send them to the user. Always report md5s and what changed compared with the previous round.
