# RUN.md: one-page run order

The full workflow (PROMPT.md, gates.md, lessons.md) stays the reference. This page is the order to run it in, with the command and the pass line for each step. Tick every box before the next upload; a step skipped is written down with its reason.

Paths: `W` is the scratch root, `R=$W/workflow_v2/runner`, the tree with the solution applied is `$TREE`.

## Task selection filter (before step 1)

First, the five questions in CLAUDE.md (any "no" = pick another; tabulate failed 1, 2, 3 and 5 and was dropped after 50 versions). Then agree the budget (versions or agent runs) and write it at the top of the task's notes.

Reject a candidate task if two or more of these hold (max_stable_dt had all five, and cost 38+ rollouts, 2 FP rounds and about a week):
- The answer is a floating-point number checked to a tolerance, not a behaviour (accept, refuse, write, return a structure).
- A promise ranges over an infinite set ("any form", "every mode", "any grid"), or needs a mathematical definition to be exact.
- Speed is part of correctness (a correct but slow solution would time out).
- Correctness depends on domain conventions agents must know (staggering, time orders, index notation), not on code they can read.
- The repository's own test runs take minutes (compilation, big suites), so every proof round is slow.

Prefer: exact outputs, behaviour you can list as accept/refuse cases, fast tests, conventions readable from the code. The moving sparse points task (same repository, behaviour-based) took 7 rounds and was approved.

## Before the first upload

1. **Scout.** Core is easy, bounded and finite: an exact method exists for every promise (no continuous search, no "any" over an infinite set). Pass: you can name the exact algorithm in one sentence (lesson 27, gates.md G13).
2. **Draft small.** First version sized at the easy end; difficulty comes back one group per round (CUT_PLAN pattern). Pass: the reference is under about 500 effective lines, no paragraph is over about 150 words, and the description is at most 385 words by `\w+` (DQ fails over 400; lesson 64). About 10 behaviours, 1-2 examples that show the trap.
3. **Bound every universal word.** `python3 $R/sq_lint.py description.txt` lists sentences with any/every/all/whole and no number. Pass: each listed sentence is either bounded by a number or finite set the tests sample, or was already passed by SQ (lesson 28).
4. **Every promise has a window.** Each sentinel or classification promise (`0.0`, `inf`, `None`, "raises", "is empty") holds only where the tests sample it; outside that window the description says "may" (lesson 30). Pass: no sentinel sentence without a stated range.
5. **Enforced = stated + tested.** List every refusal and guard in the reference (grep `raise`). Pass: each one is named in the description and has a test case, or is removed (field manual 1.3). A guard the prompt does not name, that correct solutions would skip, is removed from the reference, not tested (lesson 30).
6. **SQ probes.** `cd $TREE && PYTHONPATH=$TREE python3 $R/sq_lint.py description.txt probes.py --timeout 60 --memory-mb 2048`. Pass: 0 probe failures. Probes: stated features in pairs, every bound at its limit and one past it. Keep probe sizes near the test sizes; grids above 3D do not exist in Devito.
7. **Pre-check** (sonnet, set the model explicitly; 1 to 2 rounds). Skip only when the change is a clarification plus parameter values and calibration.md shows that kind kept TQ clean. Pass: no partial rows.
8. **Proof.** `SKIP_MUTANTS=... bash $R/prove.sh SHA solution.patch test.patch description.txt OUT [MUTANTS]`. Pass: last line GO. Mutants may be skipped only while their spec targets code that still exists; say so.
9. **Upload once, run TQ, SQ, DQ together.** Every DQ finding is fixed; contesting is no longer allowed (lesson 47). Before upload: default-path differential = 0 differences, crash fuzz = 0 new crash classes. What goes stale: TQ reads description and tests, SQ reads description and solution, DQ reads everything (lesson 25).

## After every rollout batch

10a. **Per-behaviour rates (first 4-8 runs of one description version).** Probe each run's behaviours (templates_tabulate/probe.py, aggregate.py). Any behaviour under 30% = blocker; product of rates under 5% = cut or drop now. Check the budget and make the continue / cut / drop call.
10. **Triage failures.** Clustered on one test = spec gap; scattered = core difficulty (field manual 8.2). Speed failures from unbatched loops are fair when a run passed in time.
11. **FP screen before the FP panel.** Run the 10 pre-FP targets (postmortems/tabulate.md section 4) on every passer: default path, degenerate inputs (no rows, empty, only the new part), values that collide with markup or base-helper bugs, every input type, existing options x new arguments, sibling features, literal readings, open sentences, unstated bad input, full product of optional parts. Any "do not send" hit = no panel. Build the probes sentence by sentence from the description (one group per sentence, plus every reference `raise` whose condition the text does not name), never only from the last failure (lesson 32).
    Then: For every passing run: replay the full new tests on its patch, then `python3 $R/fp_screen.py probes.py --out cand.json` in a tree with its patch, and the same on the reference, then `python3 $R/fp_screen.py --compare ref.json cand*.json`. Pass: no disagreement inside a stated range. Probes: the SQ probes, every sentinel at extreme magnitudes (1e-13, 1e30, 1e-301), silent inputs (objects the prompt neither allows nor refuses), feature pairs.
12. **Close every gap found in 11** (field manual 13.10, guide section 11), in this order:
    - Disagreement inside a stated, tested range: a real FP. Add a test; check how many passers it knocks out.
    - Disagreement past a stated bound: bound the promise in words ("may") and test the window ends; do not test past it.
    - Disagreement on a silent input where the reference is stricter than the prompt: make the reference match the passers (lenient), no test. Never add a refusal the prompt does not name.
    - After any fix: replay every passer on the new tests (expected pass count), rerun the stale checks from step 9.
13. **Pass band.** At least 1 pass and at most 50% over 10 runs; mentor target 20 to 30%. Too many passes: add a discriminating test (field manual 8.4), never soften the description.
14. **FP panel, then Auto Review.** Read the adjudicator, not the judges; a lone dissent on an unstated route is over-flagging (lesson 14). Auto Review compares solution and tests: every behaviour the solution enforces must be tested (step 5).

## Never

- Spawn simulated solver agents without opt-in (TOKEN BUDGET in PROMPT.md).
- Leave an agent's model unset (lesson 29).
- Run heavy probes without the memory and time caps.
- Fix a TQ partial by editing the description only (field manual 6.1).
