# Rulings

- 2026-10-04 (user): delegate minuscule mechanical jobs (word counts, md5, patch rebuilds, re-running a known harness, greps, SUBMIT count updates) to a Sonnet subagent (model: sonnet). Opus for judgement work (pre-TQ, pre-SQ, task building, FP probes).
- 2026-10-04 (platform check "test file names don't collide"): the hidden test FILE name needs a random hex too, not only its directory (digestauth_e8b45f/digestauth_test.go was flagged; renamed to digestauth_9c14be_test.go). The check compares basenames against predicted paths. Use `openssl rand -hex 3`; never "shipd" or "datacurve".
