# python-tabulate `footer` + `headergroups`: post-mortem (task abandoned)

## 0. Using this on the next task

| Stage | Do this | Where |
|---|---|---|
| 1. Pick the task | Answer the five questions; any "no" = pick another. Reject tasks that need better-than-base behaviour from a buggy helper, or that force edits to shared code (agents reuse helpers 76%, edit shared code 98%) | 5, 8.1 (A3, A4) |
| 2. Day one | Agree a budget (for example 15 versions or 40 runs). Claude makes a continue / cut / drop call at each budget point | 7 |
| 3. Description | About 10 behaviours, under 385 words, written like a prompt. Every behaviour that matters gets an example, and each example is a case the naive approach gets wrong. Choose placement and strength words (after, raise, may, every) on purpose: agents implement them literally. Decide every open question; open sentences split agents 50/50 | 4 (DQ), 8.1 (A1, A2, A6) |
| 4. Hidden tests | Permissive: check behaviour and values, never whole layouts; find rows by content, not fixed index; one sentence behind every test; pin "nothing changes" with exact old output | 4 (TQ) |
| 5. Reference solution | Gate all changes behind the new arguments; default-path diff = 0; crash sweep; meet the repo's own lint/type/docs gates; decide validation up front | 4 (SQ), Appendix D |
| 6. First 4-8 runs | Probe each run's behaviours, compute per-behaviour success rates, multiply. Any behaviour under 30% = blocker; product under 5% = redesign or drop now | 8.2, Appendix D (probe.py, aggregate.py) |
| 7. A passer | Run the 10 pre-FP targets; do not open the panel on any "do not send" hit | 4 (Pre-FP check) |
| 8. Any platform finding | Look up the gate in the lessons; fix only on a FAIL, never on an advisory note on a PASS | Appendix A, 4 |

## 1. Outcome

| | |
|---|---|
| Task | Add `footer=` and `headergroups=` to `tabulate()` (python-tabulate @ 268615a) |
| Versions shipped | 50 |
| Agent runs | 116 |
| Agent passes | 1, and it was a false positive (FP) |
| Final state | DQ passed (then re-flagged with no changes), TQ PASS (advisory partials), SQ PASS (2/3 + 3/3), FP findings all covered by tests |
| Decision | Abandoned. The task's shape kept every gate cycling; no amount of patching made two rounds in a row stable |

What was kept: the workflow (`workflow_v2`, lessons 1-84), this file, and the tools listed in section 6.

---

## 2. Why the task failed

### 2.1 Structure (the real cause)
1. **Too much surface.** Two features x 36 formats x number formats, colour codes, Decimal, bytes, html/rst/latex rules = about 25 stated behaviours. Every behaviour is one place for an agent to slip and one more thing a reviewer can probe.
2. **A pass needs all of them at once.** At 95% per behaviour, 0.95^25 is about 28%. Colour alone was right about 10% of the time.
3. **The spec came from the solution, not from a need.** rst `..`, latex `\endhead`, stacked colour codes, Decimal zeros and bytes decoding were mostly what the reference (or base tabulate) happened to do. Agents cannot guess implementation choices; every unstated one is a reviewer finding.
4. **"Better than base" and "identical to base" at the same time.** The footer had to handle colour better than base (base corrupts escape codes), while plain tables had to stay exactly like base (including base's odd ragged-header behaviour). Agents reuse base code: reuse it and inherit its bugs, change it and break "nothing changes".
5. **Layout is the output.** Every space, border and alignment is visible. Early tests compared whole tables, which turned cosmetic choices into hidden requirements; even later, "merged", "aligned" and "widened" stayed geometry judgments.
6. **Every existing option is an unwritten requirement.** showindex, maxcolwidths, multiline, colour codes, wide characters, header modes, ragged rows, empty tables, separating lines. Reviewers read "works with everything tabulate supports" into the text.
7. **"Not stated" was not free.** The FP panel grounds findings in base behaviour, not only in the description. Both FPs were unstated behaviour judged against base.
8. **The example did not test the trap.** The one colour example (red 3, `03d`) is exactly the case base's buggy code already gets right. Agents ran it, saw it pass, never found the bug. 0 of 8 fresh runs got colour right.

### 2.2 The gates pulled against each other
| Gate | Wanted | Effect on the others |
|---|---|---|
| TQ | every test grounded in a sentence | longer description |
| DQ | short (<=400 words) and human-sounding (AI detector) | fewer sentences, so less grounding |
| FP | every behaviour a passer shows pinned by a test | more tests |
| Pass rate | fewer, looser tests | more FP room |

With about 25 behaviours there is no point where all four are satisfied. Each fix for one gate handed another gate a new finding.

### 2.3 The reviewers sample
- SQ graded the **same** solution three times: three different findings (overlong footer, group validation, multiline titles).
- TQ was clean on v47, then showed partials again on the same tests after a rewording.
- DQ re-flagged an unchanged description.
A large surface guarantees each run finds a new corner. Small surface = stable gates.

### 2.4 Process (my failure)
- The platform gates were used as the debugger: one finding per round, no budget, no stop-loss.
- Clear stop signals were ignored: 0 clean passes in 73 runs by v43; SQ giving different findings on identical code; 0/8 fresh runs past the main blocker. Each was treated as "the next fix", never as "this task should be cut or dropped".

---

## 3. The FP panel: why it was the worst gate
1. **Asymmetric.** A passer must be right everywhere; the panel needs one fair counterexample ("One confirmed fair discriminator is sufficient").
2. **Judges against base.** Clean repo vs reference vs candidate. Anything a passer does differently on an existing path counts, stated or not.
3. **The feature forced agents into the risky code.** Adding footer/groups meant touching column counting and padding, which every plain table goes through.
4. **It probes actively.** Judges write their own tests on edges (ragged rows with short headers, no data rows). Judges disagreed; the adjudicator sided with evidence.
5. **Vicious circle.** Each FP -> new tests -> rarer passes -> more runs.

The two FPs:
| Version | Passer did | Ground used |
|---|---|---|
| v36b | bytes footer shown as `b'abc'`; Decimal precision lost | base data cells decode bytes and keep Decimal precision |
| v48 | padded every table to max(data, headers, footer, groups) on every call (ragged rows with short headers changed; extra header added a column); header line missing above the footer with no data rows | "If omitted/None nothing different will happen" + base output |

The v48 default-path change was caught by my pre-FP check before the panel (5724 of 23328 default calls differed). The empty-data finding was not; my sweep never compared tables with no rows.

---

## 4. Rules by gate

### DQ (description)
- Hard limit 400 words by `\w+`; budget <=385.
- Write it like a prompt to an agent: behaviours + 1-2 examples, no implementation steps, no laundry list (platform guidance).
- Claude drafts, the author rewrites fully in their own voice, Claude checks every fact against the tests and counts words.
- Never cut a long text down by deletion; rewrite short from the fact list (deletion residue reads as AI).
- Pick examples that expose the trap: a case the existing code gets WRONG, not one it already handles.
- Never promise more than the code keeps ("unchanged", "every", "exactly"). "Decimal values remain unchanged" would have been an SQ/FP hit; "keep all trailing zeros" was right.

### TQ (tests)
- Behaviour tests are permissive: assert where things go and what values show; exact strings only at value level.
- Never locate a row by fixed index (`out[-2]`); find it by content. Outer rules are cosmetic.
- Every test needs a sentence. After any wording change, re-map every test to a sentence.
- When a reviewer says a test over-demands the literal wording, relax it before the next batch. Runs written to an older description are not evidence a test is fair.
- Exact old output is fair for a stated "nothing changes" (TQ accepted it).
- Coverage suggestions and partials on a PASS are advisory; do not add tests for them.

### SQ (solution)
- Gate every behaviour change behind the new arguments.
- Before each upload: default-path differential (new args omitted AND passed as None, wide matrix, 0 differences).
- Crash-fuzz new value kinds x existing options x formats whenever the solution calls a base helper.
- Meet the repo's own gates (lint, type check, docstrings, signature test, changelog/docs if used).
- A medium on a PASS is not a blocker. If the score matters, close every known medium in one bundle and sweep sibling features first, then re-run SQ once.

### Nova runs
- Re-eval re-grades saved patches; description changes do not affect it. Predict it locally (apply patch to base, run tests) and verify once against the platform junit.
- Fresh runs are the only evidence about the current description.
- Use batches of 4 with a check between batches; send zips immediately.
- Measure the blocker rate (e.g. "colour fully right": 9/77 old runs, 0/8 fresh), not just pass/fail counts.

### FP panel
- No panel before the passer is swept against the reference:
  - default-path differential (args omitted / None),
  - crash fuzz,
  - the wide description suite,
  - degenerate tables (no rows, headers only, footer only, no headers) in every format,
  - every ambiguous sentence probed.
- If the default path differs on a stated "nothing changes", do not send; add a test.
- After an FP, turn every finding (including the "weaker" ones) into a test, then re-check the passer fails exactly those.

### Pre-FP check: targets in priority order
Run every target on every passer before any FP panel. Compare the passer against the reference (and against base where base has the same behaviour).

| # | Target | Why (evidence) | How | Do not send if |
|---|---|---|---|---|
| 1 | Default path: new arguments omitted AND passed as None | 98% of agents edited shared code; only 4/9 kept plain tables unchanged even with "nothing changes" in the text; v48 FP | `default_path.py`, base vs passer, wide matrix (ragged rows, extra headers, header modes, every format) | any difference |
| 2 | Degenerate tables: no rows, headers only, footer only, no headers, empty footer, in every format | v48 FP second finding (header line missing with no rows); my sweep had skipped these | probe each shape, passer vs reference | any difference on a stated rule |
| 3 | Values that collide with markup or with a base helper's bugs: colour codes (negative, float, digits inside the code, stacked codes) | 72% of agents corrupted colour codes the way base does; v27 FP | `probe.py` colour cases, plus the text's own example in every column type | escape codes changed or a number left unformatted |
| 4 | Every accepted input type: bytes, bool, None, Decimal, objects, tuples/generators | v36b FP (bytes shown as `b'abc'`, Decimal precision lost) | value probes, exact output | output differs from the base equivalent (data cells) |
| 5 | Existing options x new arguments: showindex, maxcolwidths, maxheadercolwidths, colalign, disable_numparse, missingval, multiline, colour codes, separating lines, header modes | SQ crash (maxcolwidths); panels probe pairs of features | `crash_fuzz.py`, then output diff vs reference on the same grid | any crash; any difference on a stated rule |
| 6 | Sibling features: the new element must do everything its existing equivalent does (titles vs header cells: multiline, colour, wide characters) | SQ found multiline titles; 7/82 agents broke borders on them | `group_sweep.py` | broken layout |
| 7 | Literal readings: each placement/strength word (after, before, raise, may, every) | agents implement wording literally (html "after thead" 9/9) | one probe per such sentence | the passer contradicts the literal reading AND the test allowed it |
| 8 | Open sentences (coin flips): list every behaviour the text leaves open | numeric strings split 41/82; Decimal + floatfmt; overlong footer | probe; record the passer's choice | its choice contradicts a plausible reading of a sentence: decide before the panel |
| 9 | Unstated bad input | 0/9 agents validate unless told | malformed input probes | anything other than a clean error or a sensible result (crash with an internal error) |
| 10 | Full product of optional parts: headers x rows x footer x groups x index, every format | v27 FP (separator dropped in groups + footer, no headers, no rows) | product grid, passer vs reference | any difference on a stated rule |

Verdict rule: a difference on a stated sentence = do not send; add a test. A difference on something unstated = compare with base; if base has an equivalent behaviour (for example data cells), the passer must match it, otherwise do not send.

---

## 5. Choosing the next task

### Five questions (any "no" = pick another task)
1. Can every behaviour be shown as `input -> exact value or error type`?
2. Can it be built without touching code every existing call goes through?
3. Can it be described in about 10 behaviours?
4. Do the tests run in seconds with no environment tricks?
5. Would an agent that runs the description's examples catch its own mistakes?

Tabulate failed 1, 2, 3 and 5.

### Good shapes
- New parse / convert / validate / compute function, or an opt-in option that changes a returned value or raises a typed error.
- Libraries backed by a spec (semver, JSON Pointer/Patch, glob, query languages) so the text can cite rules instead of listing quirks.
- Pure Python or Go, second-long test suites.

### Avoid
- Formatters, tables, terminal output, colour/escape codes, wide characters, multi-format output.
- Byte-identical compatibility with buggy legacy output.
- Big frameworks, async, network, concurrency, file systems.

### Vetted candidates (checked in this session)
| Repo | Suite | Verdict |
|---|---|---|
| python-semver | 450 passed, 0.6s | best: add version ranges |
| python-json-patch | 110 passed, 0.3s | good but maybe too easy: RFC 7396 merge patch |
| python-json-pointer | 31 passed, 0.2s | small |
| more-itertools | 767 passed, 49s | slow, features tend to be trivial |
| glom | 1 test failing on a clean checkout | avoid |
| jmespath.py | suite hung past 5 minutes | avoid |

### Plan sketch: python-semver version ranges
- Feature: new method, e.g. `Version.parse("1.4.2").match_range("^1.2.0 || >=3.0.0 <3.5.0") -> True`.
- About 8 behaviours: space = AND, `||` = OR, terms = anything `match()` accepts, `^` (with 0.x rules), `~`, `x`/`*` wildcards, invalid -> ValueError.
- FP design, decided up front:
  1. `match()` stays as it is; test that `match("^1.2.3")` still raises ValueError.
  2. Prereleases use the library's ordering; say it with the example `2.0.0-rc.1` matches `^1.2.3`. Never write "npm-style".
  3. `^0.2.3` -> <0.3.0 and `^0.0.3` -> <0.0.4 as examples (the trap naive code gets wrong).
  4. One grammar sentence; anything else raises ValueError; test only clearly invalid strings.
  5. Build metadata ignored, as in `compare()`.
  6. Fuzz range strings: only ValueError allowed.
- SQ gates in that repo: mypy, ruff, docstrings (tox); probably a changelog fragment and docs entry.
- Pre-FP: compare passer vs reference on thousands of random (version, range) pairs; every disagreement is checked against the text.

---

## 6. What worked (keep using)
| Tool / method | What it caught |
|---|---|
| Permissive behaviour tests (value-level exact only) | took near-passers from 20-100 failures to 1-2 |
| Default-path differential (23328 cases, omitted + None) | SQ regression; the v48 FP before the panel |
| Crash fuzz (171675 calls) | the maxcolwidths crash class (12015 crashes, one bug) |
| Mutation testing (fp_mutants.py, 34 mutants) | proved each stated behaviour is actually tested |
| Wide description suite (~3000 checks, one per sentence) | agent behaviours the tests missed |
| Blind reviewer agent with the 10-point FP gap prompt | 12 real test gaps, incl. the html over-demand |
| Replaying every run against new tests | showed which test changes cost near-passers |
| Blocker analysis across runs (who got colour right, how) | showed the example did not expose the trap |
| Group-title sweep vs header features (24624 cases, with/without wcwidth) | closed SQ's multiline-title gap and siblings |

## 7. Stop-loss rule (lesson 84)
- Agree a budget on day one (for example 15 versions or 40 agent runs).
- At each budget point, and whenever a gate gives a new finding on unchanged code or 8 fresh runs share one blocker, Claude states plainly: **continue, cut scope (name what), or drop**, with the evidence.
- Fixing the next thing is not a substitute for that call.

---

## 8. How agents behave (82 runs measured)

Data: 82 distinct agent patches (70 Nova, 12 Orion) over 9 description versions, re-graded on the final tests (v49) and probed in their own code for every behaviour that mattered (Appendix D, probe.py), joined with each transcript (description seen, tokens, requests, minutes, final message). 73 runs saw long texts (713-977 words, errors required); 9 saw the short text (367 words, examples for red 003 and `abc True`, "after thead", "you can throw ValueError").

| Behaviour | Long texts (73) | Short text (9) |
|---|---|---|
| colour: the text's own example (red 3, 03d) | 22 | **9** |
| colour: negative (-3) | 50 | **1** |
| colour: float (green 2, .2f) | 9 | 3 |
| colour: stacked codes (bold red) | 50 | **1** |
| colour: corrupts the escape code (base str.replace) | 53 | 6 |
| colour: all five right | 9 | 1 |
| bytes shown as `abc True` | 21 | **9** |
| Decimal 2.00 kept | 60 | 9 |
| html tfoot right after thead | 0 | **9** |
| raises on an overlong footer | **73** | **0** |
| groups refused on html | 56 | 9 |
| default path: ragged rows unchanged | 2 | 4 |
| default path: extra header unchanged | 56 | 7 |
| empty data: header line repeated | 58 | 6 |
| numeric string "3000" formatted | 38 | 3 |
| wrote its own test file | 51 | 8 |
| near (<=2 failing tests) | 4 | 3 |

All 82: reuse base `_format` in the new code 62 (76%); edit `_normalize_tabular_data`/`headers_pad` 80 (98%); Decimal + floatfmt applied 81; rst `..` 81; decimal alignment 80; multiline titles: 56 raise (old texts said so), 19 right, 7 broken; final message claims tests pass **82/82**; clean passes on the final tests **0/82**.

### 8.1 Patterns
- **A1 Literal compliance.** Agents implement the stated example and the stated words almost exactly: red 003 22/73 -> 9/9 once the example was in the text; `abc True` 21/73 -> 9/9; "after thead" -> 9/9 put tfoot before tbody; "raise" in the text -> 73/73 raise, "you can throw" -> 0/9 raise on unstated cases. Words like after, raise, may, every decide the implementation.
- **A2 No generalisation past the example.** With only "red 3" shown, negatives and stacked codes fell to 1/9 (50/73 when the long texts described colour codes generally). A variation that matters needs its own example, or a one-line rule plus an example the naive approach gets wrong.
- **A3 Agents reuse base helpers and inherit their bugs.** 76% call base `_format`; 72% corrupt colour codes exactly as base does for data cells. Before demanding a behaviour, run the base helper on the same inputs; if base is wrong there, the example must be the wrong case.
- **A4 Shared code always gets touched.** 98% edit the shared normalisation. Even with "If omitted/None nothing different" in the text, only 4/9 kept ragged tables unchanged. A sentence does not stop it; only a test does. Prefer features that need no shared code.
- **A5 Unstated validation does not happen.** 0/9 raise on an overlong footer when the text does not ask. SQ, however, asks the reference for validation. Decide errors up front: state them (and test) or accept SQ's medium.
- **A6 An open sentence is a coin flip.** Numeric strings: 41/82 formatted. Anything a sentence leaves open splits agents about 50/50; state and test it, or keep it out of the tests and the FP scope.
- **A7 Agent self-reports carry no signal.** 82/82 say their tests pass; 0/82 pass the hidden tests.
- **A8 Their own tests do not help.** 72% write tests; median failures 5 with or without. They test their own reading.
- **A9 Effort does not predict quality.** Near-passers: median 7.1M tokens, 80 requests; the rest 9.1M, 93. Colour-right runs explored more (9.5M, 99 requests): extra effort helps only on the trap.
- **A10 Nova and Orion behave the same** within noise (colour all-right 11% vs 17%, n=12).
- **A11 Agents agree with base on cosmetics** (rst `..` 99%, decimal alignment 98%, simple outer rules 98%). Failures cluster where base is buggy or where the text is read literally.

### 8.2 Pass-rate model
Pass rate is about the product of the per-behaviour success rates. Short text: colour all-right 0.11 x ragged default 0.44 x extra header 0.78 x empty-data line 0.67 x the rest about 1 = **about 2.5%**, which matches 0 clean passes in 9 short-text runs (and 1 FP pass in about 20 fresh runs overall). Use it before a task goes to rollouts: probe 8 runs, compute per-behaviour rates; any behaviour under 30% is a blocker; the product is the expected pass rate. If the product is under 5%, cut or redesign before spending more runs.

---

## 9. Independent analysis (Opus, blind)

The analyst's report, unedited. It saw only the raw data (82 anonymised runs: patches, transcripts, final-test failures, base repo, reference, final tests), none of sections 1-8.

### python-tabulate `footer` / `headergroups` task: analysis of 82 agent runs

#### Headline

- **0 of 82 runs pass the final hidden test file.** All 82 patches apply and import cleanly.
  - The best runs (run076, run077, run079, all V9) fail 2 of 549 cases, in 2 of 54 test functions.
  - The median run fails 28.5 cases and 5 test functions.
  - Pooled over all runs, 94.1% of cases pass (2,657 of 45,018 fail).
- **Two tests account for every failed run.** 76 runs fail `test_none_leaves_ragged_rows_unchanged`. The other 6 all fail `test_colour_codes_are_left_untouched`.
- **Most failures trace back to the description history, not to the agents.** I marked each (run, test) pair by whether the run's own description stated the tested behaviour:
  - Stated: 4.0% of pairs fail (152/3,803).
  - Unstated: 53.8% fail (318/591).
  - Contradicted by the description: 100% fail (34/34).
  - 31 of 82 runs pass every hidden test whose behaviour their own description stated. The stated/unstated mapping is my judgement (see §5).
- **Four hidden tests require the footer to format values better than tabulate's own data cells do.** In the reference, the same value renders differently in a data row and in the footer. The four tests, with the number of runs failing each:
  - `test_colour_codes_are_left_untouched`: 72 runs.
  - `test_coloured_footer_numbers_with_maxcolwidths`: 64.
  - `test_bytes_footer_cells_are_text`: 52.
  - `test_coloured_footer_numbers_use_the_column_formats[-1]`: 31.

  Runs that reused the library's existing helpers inherited its bugs. Every run that passed a coloured footer value into `_wrap_text_to_colwidths` fails (51/51), against 13/31 of the runs that did not (p=3.5e-10).
- **78 of 82 runs change tabulate's output for calls that don't use the new arguments.** This comes from a 6,000-call differential fuzz against the base library.
  - The repository's existing test suite catches none of these changes.
  - The hidden tests catch only two shapes of them.
  - 5 runs drop every data row when the headers outnumber the columns.

---

#### 1. Method

**Reproduction**
- I copied `env/base` to `work/trees/<run>` and applied each `solution.patch` with `patch -p1`. All 82 applied and imported without errors. The reference patch went into `trees/ref` the same way.
- I ran the hidden file (549 cases in 54 test functions) on every tree with pytest 9.1.1 under Python 3.11.
- My per-run failure sets match every `final_test_failures.txt` exactly (82/82). The reference passes 549/549. Base fails 549/549 because it rejects the new keyword arguments.

**Trajectories**
- The brief says trajectories have no tool calls, but they do. Each holds about 99 `exec` wrappers containing `exec_command` and `apply_patch` code, with truncated outputs.
- I parsed them with regexes (`traj.py`) for shell commands, pytest runs, ad-hoc Python probes, `apply_patch` counts and the last pytest summary. These counts are approximate.

**Behaviour extraction.** Every verdict comes from executing each run's code. I read patches only to explain mechanisms.
- `probes.py`: 384 targeted calls covering:
  - footer values and footer shapes;
  - degenerate tables and every table format;
  - groups and validation inputs;
  - combinations with existing options: showindex, maxcolwidths, maxheadercolwidths, colalign, disable_numparse, missingval, multiline cells, ANSI colour codes, separating lines, `keys`/`firstrow`/dict headers, numalign/stralign/colglobalalign, rowalign, preserve_whitespace, pretty, a caller-built `TableFormat`, and `simple_separated_format`.
- `probes_none.py`: 47 calls without the new arguments, aimed at known base quirks.
- `fuzz.py`: 6,000 seeded random calls across 36 formats and many data shapes and options. Each call ran with the new arguments omitted and with them set to None, and the output was hashed and compared with base.
- `probes_groups.py`: finds the title length at which each format starts widening columns.
- `trace_probe.py`: wraps library helpers such as `_format`, `_wrap_text_to_colwidths` and `_align_column`. It records which helpers receive marker footer values (bytes, coloured number, Decimal, bool, text, title).
- `consist_probe.py`: compares how a run renders the same value in a data row and in the footer.
- `classify.py`: turns probe output into 45 categorical behaviours per run.

**Other analyses**
- Static comparison of every top-level definition against base (`static.py`).
- Each tree run against the original base test suite and against its own test directory.
- Each run's own tests run against the reference.
- All 504 failing (run, test function) pairs assigned a root cause (`failure_root_causes.csv`).
- Statistics in pure Python because scipy isn't installed: Fisher exact tests, Spearman correlation, and permutation tests, including permutation within version.

---

#### 2. Finding 1: Description versions

There are nine distinct texts, named V1–V9 in time order. Within a version every run saw the same text. All runs got the same system prompt, whichever family.

| ver | hash | words | first run (UTC) | runs Nova/Orion | fail cases median [min–max] | fail test funcs median [min–max] | pass all stated tests | fuzz-identical | units failed by ≥50% of runs |
|---|---|---|---|---|---|---|---|---|---|
| V1 | bcbf726d | 958 | 2026-09-29 16:05 | 5/2 | 55 [21–58] | 8 [7–11] | 4/7 | 0/7 | none_unchanged, colour_codes, colour_maxcw, colour_fmt, bytes, other_formats |
| V2 | bddfbf71 | 885 | 2026-09-29 19:59 | 6/4 | 56 [14–84] | 8.5 [5–12] | 3/10 | 1/10 | same as V1 + bool |
| V3 | 796fc0f2 | 718 | 2026-09-30 13:16 | 6/1 | 31 [4–48] | 5 [3–8] | 2/7 | 0/7 | none_unchanged, colour_codes, colour_maxcw, bytes |
| V4 | c963d35c | 728 | 2026-09-30 14:37 | 5/2 | 32 [4–188] | 6 [3–18] | 2/7 | 0/7 | same as V3 + repeat_line |
| V5 | 72d81ffd | 749 | 2026-09-30 15:30 | 10/0 | 16.5 [5–63] | 5.5 [4–9] | 2/10 | 0/10 | same as V3 + decimal |
| V6 | 31c73539 | 710 | 2026-10-01 10:38 | 11/2 | 6 [4–213] | 4 [3–19] | 10/13 | 0/13 | none_unchanged, colour_codes, colour_maxcw, bytes |
| V7 | 53c0e5ca | 705 | 2026-10-01 12:03 | 4/1 | 3 [3–30] | 2 [2–9] | 4/5 | 0/5 | none_unchanged, bytes |
| V8 | ed2a6e6a | 722 | 2026-10-01 16:03 | 14/0 | 13.5 [3–118] | 4 [2–17] | 1/14 | 0/14 | none_unchanged, colour_codes, colour_maxcw, bytes |
| V9 | d2adb758 | 359 | 2026-10-02 19:59 | 9/0 | 4 [2–63] | 3 [2–5] | 3/9 | 3/9 | none_unchanged, colour_codes, colour_fmt |

"Units" are the 12 root-cause groups of tests defined in §8.

**What each version states** (quotes are exact):

- **V1** gives the full specification:
  - footer validation: "strings, bytes and non-iterables such as ints raise TypeError … More cells than columns raise ValueError; with no rows or headers, it sets the columns";
  - "maxcolwidths wraps footer cells like data cells";
  - html footer as a tfoot "after the tbody"; "That line is \hline in latex_longtable";
  - nested multi-level groups with boundary validation and exact exception classes, and multi-line titles;
  - **group markup for rst, html, latex, mediawiki, textile and moinmoin**; ValueError only for asciidoc, github, jira, orgtbl, pipe, presto, tsv and a caller-built `TableFormat`;
  - "Title widths ignore ANSI codes";
  - a CLI flag `-G/--headergroups` that exits with status 2.
- **V2** drops the CLI paragraph, the maxcolwidths sentence and the ANSI-title sentence. It adds:
  - "That line is \hline without \endhead in latex_longtable";
  - "Without headers, simple keeps its top and bottom lines.";
  - "so grid uses +---+ there".
- **V3** is a full rewrite.
  - Groups only in "simple, plain, psql, pretty and the grid and outline formats". Every other format "including a caller-created TableFormat, raises ValueError".
  - "A title with a \n or \r raises ValueError."
  - New sentences:
    - "When rows are present, headers beyond the longest row are trimmed from the end."
    - "Same formatting is used for an ANSI-colored number, with the color codes surrounding the formatted value."
    - "Other footer values, including booleans, are rendered as text."
    - "`simple` still draws its top and bottom borders if there are no headers."
    - The footer renders like the header row "even if there are no headers or data".
  - Keeps "With no rows or headers, the footer determines the number of columns."
- **V4** adds "With headers, `simple` draws no top border above the groups."
- **V5** adds:
  - "…trimmed from the end, even if every row is empty."
  - "Ragged rows keep every column up to the longest row, also with `maxcolwidths`."
  - Explicit simple-border sentences.
  - "an ANSI-colored number, negative ones included".
- **V6** removes the V5 additions. It also removes "With no rows or headers, the footer determines the number of columns.", the caller-supplied `TableFormat` clause, and "or data".
- **V7** removes "`simple` still draws its top and bottom borders if there are no headers." It adds "Digits inside the colour codes must stay untouched."
- **V8** adds "You get 1 space each side of a title, none of that thing in `simple` and `plain`."
- **V9** is an informal rewrite.
  - Drops all validation rules, multi-level groups, the newline rule and the trimming sentence.
  - Adds:
    - "If omitted/None nothing different will happen."
    - The example `[("Totals", 2)]`.
    - "Data/header row is left untouched."
    - "(you can throw ValueError)" for unsupported formats.
    - "If it's Decimal then it will keep all trailing zeros."
    - "red 3 with intfmt="03d" will be red 003".
    - `[b"abc", True]` appears as "abc True".
    - The html footer is "appended after thead as tfoot".
- **Final** (365 words, seen by no run) is a reworded V9. It adds "Same with -3, float values and multiple color codes", "Escaped in html", "Footer will not affect your data row…" and "Will appear below the thead".

**How versions scored.**
- V1/V2 runs fail most. They did what their text said in ways the final tests forbid: groups rendered in rst/html/latex and other formats, coloured numbers never formatted, booleans shown as numbers.
- V3–V8 runs cluster at 4–6 failing test functions.
- V9 is best, as the closest ancestor of the final description, with examples for bytes, Decimal and colour.
- Version quality is therefore confounded with closeness to the final tests. No version produced a passing run.

---

#### 3. Finding 2: Run × behaviour matrix

##### 3a. Aggregated table (behaviour × version)

Each cell counts runs whose behaviour matches the reference's category. [T] marks behaviours exercised by the hidden tests; U1 is only partly tested.

| behaviour | ref | V1 (7) | V2 (10) | V3 (7) | V4 (7) | V5 (10) | V6 (13) | V7 (5) | V8 (14) | V9 (9) | all 82 | most common non-reference value (count) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| U1 6,000-call fuzz identical to base (partly T) | identical | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 3 | 4 | changed on >50 calls (76) |
| U2 ragged rows + shorter headers, no new args [T] | base | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 1 | 4 | 6 | headers shifted right (72) |
| U3 headers longer than rows [T] | base | 1 | 2 | 7 | 7 | 7 | 13 | 5 | 14 | 7 | 63 | extra header shown (9) |
| U4 headers + all-empty rows `[[]]` | base | 4 | 5 | 0 | 2 | 0 | 2 | 0 | 2 | 8 | 23 | empty output (49) |
| U5 ragged rows + maxcolwidths | base | 0 | 1 | 1 | 1 | 0 | 2 | 1 | 4 | 9 | 19 | keeps all columns (63) |
| U6 coloured numbers in DATA cells | base | 7 | 10 | 7 | 7 | 8 | 11 | 3 | 10 | 7 | 70 | changed (12) |
| U7 bytes + ANSI data (base crashes) | crash | 7 | 10 | 7 | 7 | 9 | 12 | 3 | 12 | 7 | 74 | crash fixed (5) |
| F1 None footer cell [T] | empty | 7 | 10 | 6 | 7 | 10 | 13 | 5 | 14 | 9 | 81 | missingval used (1) |
| F2 intfmt / floatfmt per column type [T] | ok | 7 | 9 | 5 | 6 | 10 | 12 | 5 | 13 | 6 | 73 | differs (9) |
| F3 per-column format lists [T] | ok | 7 | 10 | 7 | 7 | 10 | 13 | 5 | 14 | 9 | 82 | – |
| F4 Decimal keeps trailing zeros [T] | keeps | 7 | 10 | 5 | 5 | 5 | 12 | 3 | 13 | 9 | 69 | converted with float() (13) |
| F5 True/False footer cells [T] | text | 4 | 5 | 7 | 7 | 10 | 13 | 5 | 14 | 9 | 74 | shown as 1.00/0.00 (7) |
| F6 bytes footer cells [T] | decoded | 3 | 2 | 2 | 1 | 2 | 4 | 2 | 5 | 9 | 30 | shown as `b'abc'` (49) |
| F7 other objects use str() [T] | str | 7 | 9 | 7 | 7 | 10 | 13 | 5 | 14 | 9 | 81 | crash (1) |
| F8 numbers in a text column as given [T] | as given | all | all | all | all | all | all | all | all | all | 82 | – |
| F9 numeric STRING "3000" in an int column | formatted | 0 | 0 | 5 | 4 | 8 | 7 | 4 | 10 | 3 | 41 | as-is (41) |
| F10 coloured int footer [T] | correct | 0 | 0 | 0 | 1 | 0 | 0 | 4 | 5 | 1 | 11 | str.replace corrupts codes (40) |
| F11 coloured float footer [T] | correct | 0 | 0 | 0 | 1 | 0 | 0 | 4 | 4 | 3 | 12 | str.replace corrupts codes (59) |
| F12 negative coloured number formatted [T] | yes | 0 | 0 | 6 | 6 | 10 | 11 | 5 | 12 | 1 | 51 | not formatted (31) |
| F13 coloured footer + maxcolwidths [T] | ok | 0 | 0 | 1 | 0 | 0 | 0 | 3 | 5 | 9 | 18 | crash in `_wrap_text_to_colwidths` (51) |
| S1 short footer padded on the left [T] | ok | all | all | all | all | all | all | all | all | all | 82 | – |
| S2 footer longer than the table | ValueError | 7 | 10 | 7 | 7 | 10 | 13 | 5 | 14 | 0 | 73 | accepted (9) |
| S3 footer="abc" (a string) | split into chars | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 4 | 4 | TypeError (73) |
| S4 footer=[] [T] | empty row | 7 | 10 | 7 | 5 | 10 | 13 | 5 | 14 | 9 | 80 | no row (2) |
| S5 simple, no headers: rule above footer [T] | rule | 7 | 10 | 5 | 6 | 10 | 12 | 5 | 13 | 9 | 77 | no rule (5) |
| S6 headers, no rows, footer: line repeated [T] | repeated | 7 | 7 | 4 | 2 | 10 | 11 | 5 | 12 | 6 | 64 | single line (17) |
| S7 footer only (no rows, no headers) | renders | 7 | 10 | 7 | 7 | 10 | 4 | 1 | 5 | 9 | 60 | ValueError (22) |
| S8 ragged rows + headers + footer | 2 columns | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 columns (80) |
| S9 `[[]]` rows + headers + footer | renders | 4 | 3 | 0 | 1 | 0 | 1 | 0 | 1 | 2 | 12 | ValueError (41) |
| FF1 html tfoot position [T] | after tbody | 7 | 10 | 7 | 7 | 10 | 13 | 5 | 14 | 0 | 73 | before tbody (9) |
| FF2 latex_longtable footer [T] | ok | 4 | 10 | 7 | 7 | 10 | 13 | 5 | 14 | 9 | 79 | second \endhead (3) |
| FF3 rst rule and ".." [T] | ok | 6 | 4 | 7 | 7 | 8 | 13 | 4 | 14 | 7 | 70 | None first cell not escaped (8) |
| FF4 footer byte-identical to reference in all 36 formats | 36 | 4 | 8 | 7 | 7 | 10 | 13 | 5 | 14 | 0 | 68 | 30–35 formats (14) |
| G1 groups render in all 19 required formats [T] | all 19 | 7 | 10 | 7 | 7 | 10 | 13 | 5 | 12 | 9 | 80 | "outline" missing (2) |
| G2 groups in the 17 other formats [T] | ValueError ×17 | 0 | 0 | 7 | 7 | 10 | 13 | 5 | 14 | 9 | 65 | 10 formats render the groups (17) |
| G3 groups + caller-built TableFormat | ValueError | 7 | 10 | 7 | 7 | 10 | 13 | 5 | 14 | 7 | 80 | TypeError (2) |
| G4 nested multi-level groups | rejected | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 9 | 9 | supported (73) |
| G5 title containing "\n" | renders | 7 | 10 | 0 | 0 | 0 | 0 | 0 | 0 | 9 | 26 | ValueError (56) |
| G6 span=True | TypeError | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | ValueError (82) |
| G7 align=5 | ValueError | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 9 | 10 | TypeError (72) |
| G8 grid widening threshold | same as ref | 7 | 7 | 4 | 5 | 5 | 11 | 2 | 13 | 6 | 60 | widens 4 chars earlier (13) |
| G9 simple widening threshold | same as ref | 7 | 9 | 5 | 6 | 7 | 13 | 4 | 14 | 9 | 74 | widens 2 chars earlier (7) |
| G10 groups without headers leave data unchanged [T] | ok | 7 | 9 | 6 | 6 | 9 | 12 | 5 | 12 | 9 | 75 | fails (7) |
| G11 wide title widens last column of group [T] | ok | 7 | 9 | 7 | 6 | 8 | 12 | 5 | 9 | 9 | 72 | fails (10) |
| G12 headergroups=[] | untitled row | 4 | 5 | 7 | 6 | 10 | 12 | 5 | 14 | 0 | 63 | no group row (13) |
| G13 ANSI title width ignores codes | ok | 7 | 10 | 7 | 6 | 10 | 12 | 5 | 13 | 8 | 78 | misaligned (4) |
| G14 groups + ragged rows + shorter headers | 2 columns | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3 columns (80) |
| G15 simple with headers: rule above group row | no rule | 7 | 10 | 6 | 7 | 10 | 13 | 5 | 14 | 9 | 81 | rule (1) |

##### 3b. Calls that don't use the new arguments: shared-code regressions

Only 4 runs are byte-identical to base on all 6,000 fuzz calls: run015 (V2), run076, run079 and run082 (all V9). Two runs differ on 20–21 calls; 76 differ on more than 50 (median 214). Passing None behaves exactly like omitting the arguments.

| Plain call (no new args) | Base output | Runs changing it | What they do | Hidden test catches it? |
|---|---|---|---|---|
| Ragged rows, headers shorter than the longest row | 3rd column dropped | **76** | 72 shift the headers right and show the 3rd column; 4 add an unnamed column | yes |
| Ragged rows + maxcolwidths | trailing cells dropped (a base bug) | 63 | keep all columns | no |
| Headers + all-empty rows `[[]]` | header row + rule | **59** | **49 return an empty string**; 10 add a trailing newline | no |
| Headers longer than the row width | extra header dropped | 19 | 9 show the extra header; **5 drop every data row**; **2 crash** (`max() arg is an empty sequence`); 3 drop the *first* header, so every column is mislabelled | yes |
| Coloured numbers in data cells | base formatting (buggy) | 12 | changed `_format`, so data cells now format differently | no |
| Bytes + ANSI data | base raises TypeError | 8 | 5 fix the crash; 3 crash differently | no |

**Where the changes live**
- 37 runs edited the shared `_normalize_tabular_data`; all 37 change ragged output.
- 41 runs changed the column count inside `tabulate()` without gating it on the new arguments.
- Other shared functions edited: `_align_column` (17 runs), `_format` (13), `_wrap_text_to_colwidths` (10), `_strip_ansi` (8), `_html_row_with_attrs` (8).
- The reference touches only `TableFormat`, `_table_formats`, `tabulate` and `_format_table`. No run extended `TableFormat`; the reference adds 4 fields to it.

##### 3c. Behaviours the hidden tests don't check

| Behaviour | How runs split | Reference | Likely grader complaint |
|---|---|---|---|
| footer="abc" | 73 TypeError (V1–V8 73/73); V9: 4 split into chars, 5 one cell | splits into chars | medium: runs follow V1–V8; the reference contradicts them |
| Footer longer than the table | 73 ValueError; 9 widen the table (V9) | ValueError | medium |
| Footer only (no rows, no headers) | 60 render; **22 raise ValueError** (22/32 in V6–V8) | renders | **high**: a valid call crashes |
| `[[]]` rows + headers + footer | 41 ValueError, 2 IndexError, 39 render | renders | high |
| Numeric string "3000" in an int column | **41 formatted / 41 left as-is** | formatted | high: an even split on an ambiguous point |
| Footer text + maxcolwidths | 54 wrap; 28 never wrap footers | wraps text but not numbers | medium |
| Nested multi-level groups | 73 supported; 9 reject | rejects | medium: the reference contradicts V1–V8 |
| Title containing "\n" | 56 ValueError; 26 render | renders | medium |
| span=True / span=2.0 / span="2" | 82/82 ValueError | TypeError | low: runs follow V1–V8 |
| align=5; groups with 1 or 4 items | 72 TypeError, 10 ValueError | ValueError | low |
| headergroups=[] | 63 untitled row, 13 no group row, 6 other | untitled row | low |
| Grouped simple table without headers | 48 keep top/bottom rules; **34 drop both** | keep | low (tests ignore rules) |
| Ragged rows + headers + footer, and groups with ragged rows | 80 show 3 columns | 2 columns | low: runs arguably better than the reference |
| HTML tfoot placement | 73 after tbody, 9 before | after | none (the test accepts both) |
| CLI `-G` | 7/7 V1 runs implement it (exit 2); 0/75 others | not implemented | none |
| Footer + existing options (showindex, maxheadercolwidths, disable_numparse, missingval lists, separating lines, keys/firstrow/dict input, alignments, rowalign, preserve_whitespace, pretty, custom TableFormat) | 75–82/82 byte-identical to the reference on each probe | – | low |

**Convergence**
- On 359 of 384 probes, at least half the runs produce output byte-identical to the reference.
- 68/82 runs match the reference's footer output exactly in all 36 formats. The 9 V9 runs differ only in html/unsafehtml, where they put the tfoot before the tbody.

---

#### 4. Finding 3: Failure analysis

##### 4a. Runs failing each hidden test

Version sizes: V1 7, V2 10, V3 7, V4 7, V5 10, V6 13, V7 5, V8 14, V9 9.

| Test | Runs | V1 | V2 | V3 | V4 | V5 | V6 | V7 | V8 | V9 |
|---|---|---|---|---|---|---|---|---|---|---|
| none_leaves_ragged_rows_unchanged | 76 | 7 | 9 | 7 | 7 | 10 | 13 | 5 | 13 | 5 |
| colour_codes_are_left_untouched | 72 | 7 | 10 | 7 | 6 | 10 | 13 | 1 | 10 | 8 |
| coloured_footer_numbers_with_maxcolwidths | 64 | 7 | 10 | 6 | 7 | 10 | 13 | 2 | 9 | 0 |
| bytes_footer_cells_are_text | 52 | 4 | 8 | 5 | 6 | 8 | 9 | 3 | 9 | 0 |
| coloured_footer_numbers_use_the_column_formats | 31 | 7 | 10 | 1 | 1 | 0 | 2 | 0 | 2 | 8 |
| line_under_header_repeated_above_footer_without_data | 22 | 3 | 4 | 3 | 5 | 0 | 2 | 0 | 2 | 3 |
| none_leaves_the_table_unchanged | 19 | 6 | 8 | 0 | 0 | 3 | 0 | 0 | 0 | 2 |
| other_formats_do_not_show_column_groups | 17 | 7 | 10 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| decimal_footer_keeps_its_trailing_zeros | 13 | 0 | 0 | 2 | 2 | 5 | 1 | 2 | 1 | 0 |
| coloured_footer_lines_up_with_its_column | 11 | 6 | 5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| rst_empty_first_footer_cell | 10 | 1 | 4 | 0 | 0 | 2 | 0 | 1 | 0 | 2 |
| group-layout tests (20 functions) | 16 | 0 | 2 | 1 | 2 | 3 | 2 | 1 | 5 | 0 |
| footer_true_and_false_are_text | 8 | 3 | 5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| footer_without_headers (and _looks_the_same) | 5 | 0 | 0 | 2 | 1 | 0 | 1 | 0 | 1 | 0 |
| line_under_header_repeated_above_footer | 5 | 3 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| others: empty footer 2, numbers aligned 2, index cell 1, None cell 1 run (2 tests), other values via str() 1, group+footer 1 | 8 | | | | | | | | | |

Thirteen test functions pass in all 82 runs:
- footer_is_one_row_after_the_data
- footer_is_styled_like_the_header_row
- footer_is_a_data_row_in_pipe_github_asciidoc
- html_footer_is_in_tfoot_with_td_cells
- html_footer_escapes_cells_unless_unsafe
- short_footer_is_padded_on_the_left
- footer_numbers_use_the_column_formats
- footer_widens_its_column (and the bordered-formats variant)
- group_forms_are_interchangeable
- numbers_in_a_text_column_stay_as_given
- short_footer_on_ragged_rows_fills_the_start
- html_tfoot_is_inside_the_table
- footer_ints_use_their_columns_intfmt

##### 4b. Root-cause clusters (all 504 failing run × test-function pairs)

Per-pair detail is in `failure_root_causes.csv`.

| Cluster | Pairs | Runs | Mechanism and evidence |
|---|---|---|---|
| **A. Changed default behaviour** | 95 | 76 | Column count taken from the longest row, or from max(rows, headers), in every call. 37 runs did this inside `_normalize_tabular_data`, the rest in `tabulate()`. Description text that invites it: V3–V8 "headers beyond the longest row are trimmed from the end"; V5 "Ragged rows keep every column"; V1/V2 "it sets the columns". 28 final messages advertise "trimming/ragged" as a feature. |
| **B1. Reused `_wrap_text_to_colwidths`** | 41 | 41 | The base helper calls `int('\x1b[31m3\x1b[0m')` and raises ValueError. Base data cells crash the same way. 51 runs pass coloured footers into it; all 51 fail. |
| **B2. Reused `_format`'s colour regex** | 40 | 20 | The regex `[0-9.]+` has no minus sign, and it keeps only the last escape code, so bold is lost. All 20 runs traced passing the coloured footer to `_format`. |
| **B3. Own code using `str.replace(visible, formatted)`** | 53 | 41 | Copies the idiom from base `_format`'s float branch. Output looks like `\x1b[0031m003`, `\x1b[000m` or `\x1b[31.00m31.00`. The pattern is present in 37/40 of these patches. |
| **B4. Bytes through base `_format` with a text column type** | 12 | 12 | Produces `b'abc'`, exactly as base renders bytes in a text data column. |
| **C. Followed text the final tests contradict** | 17 | 17 | V1/V2 runs render groups in rst/html/latex and similar formats, as their description told them to. |
| **D. Description silent or incomplete** | 58 | 22 | Coloured numbers never formatted (11 V1/V2 runs, 44 pairs); booleans shown as numbers through `_format` (8 runs); a second `\endhead` in latex_longtable (3 V1 runs). |
| **E. Own code: `float()` on Decimal, `str()` on bytes** | 53 | 50 | 13 runs convert Decimal with `float()` (all V3–V8). 40 runs apply `str()` or an f-string to bytes. |
| **F. Ambiguous text** | 41 | 33 | No repeated rule when there are no data rows (17 runs); no rule above the footer without headers (5); incomplete rst ".." handling (10); rst rule drawn with "=" (2). |
| **G. Group-layout bugs** | 86 | 16 | run004/run014 build the format list with `endswith("_outline")`, which rejects plain `outline` (15 failures each). run017/026/033/040/060 re-pad data cells when there are no headers. run007/045 widen rules and headers but not data cells. run012's merged cell is one character short. run059's merged width ignores padding (207 cases). run035's group row alters header widths. run066 crashes on groups + footer. run006, run019 and run047 have smaller widening errors. |
| **H. Other bugs** | 8 | 7 | `int('')` crash; missingval used for a None footer cell; crash formatting an arbitrary object; footer=[] treated as no footer (2 runs); misaligned decimal points (2 runs). |

Clusters A, B1–B4 and the bytes half of E reproduce semantics the library already has. Together they cover 281 of 504 pairs (56%), and A alone hits 76/82 runs. Group-layout bugs (G) are the only large cluster of plain agent mistakes, and they come from just 16 runs.

##### 4c. The reference treats data rows and the footer differently

These are actual reference outputs:
- `red("31")` in a float column with `floatfmt=".2f"`: the data row shows `\x1b[31.00m31.00` (corrupted); the footer shows `\x1b[31m31.00`.
- A coloured `-3000` with `intfmt=","`: data row `-3000`, footer `-3,000`.
- `b"abc"` in a text column: data row `b'abc'`, footer `abc`.
- A coloured data cell with maxcolwidths still crashes.

The consistency probe checks whether a run renders a value in its footer exactly as in a data cell:
- **Bytes:** all 49 consistent runs fail; 3 of 33 inconsistent runs fail.
- **Negative colour:** 31 of 41 consistent runs fail; 0 of 41 inconsistent runs fail. The 10 consistent runs that pass all modified `_format` itself.
- **The "31" colour trap:** 48 of 51 consistent runs fail.

---

#### 5. Finding 4: How the description text drives behaviour

These are Fisher exact tests. I ran about 35 comparisons, so treat anything with p > 0.0014 as **weak**.

| Text difference | Behaviour measured | k/n vs m/p | p |
|---|---|---|---|
| V1/V2 specify group markup for rst/html/latex/…; V3+ say other formats raise ValueError | Groups rendered in those formats | 17/17 vs 0/65 | 6e-18 |
| V1/V2 silent on coloured numbers; V3+ "Same formatting is used for an ANSI-colored number…" | Coloured numbers left unformatted | 11/17 vs 0/65 | 9e-10 |
| V3+ "Other footer values, including booleans, are rendered as text" | Booleans shown as 1.00 | 8/17 vs 0/65 | 7e-7 |
| V1 lacks "without \endhead" | Second `\endhead` emitted | 3/7 vs 0/75 | 4e-4 |
| V1's CLI paragraph (dropped in V2) | cli.py implements -G | 7/7 vs 0/75 | deterministic |
| V1 "maxcolwidths wraps footer cells like data cells" | Footer text wrapped | 7/7 (V1) vs 47/66 (V2–V8) vs 0/9 (V9) | – |
| V7/V8 "Digits inside the colour codes must stay untouched." | Coloured int footer exactly right | 9/19 vs 1/37 (V3–V6) | 1e-4 |
| same sentence | Coloured float footer exactly right | 8/19 vs 1/37 | 4e-4 |
| V5 "negative ones included" | Negative coloured numbers formatted | 10/10 vs 40/46 | 0.58 (no effect; already high) |
| V9 gives only an example ("red 3 → red 003"), no general rule | Reuses base `_format`'s colour regex | 8/9 vs 6/56 | 5e-6 |
| same | Negative coloured numbers formatted | 1/9 vs 50/56 | 5e-6 |
| V9 `[b"abc", True]` → "abc True" | Bytes decoded | 9/9 vs 21/73 | 5e-5 |
| V9 Decimal sentence | Decimal zeros kept | 9/9 vs 43/56 | 0.19 (weak) |
| V1/V2 silent on Decimal | Decimal zeros kept (via `_format` reuse) | 17/17 vs 43/56 | 0.03 (weak) |
| V9 "If omitted/None nothing different will happen." | Ragged rows unchanged | 4/9 vs 2/73 | 1e-3 |
| same | 6,000-call fuzz identical to base | 3/9 vs 1/73 | 4e-3 (weak) |
| same | Ragged rows + maxcolwidths unchanged | 9/9 vs 10/73 | 3e-7 |
| V3–V8 "headers beyond the longest row are trimmed from the end" | Long headers still dropped, as in base | 53/56 vs 3/17 (V1/V2) | 1e-9 |
| **same sentence, side effect** | `[[]]` rows + headers give EMPTY output | 49/56 vs 0/26 | 3e-15 |
| V6 removes "With no rows or headers, the footer determines the number of columns" | Footer-only table raises | 22/32 (V6–V8) vs 0/41 (V1–V5) | 3e-11 |
| V1–V8 validation sentences; V9 drops them | String footer TypeError / too-long footer ValueError / nested levels / TypeError for non-string align | 73/73, 73/73, 73/73, 72/73 vs 0/9 each | 3e-12 |
| V3–V8 "A title with a \n or \r raises ValueError" | Newline in a title raises | 56/56 vs 0/26 | 6e-22 |
| "tfoot after tbody" (V1–V8) vs "appended after thead" (V9) | tfoot placed after tbody | 73/73 vs 0/9 | 3e-12 |
| Simple-table borders: explicit "Without headers, simple keeps its top and bottom lines" (V2, V5) vs softer "still draws…" (V3, V4, V6) vs absent (V1, V7, V8, V9) | Rules kept on a grouped simple table without headers | 20/20 vs 17/27 vs 11/35 | 3e-7 (explicit vs absent) |
| "An empty level is interpreted as one untitled group" (V3–V8) vs V1/V2 wording vs absent (V9) | headergroups=[] gives an untitled row | 54/56 vs 9/17 vs 0/9 | 6e-5 |
| V8 "1 space each side of a title" | Grid widening threshold matches the reference | 13/14 vs 27/42 | 0.047 (weak) |
| V1/V2 "A number…" vs V3+ "numeric footer values…" | Numeric string footer formatted | 0/17 vs 38/56 | 3e-7 |
| **No relevant text change** (V3/V4 and V5 have identical footer text) | Empty-data rule repeated | 6/14 vs 10/10 | 6e-3 (weak, unexplained) |

**Stated vs unstated, per (run, test) pair**

| Status in the run's own description | Pairs | Fail rate |
|---|---|---|
| Stated | 3,803 | 4.0% |
| Unstated | 591 | 53.8% |
| Contradicted | 34 | 100% |

The stated/unstated difference has p ≈ 1e-196. 31/82 runs pass everything their own description stated. The mapping is my judgement and is saved in `stated_map.json`. Borderline calls, such as whether "colored number" covers negatives, move only a handful of pairs.

**Caveats**
- Versions are confounded with calendar time.
- Orion runs appear only in V1–V4, V6 and V7.
- n per version is 5–14.
- The identical-text pair in the last row (p=0.006) shows that version differences of this size can arise without any wording change.

---

#### 6. Finding 5: Implementation habits

**Reusing helpers is the norm, and it helps or hurts depending on the test.** This table is based on dynamic tracing.

| Helper receives the footer value | Reusers that fail | Non-reusers that fail | Test | p |
|---|---|---|---|---|
| `_format` gets a Decimal | 0/59 | 13/23 | Decimal zeros | 3e-9 (reuse **helps**) |
| `_format` gets a bool | 8/12 | 0/70 | True/False as text | 1e-8 |
| `_format` gets bytes | 12/12 | 40/70 | Bytes as text | 3e-3 |
| `_format` gets a coloured number | 23/33 | 8/49 | Negative coloured numbers | 2e-6 |
| `_wrap_text_to_colwidths` gets a coloured number | 51/51 | 13/31 | Colour + maxcolwidths | 4e-10 |

- All 82 runs align the footer through `_align_column`, and only 2 fail an alignment test.
- 80–82 runs reuse `_align_header` and `_build_simple_row` for group rows.

**Shared-code changes**
- 78/82 runs change default output (see §3b).
- Every run passes 305 of the 306 original tests. The one failure is the signature test, which is expected to change. **The existing suite detects none of the regressions.**
- 5 runs left the signature test failing and called it "legacy" or "stale" in their final message.

**Input validation**
- Patches have a median of 13 `raise TypeError/ValueError` statements (V9 runs: 7; reference: 9).
- Runs implemented exactly what their text specified. Exception types disagree with the reference for span=True (82/82 runs), non-string align (72) and malformed groups (72). No hidden test checks validation.

**Their own tests**
- 59/82 runs added tests: 51 new files and 8 edits to existing test files, median 9 tests.
- Having tests has no measurable effect: mean failing test functions is 6.29 with tests and 5.78 without, and the within-version correlation is +0.11 (p=0.37).
- I ran all 602 agent-written tests against the reference. **175 (29%) fail, and not one run's test set fully passes.**

| Why the reference fails the agent test | Tests |
|---|---|
| Reference raises ValueError (mostly on nested levels) | 111 |
| Reference raises TypeError (span types) | 28 |
| Reference doesn't raise the expected error | 16 |
| Output mismatch (footer-only tables, ragged rows, `[[]]` trimming) | 20 |

The agents' tests encode their descriptions faithfully; the reference doesn't implement V1–V8.

**Testing activity.** Median 9 pytest runs (range 4–17) and 23 ad-hoc Python probes per run. Neither predicts outcome within a version.

**Final messages vs reality**
- Median length is 39 words.
- All 82 report a passing count, such as "323 passed, 60 skipped". I reproduced every count within ±2; the agents' environment also collected 17 doctests.
- 52 say tests were added, which is true in every case.
- 28 advertise trimming or ragged handling as a feature.
- 1 mentions a limitation. None mentions any risk to existing behaviour.
- **82/82 claim success; 0/82 pass.**

**Patch similarity.** Patches are not near-duplicates: the maximum Jaccard overlap of added lines is 0.28 and the median 0.14. But error strings are shared widely:
- "headergroups must be an iterable of groups": 72 runs.
- "footer has more cells than the table has columns": 62 runs.
- "header group spans must be positive integers": 58 runs.

Nova–Orion similarity (0.138) equals within-family similarity (0.141 and 0.148).

---

#### 7. Finding 6: What predicts fewer failures

The outcome is the number of failing test functions. "Within version" means ranks normalised inside each version, with a permutation test that only shuffles within versions.

| Predictor | ρ (all runs) | p | ρ within version | p |
|---|---|---|---|---|
| Description words (one value per version) | +0.62 | <1e-3 | – | – |
| Fuzz calls whose output changed | +0.48 | <1e-3 | **+0.25** | **0.036** |
| Patch lines added | +0.45 | <1e-3 | −0.03 | 0.78 |
| Requests / tool calls | +0.37 | 1e-3 | −0.06 | 0.58 |
| Prompt / completion / reasoning tokens | +0.34 | ≤3e-3 | −0.11 / −0.15 / −0.11 | ≥0.2 |
| apply_patch calls | +0.33 | 2e-3 | −0.07 | 0.56 |
| Shared definitions modified | +0.28 | 0.014 | +0.01 | 0.95 |
| pytest runs | +0.27 | 0.011 | +0.10 | 0.39 |
| Ad-hoc probes | +0.14 | 0.22 | −0.08 | 0.51 |
| Own tests (any / count) | 0.00 / +0.09 | ≥0.4 | +0.11 / +0.01 | ≥0.37 |
| Validation raises | +0.15 | 0.19 | −0.05 | 0.69 |
| Orion family | +0.13 | 0.24 | −0.12 | 0.30 |
| Wall-clock minutes | +0.04 | 0.71 | −0.08 | 0.52 |

- All the effort and size correlations come from the version: longer texts (V1/V2) produced more work and more failures. Within a version, effort predicts nothing.
- The only within-version predictor is how much default behaviour a run changed.
- Orion used about twice Nova's prompt tokens in V1–V4 (17–22M vs 8–12M) but the same in V6/V7. Within a version, its failure medians match Nova's (V1 8 vs 9, V2 8 vs 8.5, V4 6 vs 7). There are too few Orion runs (12) to separate the two families.

---

#### 8. Finding 7: Pass-rate model and early prediction

**Units.** I grouped the 54 test functions into 12 root-cause units (`units.json`). The model is P(pass) = the product of each unit's pass rate.

| Unit | Pass rate |
|---|---|
| none_unchanged | 0.073 |
| colour_codes | 0.122 |
| colour_maxcw | 0.220 |
| bytes | 0.366 |
| colour_fmt | 0.622 |
| repeat_line | 0.732 |
| other_formats | 0.793 |
| group_layout | 0.805 |
| decimal | 0.841 |
| footer_misc | 0.866 |
| rst | 0.878 |
| bool | 0.902 |

**Pooled model.** P(pass) = 1.2e-4, or 0.010 expected passing runs; I observed 0. I checked it on all 4,095 subsets of units ("how many runs pass every unit in S"):
- MAE 1.54 runs, bias +0.97.
- It underestimates rare joint passes: when it predicts fewer than 1 run, the observed mean is 0.91.
- Failures are positively correlated: joint passes occur up to 3.2× more often than independence predicts (colour_codes with colour_maxcw).
- The number of failed units per run is over-dispersed: variance 3.02 vs 1.78 predicted.

**Version-stratified model (recommended).** Estimate each unit's rate within a version, smooth by adding 0.5, then sum over versions. It predicts 0.061 passing runs against 0 observed. Over the 4,095 subsets the bias is +0.30 and the MAE 1.19.

| Predicted passing runs | Mean predicted | Mean observed |
|---|---|---|
| fewer than 1 | 0.48 | 0.08 |
| 1–5 | 2.57 | 2.64 |
| 5–20 | 9.3 | 10.05 |
| 20–50 | 31.6 | 35.9 |

Failed units per run, observed vs predicted:

| Failed units | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 |
|---|---|---|---|---|---|---|---|---|
| Observed | 8 | 12 | 17 | 21 | 9 | 10 | 2 | 3 |
| Predicted | 5.2 | 12.7 | 20.1 | 17.4 | 11.7 | 7.8 | 4.2 | 1.5 |

**What-if: runs passing everything else after removing trap units.**

| Units removed | Runs passing the rest |
|---|---|
| none_unchanged | 0 |
| + colour_codes | 0 |
| + colour_maxcw | 5 |
| + bytes | 16 |
| + colour_fmt | 25 (30%) |

**Early prediction for a new task**
- Take the first k runs **of one description version**. Estimate the pass rate as (passes + 0.5)/(k + 1), or as the product of unit rates, or bound it by the lowest unit rate.
- I validated this on 287 counterfactual suites (subsets of units with true pass rates from 0 to 0.9), sampling k runs from one version at a time:

| k | MAE | Recall for "true pass rate < 10%" (estimate < 0.15) | False alarms |
|---|---|---|---|
| 4 | 0.11 | 0.99 | 0.11 |
| 6 | 0.08 | 0.99 | 0.05 |
| 8 | 0.06 | 0.98 | 0.02 |

- Pooling the first k runs chronologically across description changes fails: MAE 0.22 and a 70% false-alarm rate.
- On the real suite, the first 4 runs of every version give a bound of at most 0.10, with 1–6 "wall" tests (tests failing in at least k−1 of k runs). The true rate is 0.

**Smallest useful probe set**
1. **Hidden-test walls.** Two tests (ragged-unchanged, colour codes) explain all 82 failing runs.
2. **A fuzz of plain calls against the base library.** Fuzz-identical runs pass the ragged test 4/4; changed runs pass it 2/78.
3. **A consistency probe: new path vs existing path on the same values.** Where the tests require a difference, consistent runs fail 94–100% of the time.
4. **Cluster the outputs of failing runs.** When many failing runs produce the *same* output (44 identical `b'abc'`; 51 identical crashes), suspect the spec or the test rather than the agents.

Probes 2–4 need no hidden tests, and here they flag all four wall units within 4–8 runs.

---

#### 9. Finding 9: Surprises

1. **The reference contradicts the pre-V9 descriptions on behaviour they spelled out:**
   - It rejects nested multi-level groups (73/73 V1–V8 runs support them).
   - It renders newline titles (56/56 V3–V8 runs raise).
   - It raises TypeError for span=True (82/82 runs raise ValueError).
   - It splits a string footer into characters (73/73 raise TypeError).

   None of this is tested. No run's own test set passes on the reference.
2. **The reference formats the same value differently in data rows and the footer** (§4c), and four tests enforce that difference.
3. **`test_coloured_footer_numbers_with_maxcolwidths` is passed only by runs that never wrap footers** (18/18). All 54 runs that wrap footer text fail it, including the V1 runs that followed "maxcolwidths wraps footer cells like data cells". The reference does wrap text footers, but nothing tests that.
4. **Other passes for the wrong reason:**
   - The second assertion of `numbers_in_a_text_column_stay_as_given` passes in the 11 V1/V2 runs because they never format coloured numbers anywhere.
   - `short_footer_on_ragged_rows_fills_the_start` passes 82/82, including the 76 runs that changed ragged handling (that test uses no headers).
   - `none_leaves_the_table_unchanged` passes 63 runs, 49 of which blank `tabulate([[]], headers=[...])` entirely.
5. **Silent catastrophic regressions.** run019, run068, run070, run073 and run080 print only the header and rule, with no data rows, for any plain call whose headers outnumber the columns. Two other runs crash on it and three mislabel every column. The existing suite passes for all of them.
6. **Most runs agree with each other but not with the reference** on 23 probes:

| Input | Runs | What they do | Reference |
|---|---|---|---|
| Bytes footer | 44 | `b'abc'` | `abc` |
| Coloured float | 39 | corrupted escape codes | correct |
| Colour + maxcolwidths | 51 | identical crash | formatted |
| Ragged rows + headers + footer | 77 | 3 columns | 2 columns |
| Numeric string footer | 38 | left unformatted | formatted |
| `[[]]` rows + footer | 41 | ValueError | renders |
| Nested levels | 68 | supported | rejected |
| span=True | 82 | ValueError | TypeError |
| Newline title | 56 | ValueError | renders |

7. **Identical text, different behaviour.** V3/V4 and V5 have the same footer wording but differ 6/14 vs 10/10 (p=0.006) on the empty-data rule.
8. **Effort correlates positively with failure** (ρ +0.34 to +0.45), entirely because of the version.
9. **Grouped simple tables.** 34 runs drop the top and bottom rules of grouped `simple` tables without headers, and 7/9 V9 runs drop the rule between the group row and the header. The tests ignore rules, so this goes unnoticed.

---

#### 10. Top 10 rules for task authors

1. **Write the hidden tests from the same text the agents see, and freeze both before collecting runs.** Stated behaviour fails 4.0% of the time, unstated 53.8%, contradicted 100%. 31/82 runs pass everything they were told; 0/82 pass the final tests.
2. **If the new code must behave differently from an existing helper, say so with an example, or don't test it.**
   - Reusing `_wrap_text_to_colwidths` fails 51/51 runs; `_format` with bytes fails 12/12.
   - The V9 bytes example raised correct decoding from 21/73 to 9/9.
   - The "Digits inside the colour codes" sentence raised correct colour handling from 1/37 to 9/19.
3. **Require "calls without the new arguments produce byte-identical output", and test it with a differential fuzz, not two hand-picked shapes.** 78/82 runs changed default output; the repo suite caught 0; the hidden tests caught 2 shapes and missed 49 blanked tables. Even V9's "nothing different" sentence only moved ragged preservation from 2/73 to 4/9.
4. **Don't write sentences that invite rewriting shared normalisation.** If the behaviour is needed, scope it to the new arguments. "Headers beyond the longest row are trimmed" protected one case (53/56 vs 3/17) and broke another (`[[]]` output went empty in 49/56 vs 0/26).
5. **Delete specification you won't test.** V1–V8 validation, multi-level groups, CLI and newline rules were implemented by nearly every run that saw them (73/73, 73/73, 7/7, 56/56). The reference contradicts them, and V1/V2 patches are larger (median ~580 added lines vs ~390 for V3–V8 and ~300 for V9). V1/V2, the longest texts, fail most: median 8–8.5 test functions vs 3 for V9.
6. **Pin degenerate inputs with explicit examples:** no rows, footer only, `[[]]`, ragged rows + headers, numeric strings.
   - Dropping one sentence turned footer-only tables into crashes (0/41 → 22/32).
   - Numeric strings split 41/41.
   - 80/82 runs differ from the reference on ragged rows + headers + footer.
7. **Make tolerant tests impossible to pass by omission.** The colour + maxcolwidths test is passed only by runs that never wrap footers (18/18). Pair it with a positive check that wrapping happened. The tfoot-order tolerance is an example done right: 73 runs put it after the tbody, 9 before, and both are valid.
8. **Check the reference against the description and against the agents' own tests before grading.** 175 of 602 agent tests fail on the reference, and no run's test set passes. Each disagreement marks a spec/reference conflict.
9. **Estimate pass rates per description version, from 6–8 runs.** Same-version MAE is 0.06–0.08, with 0.98–0.99 recall for suites below 10%; pooling across versions raises false alarms to 70%. Treat any test failing in at least k−1 of k runs as a wall, and cluster its failing outputs: identical outputs (44 `b'abc'`, 51 identical crashes) mean a spec or test problem.
10. **Don't treat effort, self-tests or final messages as quality signals.** Within a version, all of them correlate with outcome at |ρ| ≤ 0.15. 82/82 final messages claim success. Use behaviour probes instead.

#### 11. Five things a task author would get wrong without this data

1. **Reading 0% as "the agents can't do this".** 31/82 runs are fully correct under their own description, and removing five trap units gives 25/82 passes. The 0% comes from tests written after the descriptions and from tests that demand better-than-library behaviour.
2. **Assuming reuse of existing helpers is safe or rewarded.** Reuse drove outcomes in both directions: Decimal had 0/59 failures with reuse, colour + maxcolwidths had 51/51 failures with reuse. The reference itself is inconsistent between its data and footer paths.
3. **Assuming "None leaves the table unchanged" is easy and well covered.** 78/82 runs changed default output and 10 dropped rows, crashed or mislabelled columns. Neither the existing suite nor the hidden tests catch most of it.
4. **Assuming more detailed specs help.** Detail that agents follow but nobody tests, or that the reference contradicts, costs effort and creates conflicts. V1/V2 scored worst, and deleting single sentences flipped untested behaviour (footer-only crashes went from 0/41 to 22/32).
5. **Judging description edits from 5–14 runs, or pooling across versions.** Identical text produced a p=0.006 difference, and chronological pooling gives MAE 0.22 on early estimates.

#### 12. Limitations

- One task, 82 runs, 5–14 per version. Orion has only 12 runs and none in V5, V8 or V9. Versions are confounded with calendar time and with closeness to the final description.
- Only the final hidden test file is available. The tests these runs were originally graded against are unknown, and the final description was written after all of them.
- The stated/unstated/contradicted mapping is my judgement.
- Root-cause attribution has gaps. Tracing only sees calls to module-level helpers, the "copied idiom" verdict rests on a static pattern found in 37/40 patches, and group-layout causes are summarised per run.
- The fuzz corpus comes from my own generator: 6,000 calls, no numpy or pandas inputs, and no wide-character tests because wcwidth isn't installed.
- I ran Python 3.11 and pytest 9.1.1; the agents ran Python 3.12 with doctests collected.
- Trajectory parsing is regex-based and tool outputs are truncated, so activity counts are approximate.
- I ran about 35 Fisher tests; effects with p > 0.0014 are marked weak.

---

#### Appendix A: Per-run table

Column codes:
- **fail cases / fail funcs**: hidden-test cases and test functions failed.
- **fuzz Δ**: plain calls (of 6,000) whose output differs from base.
- **rag** (ragged rows): B base · S headers shifted · X extra column.
- **long** (headers longer than data): B base · E extra header shown · D data rows dropped · C crash · M first header dropped.
- **[[]]**: B base · E empty output · O other.
- **cInt / cFlt** (coloured int / float footer): C correct · R str.replace corrupts codes · G base `_format` regex · N not formatted.
- **neg**: negative coloured number formatted, Y or N.
- **cMaxW** (colour + maxcolwidths): ok · X crash · W wrong output.
- **bytes**: D decoded · R `b''` shown · P partial.
- **dec**: K zeros kept · F converted with float().
- **bool**: T text · N number.
- **eData** (empty-data footer): R rule repeated · S single rule · O other.
- **grpOth** (groups in other formats): VE ValueError · RN rendered in 10 formats.
- **multi** (nested levels): S supported · R rejected.
- **strF** (string footer): TE TypeError · ch characters · 1c one cell.
- **fOnly** (footer-only table): ok · VE ValueError.
- **tfoot**: A after tbody · B before.
- **own tests**: number of tests the run added. **min**: wall-clock minutes.

| run | ver | agent | fail cases | fail funcs | fuzz Δ | rag | long | [[]] | cInt | cFlt | neg | cMaxW | bytes | dec | bool | eData | grpOth | multi | strF | fOnly | tfoot | own tests | prompt Mtok | min |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| run072 | V1 | O | 21 | 8 | 312 | S | B | B | N | N | N | X | R | K | N | R | RN | S | TE | ok | A | 22 | 17.7 | 15 |
| run067 | V1 | N | 53 | 8 | 615 | S | E | O | G | R | N | X | D | K | T | R | RN | S | TE | ok | A | 0 | 11.9 | 11 |
| run069 | V1 | N | 54 | 7 | 574 | S | E | O | N | N | N | X | D | K | T | R | RN | S | TE | ok | A | 19 | 13.4 | 14 |
| run073 | V1 | O | 55 | 8 | 578 | S | D | B | N | N | N | X | R | K | T | R | RN | S | TE | ok | A | 0 | 15.9 | 18 |
| run070 | V1 | N | 57 | 9 | 585 | S | D | B | N | N | N | X | R | K | N | R | RN | S | TE | ok | A | 5 | 11.3 | 13 |
| run068 | V1 | N | 58 | 11 | 603 | S | D | B | N | N | N | X | R | K | T | R | RN | S | TE | ok | A | 7 | 13.4 | 12 |
| run071 | V1 | N | 58 | 10 | 592 | S | E | O | N | N | N | X | D | K | N | R | RN | S | TE | ok | A | 0 | 8.2 | 13 |
| run015 | V2 | N | 14 | 5 | 0 | B | B | B | G | R | N | X | P | K | T | R | RN | S | TE | ok | A | 16 | 11.9 | 11 |
| run020 | V2 | N | 20 | 8 | 186 | X | B | B | N | N | N | W | R | K | T | R | RN | S | TE | ok | A | 4 | 8.6 | 10 |
| run023 | V2 | O | 53 | 8 | 597 | S | E | O | G | R | N | X | R | K | T | R | RN | S | TE | ok | A | 0 | 18.2 | 17 |
| run022 | V2 | O | 54 | 8 | 596 | S | C | B | G | R | N | X | R | K | N | R | RN | S | TE | ok | A | 27 | 19.9 | 17 |
| run019 | V2 | N | 56 | 11 | 586 | S | D | B | G | R | N | X | R | K | T | R | RN | S | TE | ok | A | 0 | 11.7 | 13 |
| run021 | V2 | O | 56 | 8 | 621 | S | E | O | N | N | N | X | D | K | N | R | RN | S | TE | ok | A | 24 | 23.4 | 16 |
| run016 | V2 | N | 57 | 11 | 600 | S | E | O | G | R | N | X | R | K | N | O | RN | S | TE | ok | A | 7 | 9.8 | 11 |
| run017 | V2 | N | 75 | 12 | 597 | S | E | O | N | N | N | X | R | K | T | R | RN | S | TE | ok | A | 12 | 9.4 | 10 |
| run018 | V2 | N | 81 | 9 | 596 | S | C | B | N | N | N | X | D | K | N | S | RN | S | TE | ok | A | 5 | 10.3 | 10 |
| run024 | V2 | O | 84 | 11 | 614 | S | E | O | N | N | N | W | R | K | N | S | RN | S | TE | ok | A | 11 | 24.1 | 17 |
| run030 | V3 | N | 4 | 3 | 235 | S | B | E | R | R | Y | X | D | K | T | R | VE | S | TE | ok | A | 0 | 10.0 | 11 |
| run028 | V3 | N | 9 | 4 | 235 | S | B | E | R | R | Y | W | D | F | T | R | VE | S | TE | ok | A | 0 | 9.3 | 13 |
| run027 | V3 | N | 31 | 5 | 204 | S | B | E | R | R | Y | X | R | K | T | S | VE | S | TE | ok | A | 9 | 7.3 | 12 |
| run029 | V3 | N | 31 | 5 | 230 | S | B | E | R | R | Y | X | R | K | T | S | VE | S | TE | ok | A | 0 | 7.4 | 10 |
| run031 | V3 | O | 34 | 8 | 234 | S | B | E | R | R | Y | W | R | K | T | R | VE | S | TE | ok | A | 0 | 17.5 | 16 |
| run025 | V3 | N | 37 | 7 | 230 | S | B | E | R | R | Y | X | R | F | T | R | VE | S | TE | ok | A | 7 | 8.8 | 12 |
| run026 | V3 | N | 48 | 6 | 204 | S | B | E | G | R | N | ok | R | K | T | S | VE | S | TE | ok | A | 10 | 8.8 | 10 |
| run032 | V4 | N | 4 | 3 | 158 | S | B | E | R | R | Y | W | D | K | T | R | VE | S | TE | ok | A | 0 | 8.0 | 10 |
| run034 | V4 | N | 6 | 5 | 218 | S | B | B | G | R | N | X | R | K | T | R | VE | S | TE | ok | A | 8 | 9.3 | 11 |
| run037 | V4 | O | 30 | 4 | 204 | S | B | E | C | C | Y | X | R | K | T | S | VE | S | TE | ok | A | 7 | 20.9 | 18 |
| run038 | V4 | O | 32 | 6 | 204 | S | B | E | R | R | Y | X | R | K | T | S | VE | S | TE | ok | A | 21 | 16.0 | 15 |
| run033 | V4 | N | 34 | 7 | 204 | S | B | E | R | R | Y | X | R | K | T | S | VE | S | TE | ok | A | 0 | 6.9 | 10 |
| run036 | V4 | N | 63 | 8 | 179 | S | B | B | R | R | Y | X | R | F | T | S | VE | S | TE | ok | A | 9 | 9.2 | 12 |
| run035 | V4 | N | 188 | 18 | 230 | S | B | E | R | R | Y | W | R | F | T | S | VE | S | TE | ok | A | 16 | 7.0 | 10 |
| run044 | V5 | N | 5 | 4 | 237 | S | B | E | R | R | Y | X | R | K | T | R | VE | S | TE | ok | A | 0 | 10.6 | 12 |
| run048 | V5 | N | 6 | 5 | 251 | S | B | E | R | R | Y | X | R | K | T | R | VE | S | TE | ok | A | 0 | 10.8 | 13 |
| run047 | V5 | N | 8 | 7 | 255 | S | B | E | R | R | Y | X | R | K | T | R | VE | S | TE | ok | A | 0 | 9.2 | 11 |
| run046 | V5 | N | 10 | 5 | 233 | S | B | E | R | R | Y | X | R | F | T | R | VE | S | TE | ok | A | 10 | 8.1 | 10 |
| run039 | V5 | N | 11 | 6 | 204 | S | B | E | R | R | Y | X | R | F | T | R | VE | S | TE | ok | A | 0 | 6.2 | 9 |
| run040 | V5 | N | 22 | 5 | 233 | S | B | E | R | R | Y | X | R | K | T | R | VE | S | TE | ok | A | 7 | 6.7 | 8 |
| run041 | V5 | N | 40 | 4 | 592 | S | M | E | R | R | Y | X | D | K | T | R | VE | S | TE | ok | A | 15 | 11.0 | 12 |
| run042 | V5 | N | 46 | 6 | 615 | S | M | E | R | R | Y | X | R | F | T | R | VE | S | TE | ok | A | 5 | 9.8 | 11 |
| run043 | V5 | N | 46 | 6 | 724 | S | M | E | R | R | Y | X | R | F | T | R | VE | S | TE | ok | A | 10 | 12.2 | 12 |
| run045 | V5 | N | 63 | 9 | 209 | S | B | E | R | R | Y | X | D | F | T | R | VE | S | TE | ok | A | 7 | 8.2 | 9 |
| run055 | V6 | N | 4 | 3 | 224 | S | B | E | R | R | Y | X | D | K | T | R | VE | S | TE | VE | A | 0 | 8.5 | 12 |
| run061 | V6 | O | 4 | 3 | 158 | S | B | E | R | R | Y | W | D | K | T | R | VE | S | TE | VE | A | 9 | 8.3 | 13 |
| run051 | V6 | N | 5 | 4 | 288 | S | B | E | R | R | Y | X | R | K | T | R | VE | S | TE | ok | A | 10 | 8.0 | 13 |
| run053 | V6 | N | 5 | 4 | 235 | S | B | E | R | R | Y | X | R | K | T | R | VE | S | TE | VE | A | 0 | 8.4 | 13 |
| run054 | V6 | N | 5 | 4 | 262 | S | B | E | R | R | Y | X | R | K | T | R | VE | S | TE | VE | A | 0 | 6.6 | 11 |
| run057 | V6 | N | 5 | 4 | 187 | S | B | B | R | R | Y | X | R | K | T | R | VE | S | TE | VE | A | 17 | 9.0 | 13 |
| run058 | V6 | N | 6 | 5 | 230 | S | B | E | G | R | N | X | R | K | T | R | VE | S | TE | ok | A | 8 | 11.6 | 15 |
| run056 | V6 | N | 10 | 5 | 204 | S | B | E | R | R | Y | W | R | F | T | R | VE | S | TE | ok | A | 0 | 7.8 | 13 |
| run060 | V6 | O | 22 | 5 | 204 | S | B | E | R | R | Y | W | R | K | T | R | VE | S | TE | ok | A | 10 | 7.5 | 12 |
| run049 | V6 | N | 30 | 4 | 159 | S | B | E | R | R | Y | W | D | K | T | S | VE | S | TE | VE | A | 14 | 10.8 | 14 |
| run052 | V6 | N | 30 | 4 | 230 | S | B | B | R | R | Y | X | D | K | T | S | VE | S | TE | VE | A | 7 | 6.4 | 12 |
| run050 | V6 | N | 32 | 6 | 204 | S | B | E | R | R | Y | W | R | K | T | R | VE | S | TE | VE | A | 5 | 6.6 | 12 |
| run059 | V6 | N | 213 | 19 | 230 | S | B | E | G | R | N | X | R | K | T | R | VE | S | TE | VE | A | 13 | 10.8 | 17 |
| run063 | V7 | N | 3 | 2 | 208 | S | B | E | C | C | Y | ok | P | K | T | R | VE | S | TE | VE | A | 10 | 6.9 | 14 |
| run064 | V7 | O | 3 | 2 | 226 | S | B | E | C | C | Y | ok | R | K | T | R | VE | S | TE | VE | A | 8 | 8.0 | 14 |
| run065 | V7 | N | 3 | 2 | 226 | S | B | E | C | C | Y | ok | R | K | T | R | VE | S | TE | VE | A | 11 | 11.6 | 17 |
| run062 | V7 | N | 8 | 3 | 230 | S | B | E | C | C | Y | X | D | F | T | R | VE | S | TE | VE | A | 5 | 8.0 | 14 |
| run066 | V7 | N | 30 | 9 | 233 | S | B | E | R | R | Y | X | D | F | T | R | VE | S | TE | ok | A | 0 | 6.0 | 14 |
| run008 | V8 | N | 3 | 2 | 224 | S | B | E | C | C | Y | ok | D | K | T | R | VE | S | TE | VE | A | 16 | 10.1 | 14 |
| run009 | V8 | N | 4 | 3 | 224 | S | B | E | G | R | N | ok | D | K | T | R | VE | S | TE | VE | A | 5 | 7.2 | 11 |
| run010 | V8 | N | 4 | 3 | 177 | S | B | E | G | R | N | ok | D | K | T | R | VE | S | TE | VE | A | 0 | 9.0 | 16 |
| run002 | V8 | N | 5 | 4 | 214 | S | B | B | R | R | Y | X | R | K | T | R | VE | S | TE | VE | A | 9 | 9.0 | 14 |
| run003 | V8 | N | 5 | 4 | 187 | S | B | B | R | R | Y | X | R | K | T | R | VE | S | TE | VE | A | 5 | 9.7 | 17 |
| run005 | V8 | N | 5 | 4 | 219 | S | B | E | R | R | Y | X | R | K | T | R | VE | S | TE | VE | A | 19 | 8.6 | 15 |
| run001 | V8 | N | 9 | 4 | 173 | S | B | E | C | C | Y | X | R | F | T | R | VE | S | TE | VE | A | 6 | 9.7 | 13 |
| run004 | V8 | N | 18 | 16 | 153 | S | B | E | C | C | Y | ok | R | K | T | R | VE | S | TE | ok | A | 10 | 6.7 | 13 |
| run014 | V8 | N | 19 | 17 | 204 | S | B | E | R | R | Y | X | D | K | T | R | VE | S | TE | VE | A | 19 | 9.2 | 15 |
| run011 | V8 | N | 28 | 3 | 21 | B | B | E | R | R | Y | W | D | K | T | S | VE | S | TE | ok | A | 14 | 6.1 | 11 |
| run013 | V8 | N | 31 | 5 | 233 | S | B | O | R | R | Y | W | R | K | T | S | VE | S | TE | ok | A | 16 | 7.6 | 14 |
| run006 | V8 | N | 41 | 6 | 214 | S | B | E | R | R | Y | X | P | K | T | R | VE | S | TE | ok | A | 0 | 6.7 | 14 |
| run007 | V8 | N | 57 | 8 | 237 | S | B | E | C | R | Y | X | R | K | T | R | VE | S | TE | ok | A | 7 | 8.5 | 14 |
| run012 | V8 | N | 118 | 10 | 318 | S | B | E | C | C | Y | ok | R | K | T | R | VE | S | TE | VE | A | 6 | 11.7 | 15 |
| run076 | V9 | N | 2 | 2 | 0 | B | B | B | G | R | N | ok | D | K | T | R | VE | R | 1c | ok | B | 3 | 7.0 | 11 |
| run077 | V9 | N | 2 | 2 | 20 | B | B | B | G | C | N | ok | D | K | T | R | VE | R | ch | ok | B | 0 | 6.5 | 12 |
| run079 | V9 | N | 2 | 2 | 0 | B | B | B | G | R | N | ok | D | K | T | R | VE | R | 1c | ok | B | 7 | 6.6 | 11 |
| run078 | V9 | N | 4 | 3 | 117 | X | B | B | G | R | N | ok | D | K | T | R | VE | R | 1c | ok | B | 6 | 7.4 | 12 |
| run081 | V9 | N | 4 | 3 | 116 | X | B | B | G | R | N | ok | D | K | T | R | VE | R | 1c | ok | B | 4 | 6.8 | 9 |
| run082 | V9 | N | 29 | 4 | 0 | B | B | B | G | R | N | ok | D | K | T | S | VE | R | 1c | ok | B | 5 | 8.0 | 12 |
| run075 | V9 | N | 31 | 5 | 117 | X | B | B | G | C | N | ok | D | K | T | S | VE | R | ch | ok | B | 5 | 7.5 | 11 |
| run080 | V9 | N | 41 | 5 | 498 | S | D | B | G | R | N | ok | D | K | T | R | VE | R | ch | ok | B | 5 | 8.5 | 11 |
| run074 | V9 | N | 63 | 3 | 528 | S | E | O | C | C | Y | ok | D | K | T | S | VE | R | ch | ok | B | 8 | 9.2 | 13 |
| REF | – | – | 0 | 0 | 0 | B | B | B | C | C | Y | ok | D | K | T | R | VE | R | ch | ok | A | – | – | – |

#### Appendix B: Files in `incog2/work/`

- `run_behaviour_matrix.csv`, `behaviour_matrix.json`: the full 82-run × 45-behaviour matrix.
- `behaviour_summary.txt`: every behaviour category with per-version and per-agent counts.
- `failure_root_causes.csv`: all 504 failing pairs with cluster and mechanism.
- `hidden_fails.json`, `fuzz_summary.json`, `trace.json`, `own_vs_ref.json`, `stated_map.json`, `units.json`, `static.json`, `traj.json`, `meta.json`, `modal_vs_ref.txt`, `agg_table.md`, `run_table.md`: intermediate data behind the tables above.
- Probe and analysis scripts: `probes.py`, `probes_none.py`, `probes_groups.py`, `fuzz.py`, `trace_probe.py`, `consist_probe.py`, `classify.py`, `model.py`, `early.py`, `predictors.py`, `stated.py`, `static.py`, `traj.py`, `stats.py`, `run_*.sh`.
- `trees/<run>`: every patched tree.
- `desc/<hash>.txt`: every description version.
- `REPORT.md`: not written (see the note at the top).

---

# Appendices

## Appendix A. All lessons (1-84)

Each row: what went wrong, what caught it, and the rule or gate now in place so it is caught locally first.

| Round | Problem | Caught by | Rule now |
|---|---|---|---|
| 1 | 4-axis coordinate arrays accepted | SQ | G4: probe every entry route, including shapes that coincide with the legacy layout |
| 1 | Local runs hid failures (devito sets `--maxfail=5`) | Me, late | Runner and test.sh always pass `--maxfail=100000` |
| 2 | A pre-built SubFunction bypassed the leading-axis rule | SQ | Fix the whole mechanism on every route, never only the reported case |
| 3 | Signed zero and multiplication order broke a bit-exact promise | TQ bulb, then probes | Promise "up to floating-point rounding" unless exactness is the feature |
| 4 | Removing `match=` made 16 tests pass on base; Verify Solution failed | Verify Solution | G3: rerun the red state after any change to an assertion's oracle |
| 4 | MatrixSparseTimeFunction cleared `self`, not the row `lhs` it wrote | SQ | Mutant per route; this one is now M2 in the example spec |
| 4 | Workflow said "mirror every probe row with a test" and "every sentence on every kind"; scope ballooned | Me, in review | Removed in v2. Breadth only where the sentence lists it |
| 5 | Scope cut removed a helper a subclass still called | Test run | CLAUDE.md: grep every caller, including subclasses, before removing a helper |
| 5 | Test helper treated `None` as "argument omitted", so the `None` case tested nothing | Test run | CLAUDE.md: helpers never map a tested value to "omitted" |
| 5 | Mutant patches had doubled `a/a/` prefixes and silently did not apply | Runner REBUILD line | `mkmut.py` writes patches with difflib and correct headers |
| 5 | Mutants on the symbolic coordinate path survived because kernels read host tables | Mutant survival | G5 triage (a): move the mutant to the path that actually runs |
| 5 | Surviving mutants led me to delete rank and shape checks as "redundant" | Nothing, until SQ in round 6 | G5 triage (b): redundant on tested inputs is not redundant on all routes; probe every route first |
| 6 | SQ: a rank-4 array matching the legacy shape, and a short supplied SubFunction, were both accepted | SQ | Checks restored; the existing `extra_axis` case retargeted to the SQ shape (no new test) |
| 6-7 | Chasing TQ "partial" rows and bulbs with rewording; four new ones every run | Observation: 4, 4, 4. Corrected later: a reference task got 0 bulbs on three versions, so bulbs come from open-ended rules sampled at one point, not a quota | Bulbs are advisory. Only "not discriminating" partials on regression or universal sentences get a narrower sentence |
| 7 | "whichever row", "behaves exactly as it does now" each read as extra requirements | TQ partial rows | CLAUDE.md: no universal words beyond what a test samples; never restate legacy behaviour |
| 8 | Rollouts 0/4: every agent kept base's clear-the-current-row line, and the test demanded the shifted row be replaced, which the description never said | Rollouts (4 runs, same case) | One consequence sentence added to the description; test loosening rejected because it would give 100% passes |
| 8 | Alignment check read `matrix(grid, name, None)` as passing `moving=None` (the helper mapped None to "omitted") | Problem/tests alignment | A separate helper builds the omitted case with no argument at all |
| 9 | SQ PASS with a medium issue: moving matrix interpolation cleared only the columns the matrix maps | SQ | Clear the whole shifted row, narrow only the accumulation; mutant M12 survives (no test, by design) |
| 10 | DQ FAIL on 3 minor presentation-only wording notes, after TQ, SQ and alignment had passed | DQ | SUPERSEDED (lesson 47): DQ findings can no longer be contested; fix them |
| 11 | Rollouts 5/10, FP panel confirmed one false positive (moving matrix injection with a radius of None and a non-default parallel Dimension); judges kept raising np.bool_ | FP panel | One stated sentence plus one parametrised test closed the FP; np.bool_ stated and tested. The coverage pre-check then flagged 15 of 38 rows, 11 fixed with parameter values and test data (independent point motion, both-sided shape faults, a second step count, float32 data that actually discriminates); 4 accepted as advisory |
| 11 | I called the 4 remaining pre-check rows "scope creep" and accepted them unchecked. Running them as probes showed the float32 exact-value sentence promised injection too, and the solution is 1 ulp off there in 2D/3D | User question, then probe | Advisory rows are test breadth, not scope; probe each one on the reference before accepting it. Sentence narrowed to interpolation |
| 12 | Chasing the pre-check to zero: 8 rounds, flags 15, 4, 1, 8, 2, 7, 2, 1. Each round found a finer unsampled cell of the promised cross product; tests grew from 74 to 118 cases. Every fix was real and passed on the solution, but the count never settled | User ("isn't this the loop again") | Pre-check capped at 3 rounds; promise few independent dimensions; narrow peripheral sentences instead of adding cases |
| 13 | Worried 3 of 4 passes meant over-hinting | Trajectory features plus probes on 14 stored agent solutions | Passers and failers used the hints equally; passing code had no shortcuts and survived 20 extra probe cases. Six test-only discriminators caught no current passer; the only one that did (a shared per-step coordinate table, 12 of 14 fail) needs a description sentence |
| 14 | Final rollouts 3/10, every failure on the same two shifted-row matrix cases. FP panel upheld all 3 passes; two lone judges dissented on unstated routes (reusing another function's moving coordinate SubFunction; building with coordinates_data= only) | FP panel adjudicator | A lone dissent on a route the description never states is over-flagging, not an FP. Probe passers locally with the unstated-route candidates first so the dissent is expected, and do not edit anything |
| 15 | Auto Review approved but routed to human review: the passing agents' effective production LOC (178, 166, 194; median 178) fell under the 200 floor, although the reference had 216 | Auto Review | The 200 floor also applies to the passing agents' median production LOC, not only the reference. Agents write leaner code, so size the reference at 250+ effective LOC and check passers with effloc.py on production files only |
| 16 | Human review approved without the scope increase. The reviewer counted 214 effective production lines in the reference (no padding) and treated the 178 passing-agent median as an Auto Review estimate. They weighed the platform's Long-horizon check (median 4 files, 136 messages, 298 LOC) and real changes across both sparse classes and the interpolator tables more heavily | Human reviewer | The passing-agent median is a warning sign, not a hard rejection, when the reference clearly clears 200 with no padding. Wait for the human verdict before building a scope increase; if you prepare one, keep it local and do not upload it |
| 17 | Second task (max_stable_dt): SQ and TQ failing, 953-word description with a refusal checklist, and a solution that took 26 s on an 11x11 model and never finished at 51x51 | Own diagnosis: timing on a realistic heterogeneous model, share of refusal code, description read against the v2 critique | Time the reference on a realistic input before any platform round. Fix speed with a result-preserving method (seed extremes, screen all points at once, full analysis only for points that can lower the result) and prove it bit-identical against the original on random inputs. State the result as a guarantee, never the method ('no point set aside' was a method rule) |
| 18 | Same task: TQ and SQ passed with nothing flagged on the first upload after the rework | Platform | What worked, in order: speed fix proven identical; description rewritten from 953 to 668 words with refusals grouped by reason and method hints removed; refusal tests cut to a representative set; three pre-check rounds that also list tests checking unstated behaviour, each gap closed by a parameter value, a restored case or a clarified sentence, and each new case probed on the reference first; full proof with mutants |
| 18b | A pre-check suggestion encoded the wrong reading (a shifted field read taken at the neighbour); probing it on the reference showed the intended reading | Probe on reference | Probe every suggested case on the reference before adding it; when it disagrees with the checker, the test settles the meaning and the sentence should say it explicitly |
| 18c | The runner wrote no junit because this test.sh reads --output_path only before the mode | Proof log (red state said NO-GO while all tests failed) | prove.sh now passes --output_path before the mode, which works for both conventions; if the red-state line contradicts the log, check the junit file exists first |
| 19 | max_stable_dt rollouts 0/4: every agent failed two cases whose clarifying clauses the rewrite had dropped (a next-level read in a source-like term, an unknown symbol inside a field index), and the double-range wording had been shortened | Rollouts | After any description rewrite, diff the old and new prose clause by clause (field manual 4.6): every clarification must survive, not only every requirement. Pre-check does not catch a dropped clarification when the test still exists |
| 20 | Three simulated solver agents built max_stable_dt from the description alone (no tests, no reference): all three failed the same Devito convention (time_order 4 steps two levels), one also missed the wide-stencil worst mode | Graded locally against the hidden tests | Before rollouts, run 2-3 simulated agents from the description only and grade them: a failure shared by all of them is a spec gap (fix the wording), a failure in one is core difficulty (leave it). They are a stronger model than the platform agents, so use them to prove solvability and find traps, not to predict the pass rate. Opt-in only since round 23 (see TOKEN BUDGET in PROMPT.md) |
| 21 | max_stable_dt ran many rounds (SQ, TQ, speed, rewrite slip, rollouts 0/4, SQ again) while scope stayed wide; a simulated agent needed over an hour; a scope cut came only after all that | User | gates.md G13 stop-loss: count tripwires every round; two means cut scope before the next upload, three means drop the task and start a new one |
| 22 | Two tasks lost SQ rounds to solution defects no pre-check could see (unsafe point screening and Function weights on max_stable_dt; missing MPI rank offsets on the curvilinear task) | SQ | PROMPT.md step 5b: a fresh-agent pre-SQ review of solution.patch against every route the description reaches, including MPI rank offsets, before uploading |
| 23 | A session told to run simulated solvers spawned 4-6 in parallel overnight, used the whole usage budget and finished nothing | User | PROMPT.md TOKEN BUDGET: solver agents banned unless INPUTS opts in (max 2, one at a time). Pre-check and pre-SQ agents are not limited by this rule |
| 24 | max_stable_dt DQ FAIL on 3 presentation-only minors (dense sentences) while TQ and SQ had passed on the same text | Description Quality | SUPERSEDED (lesson 47): DQ findings can no longer be contested. Fix every one, and batch the DQ edits with the other description changes of the round so TQ/SQ rerun once |
| 25 | max_stable_dt: a solution-only fix for SQ left TQ valid; the platform did not mark TQ stale | Platform | Staleness follows what each check reads: TQ reads description and tests, SQ reads the solution, DQ reads the description. Change only the artifact a finding is about, and rerun only the checks that read it |
| 26 | max_stable_dt: the second scope cut removed tests and sentences but left solution behaviour in place, and refusals added for SQ (derived-dimension left-hand sides, unknown applied functions, raw Indexed) were stated only in general words and never tested | Field manual 1.3 read after the fact | A cut also cuts the solution: re-list every behaviour the solution enforces; each is stated and tested, or removed. A refusal added for SQ gets a test case in the same round (SCOPE-CUT d2, step 5b) |
| 27 | max_stable_dt parked: started hard (exact worst mode over continuous wavenumbers, 150+ cases), then 0/12 rollouts over 4 batches, two cuts, and SQ still found a 100x error in the core search. No finite sampling can guarantee the promise | SQ, rollouts, stop-loss | Start easy and scale up: size the first draft so a 3-agent batch can pass, then add one behaviour at a time. Lowering difficulty after failures costs far more rounds than raising it. Reject in SCOUT any core promise no finite method can guarantee (G13 "unguaranteeable core") |
| 28 | Every SQ fail on max_stable_dt was one unbounded word stress-tested at an extreme: every wavenumber (narrow band between samples), any earlier level (100000 back, 160 GB), whole Grid (SubDimension), a symbol with no value (applied function) | SQ, four rounds | Before any SQ upload, list every universal word in the description (any, every, all, whole, arbitrary) and give each a number or a finite set the tests already sample; then probe the reference at that bound. Cheaper than any pre-SQ agent |
| 29 | Every pre-check and pre-SQ agent on max_stable_dt ran on the session's top model because no model was set (65k-155k tokens each) | User | PROMPT.md TOKEN BUDGET: set the model on every agent (sonnet for pre-check and pre-SQ, haiku for simulated solvers) and cap the report length |
| 30 | max_stable_dt FP panel failed 3 of 4 passes (40% rollouts): two passers searched only 1e-12..1e12 and one stopped at 1e-300, so limits past those came back `0.0` or `inf` against an unconditional sentinel sentence; the test sampled 1e-9 and 1e8 only. A solo judge also flagged a gridless coefficient Function that every passer accepted and the reference refused, a reference stricter than the prompt | FP panel | Every sentinel or classification promise gets a window the tests sample at both ends, and 'may' outside it. A reference guard the prompt does not name is loosened to match the passers, never tested. Before the FP panel, replay every passer on the tests and run runner/fp_screen.py against the reference (RUN.md steps 4, 5, 11, 12) |
| 31 | Quick platform pre-checks ("AI, up to 1 min") failed on misreadings: 1e-9 read as below 1e-10, "eight levels before the next one" counted from the current level, "earlier" read against the stepping direction. The pre-check gates the Scope Gate, so a bypass was not enough | Pre-check | Write boundaries as examples the tests already use (`u.subs(t, t - 7 * dt)`, "such as 1e-9 or 1e8") instead of counting rules. Examples are hard to misread and add no scope |
| 32 | Second FP round on max_stable_dt: the one passer read source terms (TimeFunctions no equation updates) at odd levels differently from the reference; a probe of that area found 67 disagreements from two rules, and a sentence-by-sentence sweep then found a third corner (field indices that are not literal shifts, 10 forms). Every earlier probe set had been built from the last failure, so each FP round found a new area | FP panel, then own sweep | After the first pass of a batch, sweep the description sentence by sentence (runner/fp_screen.py with a probe file per sentence, plus the reference's internal guards: every `raise` whose condition the text does not name) and fix every disagreement in one edit. Where two sentences pull apart, allow both readings with "may" rather than a test that fails the passer |
| 33 | Final FP on max_stable_dt (passed, one dissent overruled): the reference evaluated dt-dependent coefficients in real numpy arithmetic, so `sqrt(-dt)` (finite complex, limit about 1.0002) became nan, and the reference then returned 0.0 standalone but raised ValueError under pytest's warnings-as-errors filter. Its search also overflowed near dt = 710 for never-unstable schemes with exp(dt) | FP judge (overruled as underspecified) | When a task allows complex values, evaluate every coefficient in complex arithmetic; wrap numerical code in `np.errstate` so no result depends on warning filters; probe dt forms that turn complex (`sqrt(-dt)`) and that overflow (`exp(dt)`) in the SQ probes |
| 34 | Curvilinear task: the description promised second-order convergence with no dtype; on Grid's default float32 the Laplacian's error grew with refinement (rate -2) from round-off. On a near-singular but valid geometry (radius from 0.15, polar angle 0.15 from the poles) spherical rates were 0.9 to 1.4 at test sizes and climbed toward 2 only on refinement | Own probes before any upload | A convergence promise names the dtype (float64) and is stated asymptotically ('as the spacing tends to zero'). Probe it on the default dtype and on the hardest geometry the description allows, at three refinement levels |
| 35 | Devito's gradient (Cartesian included) holds its values at the staggered positions of the vector components: assigned to node-centred Functions it is first order at the nodes | Probe of the reference and of the base repository | Any promise about where a result is held names the positions for each kind of target, and says 'not specified' for the rest. Check the base repository's own behaviour before calling a reference behaviour a bug |
| 36 | Curvilinear task, version B: TQ flagged the convergence test unfair. The description promised second order 'as the spacing tends to zero' and the test asserted an observed rate above 1.6 at two fixed resolutions. A finite promise would have been false: fields the scheme differentiates exactly give rounding-noise rates (-2.4), and fields of order-one frequency near the axis and poles give correct but pre-asymptotic rates (1.4) | TQ | Convergence-rate tests sit between a false finite promise and an 'unfair' asymptotic one. Prefer features with exact outputs. When a rate test is unavoidable, contest with measurements: alternative correct schemes on the test's own fields and sizes (here 1.84 to 1.98) against the threshold, and a first-order mistake below it (0.97) |

### What actually converged
- Measuring LOC per feature group, then cutting whole groups together with their sentences (249 lines, then 204, then 214 after SQ fixes).
- Retargeting an existing test case to an SQ repro instead of adding a test.
- Narrowing a sentence to exactly what its test asserts.
- Treating TQ PASS with bulbs as done.

### What kept the loop going
- Adding a test for every bulb, then a new bulb appearing for the new test's breadth.
- Deleting code because mutants survived, without probing the routes SQ uses.
- Sentences with "every", "whichever" or "exactly as today".
| 37 | SQ failed the reference on a Grid built with a ConditionalDimension: new helpers built derivative shortcut names from `d.name`, while devito names them from `d.root.name` | SQ | When new code calls devito's generated shortcuts (`f.dx`, `f.dx2`, `f.dxc`), build the name from `d.root.name`, as `finite_differences/tools.py` does. Probe the reference with every Dimension kind Grid accepts before SQ |
| 38 | Hint sentences written broadly ("behaves as before", "before any other use") each became a TQ coverage suggestion | TQ | Write a hint as the narrowest true statement the tests pin ("still accepts more than three dimensions", "a shift given as a list raises ValueError") |
| 39 | Auto Review (approved, solution 2/3): validation narrowed values with `float(np.real(x))`, so a positive np.longdouble origin (1e-4000) became 0 and was rejected | Auto Review S1 | Compare values in their own dtype (`x > 0` on the numpy scalar, `np.pi` cast to that dtype), never through Python float. Probe validation with float16, float32, float64 and longdouble, the dtypes test_grid.py parametrizes |
| 40 | Auto Review (description 2/3): hints packed into one sentence (signed extent, spacing path, dtype) read as overloaded | Auto Review P4 | One rule per sentence when adding hints; split direct and spacing-implied rules |
| 41 | Adversarial Opus pre-check seeded with the platform's own past partial flags predicted TQ exactly (0 partials) and SQ clean | calibration | Keep that prompt as the standard final pre-check (platform_patterns.md order step 3) |
| 42 | Scouting after curvilinear: save/load of Functions (all four kinds, time slices, grid checks, overwrite guard) measured 87 effective lines; periodic boundaries via wrapped indices about 25 lines for the core | sizing prototypes | In devito, features with exact, behaviour-style tests are small; the ones above 200 lines are numerical (staggering, convergence). Measure the laziest working version before anything else; it sets the floor for agents |
| 43 | tabulate v2: TQ unfair on 3 test parameters that passed container forms (outer tuple, generator) the text described only as "a list"; SQ failed on 3 stated promises broken in combination with another stated option (None footer + missingval + maxcolwidths, footer-only table + scalar maxcolwidths, CLI with two files) | TQ, SQ | TQ: delete the parameters (test-only, keeps description, DQ and Scope Gate valid). SQ: fix on every route, retarget existing cases, one new CLI case; each repro kept as a probe. Before upload, probe every value promise crossed with every stated option, both scalar and list forms, and every CLI promise with two inputs (platform_patterns U3, S5-S7) |

| 44 | tabulate v4: SQ failed on a solution byte-identical to the v3 one that passed SQ (new finding: a caller-built TableFormat with the capability field set drew groups). TQ flagged the repo's signature test, edited in the first probe, for pinning the new arguments' position | SQ, TQ | SQ re-samples on every upload, so an SQ pass does not carry over; probe each refusal against every field a caller can set (platform_patterns S8). Diff every edit to an existing repo test for order it adds (U5). When the repro needs the solution's own field name, fix the code and record the mutant as an accepted gap instead of writing a test (U3) |
| 45 | tabulate v6: TQ and SQ both passed clean, with zero coverage suggestions, on the first round where PROMPT.md steps 5 (TQ pre-check) and 5b (pre-SQ review) both ran on Opus before upload. v2 to v4 skipped or cut them off and lost 2 rounds on each check | TQ, SQ | Never upload without steps 5 and 5b, including in MODE DEBUG re-uploads. Leave "fair on balance" borderline items when the platform already passed those tests |
| 46 | tabulate rollouts: every run failed one graded test that lived in an existing repo file (test_api.py) which agents also edit, because the platform merges test.patch into the agent's edited copy. The same check, moved into the new test file, passes on all 7 agent patches | Rollouts | Graded checks go only in new test files; replay agent patches with their own test-file edits kept before trusting a first batch. Hints are behaviour statements the tests already pin (the output, the consequence), never new rules |
| 47 | Platform rule change (tabulate v10): DQ findings can no longer be contested, not even minor presentation-only ones | DQ | Fix every DQ finding until DQ passes. Write the description to DQ's taste from the start: an explicit subject in every sentence, one rule per sentence, a short example for any nested shape. If a DQ fix clashes with another rule, the DQ fix wins and tests or other sentences are adjusted to match |
| 48 | tabulate v10 FP: the only passing run was judged a false positive for 3 behaviours the text never pinned (extra headers widened, True footer as 1.00, coloured footer number unformatted) | FP panel | Before rollouts, list the base-library behaviours on the feature's path (header/row count mismatch, bool, ANSI codes, bytes, None). State and test each one the feature could change; fp_screen every passer with those probes |
| 49 | tabulate v10 Auto Review High: the v10 scope cut removed the ANSI title scan with its sentence, but the code still served a reachable path (a coloured title mis-sized its column) | Auto Review | Cutting a promise cuts its sentence and its test, never code that keeps the base library's general behaviour (ANSI, wide chars) correct on a path that stays reachable |
| 50 | tabulate v10 Auto Review Low: no docstring or README for the new arguments | Auto Review | Every new public argument gets a docstring section and a README example that runs as a doctest, from the first version |
| 51 | tabulate v10 Auto Review tests band 2: the signature check pinned only the new defaults; caller-built formats were only called with footer=None | Auto Review | For every input kind the text names (registered names and caller-built objects), call the new argument with a non-default value; pin existing parameters' positions when the text says they keep them |
| 52 | tabulate v11 pre-check: naming "a caller-built TableFormat" in a sentence exposed that the solution's added TableFormat fields let a caller copy of pipe or html change the footer | Pre-check | When a sentence names caller-built objects, ignore solution-added fields on caller input and probe TableFormat(*_table_formats[name]) for every name (platform_patterns S10) |
| 53 | tabulate v11: DQ now runs a blocking AI-text detector on the description (74% AI, threshold 50%, cannot be contested: "rewrite the flagged passages in your own words") | DQ | The author writes the description prose. Claude supplies the rule list and checks the author's text (every rule kept, matches the tests, word count, banned words); it does not write or reword description prose to get past the detector |
| 54 | tabulate v11 SQ: "footer numbers in colour codes are formatted" failed for -3000; the solution reused the base formatter, whose colour regex reads digits only | SQ | When a promise reuses a base helper, probe that helper's input classes the promise covers (sign, numeric strings, bytes, digits inside codes, hyperlinks), not only the example in the text |
| 55 | tabulate v25 SQ: the repo's own signature test failed under the repo's tox gate because only test.sh deselected it | SQ code quality | When a feature changes a public signature, update the repo's own signature test in solution.patch (never in test.patch, rule R1) and run the repo's full tox command on a fresh clone with both patches before upload |
| 56 | tabulate v20-v24 SQ: three findings were base code sizing tables from the first row, exposed by the new "longest row" rule | SQ | When the text defines table width one way, grep the base for every other width source (rows[0], list_of_lists[0]) and probe each with ragged rows before upload |
| 57 | tabulate v27 FP: a 360/360 passer replaced the number text everywhere in a coloured cell (red "1" became `\x1b[3001m`), crashed on bytes footer cells, and dropped a separator in the groups + footer, no headers, no rows case | FP | Before the panel, run a wide sweep on any passer: value classes that collide with markup (digits in ANSI codes), every accepted input type (bytes), and the full product of optional parts (headers x rows x footer x groups x index) in every format |
| 58 | sq_lint cut results to 120 chars before eval (long outputs crashed it) and joined the child before reading the queue (a large result deadlocked and showed as a timeout) | tooling | Fixed in sq_lint.py: full repr, read the queue before join. A probe "timeout" on a fast function means check the runner first |
| 59 | fp_screen.py compared outputs cut to 120 chars, so every table difference past char 120 was invisible; the v11-v27 screens under-reported | tooling | Fixed: full output compared (hash past 120). Never truncate before comparing |
| 60 | tabulate v29: sweeping ALL runs (not only passers) with sentence-by-sentence probes found 6 more FP routes (numeric strings 15/24 runs, html copy, no-column tables, rst spaces, stacked codes, widened footer) and 4 silent inputs where the reference disagreed with most runs | FP | Step 11 on every run of every batch: for each probe disagreement, is it on a stated rule the run passes every test for? Yes = add a test (and a hint). Silent input where most runs disagree = move the reference to the majority, no test |
| 61 | tabulate v34: after deleting a sentence, tests still assumed what it had said | TQ | After any deletion, re-derive what the remaining text implies, sentence by sentence, and drop or adjust tests that relied on the deleted words |
| 62 | tabulate v35 TQ: tests that only pass with a base-bug fix the text never states (ragged rows + maxcolwidths) were unfair | TQ | A test may require a base fix only when the description states that behaviour |
| 63 | tabulate v36b FP: a passer showed bytes footers as b'abc' and lost Decimal precision; the test only checked "abc" in result. The panel grounded both in base behaviour (data cells decode bytes, keep Decimal precision), not only in the text | FP | Every value class the new code renders gets an exact-output test where base has a data-cell equivalent. Deleting description text does not remove a base-consistency ground |
| 64 | tabulate v37: DQ added a length gate: pass <=200, warn 201-400, fail >400 words; it counts about like \w+ (721 for 722) | DQ | Budget <=385 by \w+ from the first draft (RUN step 2) |
| 65 | tabulate v35-v36b: the colour rule line ("digits inside the colour codes must stay untouched") was followed by about 1 run in 3; 11 of 14 still failed. The padding line moved padding misses from about 3 in 4 to 6 of 14 | runs | A rule line does not show a trap. Spend hint words only on traps that block 2+ near-passers; prefer one input -> output example of the exact trap |
| 66 | tabulate v38: the 721-word text cut to 385 by deletion only was flagged AI; the residue was all dense rule sentences | DQ | Write the short version fresh in the author's words from the fact list; do not delete a long text down to its rules |
| 67 | tabulate v36b: the FP panel was opened before the sweep; the sweep (45 disagreements) would have caught both FP reasons | FP | No FP panel before the passer's patch is swept against the reference |
| 68 | tabulate v35-v36b: applying only the hinted fix to near-passers' code (colour: 4 of 5 then passed; padding: 2 of 4) measured a hint's value before a DQ cycle | runs | Before writing a hint, run the follow-the-hint check on the near-passers |
| 69 | tabulate v1-v39: tests compared whole rendered tables exactly (19 group formats, 36 footer formats). Every cosmetic choice (padding 0/1/3, which border line, which joint character) became pass/fail, so each one had to be spelled out in the description: the text grew past the length gate, read as dense rules (AI flag), and agents still failed on choices they could not guess (73 runs, 0 clean passes) | author | Behaviour tasks are permissive. Tests check the promised behaviour (where things go, what is merged, what value is shown) and accept any reasonable layout. Exact strings only at the value level (a formatted number, decoded bytes, intact colour codes), never whole tables. Do not state cosmetic choices in the description; what is not stated is not tested |
| 70 | tabulate v40: the author's 10-point FP gap checklist found untested combinations (wide title + footer, showindex + groups + footer) and an untested signature promise | FP | Run FP_GAP_PROMPT.md on the tests before every upload and after every FP verdict (RUN step 10c) |
| 71 | tabulate v40: description target <=200 words (DQ pass band), signature + input -> result lines, no explanation; Claude writes a reference draft, the author rewrites it in full, Claude checks the rewrite against the tests | DQ | Flow: draft (Claude) -> full rewrite (author) -> fact check + word count (Claude). Cosmetic details stay out of the text and out of the tests |
| 72 | tabulate v44 SQ FAIL: ragged-row normalisation ran on every call, so tables changed with footer/headergroups left out ("If omitted/None nothing different") | SQ | Gate every behaviour change behind the new arguments. Before each upload, diff base vs solution with the new args omitted AND passed as None over a wide matrix (datasets incl. ragged/sepline/dicts/ANSI/bytes/multiline x header modes x options x every format; 23328 cases here) and require 0 differences |
| 73 | tabulate v45 SQ FAIL: footer text went through base _wrap_text_to_colwidths under maxcolwidths, which crashes on coloured numbers and "1,000" | SQ | When new code calls a base helper, crash-fuzz new value kinds x existing options x formats before upload (171k calls here). Every crash class is one bug; fix the class, not the case |
| 74 | tabulate v46-v48: the same solution got three SQ runs with three different mediums (overlong footer, group validation, multiline titles) | SQ | SQ samples edges. A medium on a PASS is not a blocker. If the score matters, close every known medium in one bundle and sweep sibling features first (group titles vs everything headers support), then re-run SQ once |
| 75 | tabulate v46 SQ cited hidden tests that only existed in v1-v18 packages | platform | When a reviewer cites test names you do not ship, check the task for stale attached tests or submissions |
| 76 | tabulate v47: 4/4 fresh runs put <tfoot> right after </thead>, as the text literally said; a test demanded it after the data. The blind reviewer had flagged it; I kept it because 73 OLD runs never hit it | TQ/runs | Runs written to an older description are not evidence a test is fair to the current text. When a reviewer says a test over-demands the literal wording, relax it before the next batch |
| 77 | tabulate v47: 13 checks read out[-2] assuming a bottom border; runs that hid outer rules (footer treated like a header) failed with correct values | tests | Never locate a row by fixed index. Find it by content (e.g. last non-rule line); outer rules are cosmetic |
| 78 | tabulate v47-v49: 0/8 fresh runs got colour right. Agents reuse base's colour formatting, which handles the text's only example (red 3, 03d) but breaks negatives, floats (str.replace corrupts \x1b[32m) and stacked codes. The example passes, so agents never see the trap. Of 9 runs that got it right, all wrote their own prefix/number/suffix wrapper | runs/DQ | The example in the text must be a case the base helper gets WRONG (red -3, green 2 with floatfmt, bold red), stated as behaviour, not as steps. Before writing a test that demands better than base, check how base's own data cells behave on it |
| 79 | tabulate v48: the first clean-looking passer (516/516) padded every table to max(data, headers, footer, groups) on every call. Pre-FP differential found 5724/23328 default-path diffs; advised not to send; panel confirmed FP (ragged rows with short headers) | FP | Default-path differential is mandatory before every FP panel. Any difference on a stated "nothing changes" = do not send; add a test. Exact old output is fair for "nothing changes" (TQ accepted it) |
| 80 | tabulate v48 FP: the panel also found the header line missing above the footer when there are no data rows; my pre-FP sweep never compared empty-data tables | FP | Pre-FP sweep includes the degenerate tables: no rows, headers only, footer only, no headers, every format, passer vs reference |
| 81 | Re-eval re-grades the saved patches; a description change does not affect it. Local replay matched platform junit case for case | runs | Predict re-eval locally (apply solution-patch.patch to base, run the new tests) and verify once against the platform's junit; then trust the prediction |
| 82 | Platform guidance: do not rescue pass rate with hints; write the description like a prompt to an agent, no laundry list of steps | DQ | Description = behaviours + 1-2 examples chosen to expose the real traps. If agents still cannot solve it, cut scope; do not add rules |
| 83 | tabulate overall: 50 versions, 116 agent runs. Two features x 36 formats x number/colour/Decimal/bytes/html/rst/latex rules = ~25 stated behaviours. TQ (every test grounded, longer text), DQ (short, human), FP (pin everything a passer shows) and pass rate (few tests) could not all be met; every fix for one gate gave another gate a finding | task selection | Cap scope at selection: one feature, about 10 behaviours, and avoid behaviours that inherit base quirks (escape codes, ragged layout, markup formats). If after 8 fresh runs one systematic blocker remains and the gates keep cycling, cut scope instead of patching |
| 84 | tabulate: Claude kept proposing the next correct fix for 50 versions and never said "this task should be cut or dropped", despite clear signals (0 clean passes in 73 runs by v43; SQ giving different findings on identical code; 0/8 fresh runs past the main blocker) | process | Claude owns the stop-loss call. At the start, agree a budget (e.g. 15 versions or 40 agent runs). At each budget point, and whenever a gate gives a new finding on unchanged code or 8 fresh runs share one blocker, Claude must say plainly: continue, cut scope (name what), or drop, with the evidence. Fixing the next thing is not a substitute for that call |

## Appendix B. Calibration: local checks vs platform

### Scoreboard

| Local check -> platform check | Rows | Agree | False alarm | Miss | No local check ran | Reading so far |
|---|---|---|---|---|---|---|
| Coverage pre-check -> TQ coverage table | 6 | 2 | 0 | 0 | 4 | Trustworthy for partial rows whenever it ran |
| Coverage pre-check -> TQ bulbs | 4 | 1 | 0 | 2 | 1 | Bulbs come from cells the pre-check never splits out; advisory anyway |
| Pre-SQ review -> SQ | 6 | 0 | 1 | 1 | 4 | Stricter than SQ on its one sample; every SQ finding came before pre-SQ existed |
| (none) -> DQ | 4 | 0 | 0 | 0 | 4 | Always presentation-only minors; fix every one (contesting is no longer allowed, lesson 47). v11 adds a DQ-lens re-read |
| Simulated solvers or probes -> rollouts | 6 | 2 | 0 | 0 | 4 | Main blind spot: no cheap local predictor |
| Reference effloc -> Auto Review LOC | 1 | 0 | 0 | 1 | 0 | Check passing agents' median too (lesson 15) |
| FP screen -> FP panel | 3 | 1 | 0 | 0 | 2 | First two FP fails came with no sweep. v48: default-path differential flagged the passer before the panel (agree), but the sweep had no empty-data tables, so one of the panel's two reasons was not predicted |
| Re-eval prediction (local replay) -> platform re-eval | 2 | 2 | 0 | 0 | 0 | Exact case-for-case match both times; trust it |
| (none) -> Auto Review | 1 | 0 | 0 | 0 | 1 | tabulate v10: description 2, tests 2, solution 1 (High). No local AR lens yet; v11 re-reads the diff through the rubric |

### tabulate round log (early versions)
| Round | Check | Local prediction | Platform | Verdict | Note |
|---|---|---|---|---|---|
| v2 | TQ | Opus pre-check, 3 rounds (61/75, 89/96, 87/91 ok); none flagged container forms | FAIL, 3 of 60 unfair (outer tuple of levels, outer tuple for one level, generator) | Miss | The pre-check prompt asks for coverage and underivable output, not "does a test pin an input form the text never names". Fixed by deleting the 3 parameters (test-only change) |
| v2 | TQ coverage | pre-check round 3: 2 medium, fixed | 28/30 covered, 2 partial ("single point"), 3 suggestions | Agree (advisory) | Partials and suggestions left as advisory per CLAUDE.md |
| v2 | SQ | pre-SQ cut off; sq_probes.py 31 probes, 0 failures | FAIL: 3 defects (None footer + missingval + maxcolwidths; footer-only + scalar maxcolwidths; CLI multi-file stdout) | Miss | All three were pairs of stated features; probes sampled pairs of group features, not footer x option pairs. Added as probes and as platform_patterns S5-S7 |
| v3 | TQ | 3 unfair parameters removed (test-only) | PASS, 58/58 fair; 5 partial rows (2 single point, 3 not discriminating), 5 suggestions | Agree on fairness | Partials closed with parameter values in v4 (CLAUDE.md coverage patterns), no description change |
| v3 | SQ | 3 defects fixed, repro probes 3 of 3 pass | PASS (complete) | Agree | Solution-only fix; description untouched, so DQ and Scope Gate stayed valid |
| v3 | VCA | none (VCA ran after TQ, as INEFFICIENCIES warns) | Incomplete, 5 gaps with a proposed test patch | No local check | Kept 3 (empty footer, scalar/tuple maxcolwidths, html footer escaping); dropped 2 that pin behaviour the text never states (ragged rows, booleans as text), per platform_patterns U2 |
| v4 | TQ | test-only change (parameter values + 3 VCA tests); no pre-check re-run | FAIL, 1 unfair: test_tabulate_signature pins footer and headergroups to the last two positions; 3 suggestions | Miss | The probe had appended the new names to the repo's ordered signature list; no local check looks at edits to existing repo tests. Loosened in v5: new names checked by name and default, old order kept. platform_patterns U5 |
| v6 | TQ | Opus TQ pre-check (step 5) on v5: 4 single point (3 fixed with values, youtrack rejected), 0 unfair, 10 borderline left as is | PASS, no issues, zero coverage suggestions | Agree | First clean TQ on this task. The 10 "borderline, fair on balance" items were right to leave |
| v6 | SQ | Opus pre-SQ (step 5b) on v5: 0 HIGH, 3 MEDIUM reproduced and fixed, 3 LOW logged | PASS, no issues | Agree | First completed pre-SQ on this task. Skipping steps 5 and 5b (v2 to v4) cost 2 failed rounds each for TQ and SQ |
| v6 | Rollouts, batch 1 (5 Nova, 2 Orion) | guessed about 10% per run, 0-2 passes in 10 | 0 of 7; 7 of 7 failed the signature test (harness collision, platform_patterns R1); best run 261/263 (one real miss). Clusters of 3+ runs: textile backslash (4), grid line under the last level (3), \r\n as two breaks (3), simple without headers hiding its lines (3), longtable repeating \endhead (3), CLI printing earlier files (3). Agent solutions 484-623 effective lines, no suspicious lines | Miss (harness), else in line | v7: test-only fix for R1; six behaviour hints (consequence, not method), each pinned by an existing test; replay after the fix: best run fails 1 test (the simple cluster) |
| v4 | SQ | solution byte-identical to v3, which passed SQ | FAIL: a caller-built TableFormat with grouprow="merge" draws groups; the text says a caller-built TableFormat raises ValueError | Miss, and SQ is not stable: the same solution passed on v3 | The refusal keyed on a field the caller can set. Fixed in v5 on how the format arrived. No fair test: the repro names the solution's own field (U3), so mutant M45 is an accepted gap. platform_patterns S8 |

| v7 | TQ | pre-check rounds 1-2 (Opus): 0 unfair; 5 rows fixed, 1 advisory | PASS, 61/61 fair; 32/34 covered; 2 suggestions (footer-only and multi-line titles not run in every format) | Agree on fairness; bounce on coverage | Suggestions are new cells again (coverage_precheck.md: the checker always finds a finer cell). Logged, not chased: tests are in rollouts (CLAUDE.md) and a test edit would stale this PASS |
| v7 | SQ | focused pre-SQ on the changed sentences only: clean | FAIL, 1 high: `tabulate -G` with no GROUPS printed usage to stdout (getopt's own error path) | Miss | The pre-SQ was scoped to the changed sentences; the CLI sentence had not changed, but the hint made "nothing to stdout" more prominent. Fixed solution-only in v8 (usage to stderr when the getopt error is for -G/--headergroups); pre-SQ on v8 covers every CLI error path |
| v8 | TQ | unchanged from v7 (tests and description identical) | PASS, 61/61 fair, 36/38 covered; 2 new suggestions (widening and multi-line titles not in every grid/outline variant) | Agree | Third round of "add more formats", each on a different test: the bounce. Logged, not chased (tests in rollouts) |
| v8 | SQ | pre-SQ (Opus, CLI error paths): 0 HIGH, 1 MEDIUM fixed (-o file emptied) | PASS; 1 medium: ragged rows with headers matching a short first row said to draw 2 columns | Agree on PASS; the medium is false | Checked at this commit: tabulate([[1],[2,3]], headers=['value']) draws 1 column (headers cap the table), so our count matches. Kept as a contest fact, no change (a solution edit would re-run SQ, which re-samples) |
| v9 | TQ | Opus pre-check on changed rows: clean | FAIL: one assertion read as unfair (TQ took the 3-column table footer=["t", 3.75, 1500] for 4 columns) plus suggestions | Miss | A misread, but it cost a round; v10 went back to the form that passed TQ v5-v8 |
| v9 | SQ | pre-SQ (Opus): clean | PASS (complete) | Agree | |
| v10 | DQ | no DQ lens; gates.py only | FAIL: 3 minor presentation-only comments (pronoun subject, stacked modifiers, nested type rule) | No local check | Contesting now banned (lesson 47); v11 fixes all 3 and 5 more of the same shape |
| v10 | Rollouts, batch 2 (6 Nova, 4 Orion) | replay of batch 1 after R1 fix: best run 1 failure | 1 of 10 passed (Orion_Nova_1) | In line | Every run widened the table to extra headers; nobody was told not to |
| v10 | FP panel | no sweep on the passer before the panel | The one pass judged a false positive (adjudicator, high confidence): extra headers widened, True footer shown as 1.00, coloured footer number not formatted | No local check | All 3 are base-library behaviours the text never pinned. v11 states and tests each; fp_screen then shows 21 disagreements, all inside those 3 rules |
| v10 | Auto Review | none | Description band 2 (P4 nested-shape prose), tests band 2 (signature check pins only defaults; caller-built formats only with footer=None), solution band 1 (High: ANSI title scan removed by the v10 cut; Low: no docs) | No local check | The High was self-inflicted by the scope cut. v11 restores the scan, adds docs and the missing tests |
| v11 | Pre-check (Opus) round 1 | n/a | 2 HIGH (both already fixed by the DQ re-read), 6 MEDIUM, 4 LOW | n/a | MEDIUM fixed: caller-built copies of pipe/html/latex_longtable kept the solution's footer fields (solution fix, mutant M61 accepted gap), caller header row equal to its data row (test), extra headers wording and coverage (test, ragged rows), positions wording, levels wording |
| v11 | Pre-check (Opus) round 2 (last) | n/a | 2 HIGH, 5 MEDIUM, 4 LOW | n/a | All high and medium were D1 wording (pointer words, stacked modifiers) or one false literal reading (pipe footer-only draws its header line); fixed word-neutral. Lows 8-10 fixed (2 small tests). Platform result below |
| v11 | TQ | Opus pre-check 2 rounds, all fixed | PASS, complete, no coverage suggestions | Agree | |
| v11 | SQ | sq_lint 42 probes clean; pre-check round 1 caught the caller-copy bug | FAIL, 1 high: a signed number in colour codes (-3000) skipped intfmt (the base formatter's colour regex takes digits only) | Miss | Probes had positive coloured numbers only. Probing the same function found 3 more: numeric string ints ignored intfmt, digits inside a colour code were rewritten, bytes numbers crashed. v12 formats the plain number and puts it back between the codes (platform_patterns S11) |
| v11 | DQ | self re-read plus 2 pre-check rounds on wording | FAIL: blocking AI-text detection (74% AI, threshold 50%, cannot be contested) plus 3 minor wording comments | No local check | New platform gate: the description must be written by the author. Lesson 53 |
| v12-v16 | DQ AI detection | none possible locally | FAIL every run: 0.74 (v11), 0.78 (v13), 0.75 (v15), 1.0 on the author's own draft (v16 base) and 1.0 on v16; wording comments fell to 0 by v15 | No local check | The detector scores dense rule-per-sentence spec prose as AI whoever writes it; a reworded draft keeps the skeleton it scores. Route: platform support with the author-written runs as evidence |
| probe | DQ AI detection, control | tabulate README prose from Jan 2019 (human, 968 words) | fractionAi 0.0, prediction Human | n/a | The detector does not flag human technical docs of this length and topic; our spec-style descriptions (0.74-1.0) are what it flags |
| probe | DQ AI detection, short controls | README 2019 prose 259 words; v16 opening 287 words | README: 0.0 Human (DQ PASS despite being off-task); v16 opening: 1.0 AI | n/a | Length is not the trigger; the writing style of our descriptions is. Probe a 250-word sample of any new description before writing the whole thing |
| v20-v26 | SQ | sq_lint probes (48-52) clean each round | v20 FAIL (ragged+maxcolwidths, Decimal), v21 PASS with medium (empty rows keep headers; fixed for FP safety), v24 FAIL (ragged rows + short headers), v25 FAIL code quality only (repo signature test stale under tox), v26 PASS | Miss x3 | Each SQ run re-samples; three findings were base first-row sizing paths exposed by our "longest row" rule (platform_patterns S12). The last was the repo's own signature test, which test.sh deselects but tox runs |
| v19-v24 | TQ | full-set coverage per stated family | PASS, all fair, no coverage suggestions (v22, v24) | Agree | Recipe: every "all X" walked in full, every quantity at 2 values, nothing stated untested |
| v22 | Auto Review | none | Approved: description 3/3, solution 3/3, tests 2/3 (headergroups=[] not refused in tests) | n/a | Closed in v23 |

Later rounds (v44-v50) are covered in sections 1-4 and lessons 72-84.

## Appendix C. The 10-point FP gap prompt

Do a deep and complete analysis on finding critical gaps that could allow an incorrect, incomplete,
hardcoded, overly simplified, or otherwise buggy implementation to pass all tests.
Review the following points; if missing from the tests, fix them:

1. Missing behavioral scenarios that are required by the problem description.
2. Edge cases that are not validated.
3. Boundary conditions that are not exercised.
4. Error handling or failure cases that are not covered.
5. State transitions, interactions, or combinations of behaviors that are not tested.
6. Cases where a partially correct implementation could still pass.
7. Cases where a hardcoded or shortcut solution could pass.
8. Cases where an implementation that handles only the tested examples, rather than the general behavior, could pass.
9. Cases where tests verify only common paths and miss important alternative paths.
10. Situations where different valid inputs should produce different outcomes but the tests do not verify those distinctions.

How to apply it here (keeps tests permissive, lesson 69):
- Walk the description clause by clause; each clause needs a test that a wrong implementation fails.
- Fix a gap with a behaviour check (position, order, merged or not, exact value), never a whole-table string.
- Do not add a test for anything the description does not state (unstated = untested).
- Then replay every run and sweep any passer (RUN step 11) before the FP panel.

## Appendix D. Reusable tools

Paths inside the scripts point at this session's scratch folder; change W and the data lists for a new task.

### default_path.py
Default-path differential. Run once in the base repo (base.json) and once in the solution or a passer (with and without 'explicit' as argv[2]); compare the two JSON maps key by key. Must be 0 differences for any 'nothing changes' promise. Adapt DATA/HEADERS/EXTRA to the library.

```python
"""Run tabulate without footer/headergroups over many inputs; print a JSON map of results."""
import itertools, json, sys, inspect
from tabulate import tabulate, tabulate_formats, SEPARATING_LINE
explicit = len(sys.argv) > 2 and sys.argv[2] == "explicit"
red = "\x1b[31m{}\x1b[0m".format
DATA = {
    "plain": [["apples", 3, 1.5], ["pears", 12, 20.25]],
    "ragged_short_first": [[1], [2, 3]],
    "ragged_long_first": [[1, 2, 3], [4]],
    "ragged_text": [["a"], ["b", "long text here"], ["c", "x", "yy"]],
    "empty_row": [[], [1, 2]],
    "sepline": [["a", 1], SEPARATING_LINE, ["b", 2]],
    "none_vals": [["a", None], [None, 2.5]],
    "ansi": [[red("x"), red(12)], ["y", 3]],
    "bytes": [[b"ab", 1], [b"cd", 2]],
    "multiline": [["a\nb", 1], ["c", "2\n3"]],
    "dicts": [{"a": 1, "b": 2}, {"a": 3, "c": 4}],
    "empty": [],
}
HEADERS = {"none": (), "short": ["h1"], "equal": ["h1", "h2"], "long": ["h1", "h2", "h3", "h4"], "keys": "keys", "firstrow": "firstrow"}
EXTRA = {
    "default": {},
    "showindex": {"showindex": True},
    "maxcol3": {"maxcolwidths": 3},
    "maxcol_list": {"maxcolwidths": [None, 4]},
    "maxhead2": {"maxheadercolwidths": 2},
    "missing": {"missingval": "?"},
    "colalign": {"colalign": ("right", "left")},
    "fmt": {"floatfmt": ".1f", "intfmt": ","},
    "noparse": {"disable_numparse": True},
}
out = {}
fmts = tabulate_formats
for (dn, data), (hn, headers), (en, extra), fmt in itertools.product(DATA.items(), HEADERS.items(), EXTRA.items(), fmts):
    kw = dict(extra)
    if explicit:
        kw.update(footer=None, headergroups=None)
    try:
        r = ["ok", tabulate(data, headers=headers, tablefmt=fmt, **kw)]
    except Exception as e:
        r = ["exc", type(e).__name__]
    out[f"{dn}|{hn}|{en}|{fmt}"] = r
json.dump(out, open(sys.argv[1], "w"))
print(len(out), "cases")
```

### crash_fuzz.py
Crash sweep: every new value kind x existing option x format. Any exception where the same call without the new arguments works is a bug class. Adapt COLS/VALS/OPTS/FMTS.

```python
"""Every footer value kind / title kind x existing options: our code must not raise where base
tabulate (same call without footer/headergroups) does not."""
import itertools, json, sys
from decimal import Decimal
from tabulate import tabulate
red = "\x1b[31m{}\x1b[0m".format
class Obj:
    def __str__(self): return "obj"
COLS = {"int": [1, 22], "float": [1.5, 22.25], "text": ["ab", "cdef"], "numstr": ["1", "22"],
        "colint": [red(1), 22], "none": [None, 3], "bool": [True, False], "bytes": [b"ab", b"cd"],
        "dec": [Decimal("1.5"), Decimal("2.25")], "multi": ["a\nb", "c"]}
VALS = [None, 3, -3, 2.5, 3000, "x", "", red("3"), red("2.5"), red("x"), "\x1b[1m\x1b[31m7\x1b[0m",
        "3000", "1,000", red("1,000"), b"abc", b"7", b"", True, False, Decimal("2.50"), Obj(),
        "long footer text here", red("long red text here"), "a\nb", 10**20, float("nan"), float("inf")]
OPTS = [{}, {"maxcolwidths": 5}, {"maxcolwidths": [None, 3]}, {"maxcolwidths": 1},
        {"maxheadercolwidths": 2}, {"disable_numparse": True}, {"disable_numparse": [1]},
        {"missingval": "?"}, {"showindex": True}, {"colalign": ("right", "left")},
        {"numalign": "decimal"}, {"stralign": "center"}, {"intfmt": "03d", "floatfmt": ".2f"},
        {"intfmt": ",", "floatfmt": ",.1f"}, {"floatfmt": [".1f", ".3f"]},
        {"maxcolwidths": 5, "intfmt": "03d"}, {"maxcolwidths": 5, "floatfmt": ".2f"},
        {"maxcolwidths": 3, "disable_numparse": True}]
HEADS = [(), ["k", "v"], ["v"]]
FMTS = ["simple", "grid", "html", "rst", "pipe", "latex_longtable", "psql", "moinmoin", "jira"]
TITLES = ["G", red("G"), 7, b"bt", "A very long group title", "a\nb", ""]
crash = {}
n = 0
def note(key, call):
    global n
    n += 1
    try:
        call()
    except Exception as e:
        crash.setdefault(f"{type(e).__name__}: {str(e)[:70]}", []).append(key)
for (cn, col), opt, hd, fmt in itertools.product(COLS.items(), OPTS, HEADS, FMTS):
    rows = [["r", c] for c in col]
    try:
        tabulate(rows, headers=hd, tablefmt=fmt, **opt)
    except Exception:
        continue  # base-style call already fails; not ours
    for v in VALS:
        note(("footer", cn, repr(v), str(opt), str(hd), fmt),
             lambda: tabulate(rows, headers=hd, tablefmt=fmt, footer=["t", v], **opt))
    if fmt in ("simple", "grid", "psql"):
        for t in TITLES:
            for span in (1, 2):
                note(("groups", cn, repr(t), span, str(opt), str(hd), fmt),
                     lambda: tabulate(rows, headers=hd, tablefmt=fmt, headergroups=[(t, span)], **opt))
                note(("both", cn, repr(t), span, str(opt), str(hd), fmt),
                     lambda: tabulate(rows, headers=hd, tablefmt=fmt, headergroups=[(t, span)],
                                      footer=["t", red("3")], **opt))
print(n, "calls,", sum(map(len, crash.values())), "crashes")
for k, v in sorted(crash.items(), key=lambda x: -len(x[1])):
    print(f"{len(v):6d}  {k}")
    for ex in v[:3]: print("          ", ex)
```

### ragged_check.py
Checks that the new feature never changes the rest of the table (here: ragged rows, footer/groups added).

```python
"""With a footer or groups, the rest of a ragged table must look exactly as without them."""
import re
from tabulate import tabulate, tabulate_formats, SEPARATING_LINE
DATA = {
    "short_first": [["r1"], ["r2", 3]],
    "long_first": [["r1", 1, 2], ["r2"]],
    "text": [["r1"], ["r2", "long text"], ["r3", "x", "yy"]],
    "sepline": [["r1", 1], SEPARATING_LINE, ["r2", 2]],
}
HEAD = {"none": (), "short": ["h1"], "equal": ["h1", "h2"], "long": ["h1", "h2", "h3", "h4"]}
GROUP_FMTS = {"simple", "plain", "psql", "pretty"} | {f for f in tabulate_formats if "grid" in f or "outline" in f}
bad, errors, n = [], [], 0
for dn, rows in DATA.items():
    for hn, hd in HEAD.items():
        for fmt in tabulate_formats:
            for idx in (False, True):
                base = tabulate(rows, headers=hd, tablefmt=fmt, showindex=idx)
                for kind, kw in (("footer", {"footer": ["Z"]}), ("groups", {"headergroups": [("Q", 1)]})):
                    if kind == "groups" and fmt not in GROUP_FMTS:
                        continue
                    n += 1
                    try:
                        out = tabulate(rows, headers=hd, tablefmt=fmt, showindex=idx, **kw)
                    except Exception as e:
                        errors.append((dn, hn, fmt, idx, kind, repr(e)))
                        continue
                    if kind == "footer":
                        if fmt in ("html", "unsafehtml"):
                            ok = out.split("<tfoot>")[0] == base.split("</table>")[0]
                        else:
                            bl = base.splitlines()
                            last = max(i for i, l in enumerate(bl) if "r2" in l or "r3" in l)
                            ok = out.splitlines()[: last + 1] == bl[: last + 1] and "Z" in out
                    else:
                        ol = out.splitlines()
                        g = next(i for i, l in enumerate(ol) if re.search(r"\bQ\b", l))
                        bl = base.splitlines()
                        strip = lambda ls: [l for l in ls if re.search(r"[A-Za-z0-9]", l)]
                        ok = strip(ol[g + 1 :]) == strip(bl)
                    if not ok:
                        bad.append((dn, hn, fmt, idx, kind))
print(n, "cases;", len(bad), "changed;", len(errors), "errors")
for b in bad[:10]: print("  CHANGED", b)
for e in errors[:10]: print("  ERROR", e)
```

### group_sweep.py
Sibling-feature sweep: the new element must support everything the existing equivalent supports (group titles vs header cells: multiline, colour, wide characters, wrapped headers). Run with and without wcwidth.

```python
"""Group titles must behave like header cells: multiline, colour, wide chars, wrapped headers."""
import itertools, re
from tabulate import tabulate
ANSI = re.compile(r"\x1b\[[0-9;]*m")
SEP = "|│┃║"
GRID = ["grid", "simple_grid", "rounded_grid", "heavy_grid", "mixed_grid", "double_grid",
        "fancy_grid", "colon_grid", "outline", "simple_outline", "rounded_outline",
        "heavy_outline", "mixed_outline", "double_outline", "fancy_outline"]
BORDERED = ["psql", "pretty", *GRID]
FMTS = ["simple", "plain", *BORDERED]
try:
    import wcwidth
    vis = lambda s: wcwidth.wcswidth(ANSI.sub("", s))
except ImportError:
    vis = lambda s: len(ANSI.sub("", s))
TITLES = ["A\nB", "Two\nline title here", "x\n\ny", "\x1b[31mred\nline\x1b[0m", "日本語\nタイトル", "naïve\nok",
          "", " ", "A very long single line title"]
DATA = {
    "plain": ([["aaa", 11, 22], ["bbb", 33, 44]], ["key", "xval", "yval"]),
    "multi_head": ([["aaa", 11, 22]], ["key\nk2", "xval", "yval"]),
    "multi_data": ([["a\nb", 11, 22]], ["key", "xval", "yval"]),
    "wide_data": ([["日本", 11, 22]], ["key", "xval", "yval"]),
}
bad, n = [], 0
for fmt, title, (dn, (rows, head)), hdr, idx, span, align in itertools.product(
        FMTS, TITLES, DATA.items(), [True, False], [False, True], [1, 2, 3], ["left", "center", "right"]):
    ncols = 3 + idx
    if span > ncols:
        continue
    kw = {"headers": head} if hdr else {}
    n += 1
    try:
        out = tabulate(rows, tablefmt=fmt, showindex=idx, headergroups=[(title, span, align)], **kw)
        out2 = tabulate(rows, tablefmt=fmt, showindex=idx, headergroups=[(title, span, align)], footer=["f"], maxheadercolwidths=3 if hdr else None, **kw)
    except Exception as e:
        bad.append((fmt, repr(title), dn, hdr, idx, span, align, "ERR " + repr(e)[:80])); continue
    for o in (out, out2):
        lines = o.splitlines()
        if fmt in BORDERED and len({vis(l) for l in lines}) != 1:
            bad.append((fmt, repr(title), dn, hdr, idx, span, align, "ragged lines")); break
        for t_line in [x for x in title.splitlines() if x.strip()]:
            if not any(ANSI.sub("", t_line) in ANSI.sub("", l) for l in lines):
                bad.append((fmt, repr(title), dn, hdr, idx, span, align, f"title line {t_line!r} missing")); break
print(n, "cases,", len(bad), "problems")
for b in bad[:12]: print("  ", b)
```

### probe.py
Agent behaviour probe: run inside each agent's patched repo; records what the code does for every behaviour that mattered. One JSON per run.

```python
"""Record what one agent implementation does on every behaviour that mattered."""
import json, re, sys
from decimal import Decimal
from tabulate import tabulate, SEPARATING_LINE
red, green = "\x1b[31m{}\x1b[0m".format, "\x1b[32m{}\x1b[0m".format
bold_red = "\x1b[1m\x1b[31m{}\x1b[0m".format
R = {}
def run(k, f):
    try:
        R[k] = f()
    except Exception as e:
        R[k] = "ERR " + type(e).__name__
def foot_line(t):
    lines = [l for l in t.splitlines() if l.strip() and re.search(r"[A-Za-z0-9]", l)]
    return lines[-1] if lines else ""
# colour
run("col_desc_red3", lambda: red("003") in tabulate([[1], [2]], footer=[red("3")], intfmt="03d"))
run("col_negative", lambda: red("-03") in tabulate([[1], [2]], footer=[red("-3")], intfmt="03d"))
run("col_float_green2", lambda: green("2.00") in tabulate([[1.5], [2.25]], footer=[green("2")], floatfmt=".2f"))
run("col_float_red3", lambda: red("3.00") in tabulate([[1.5], [2.25]], footer=[red("3")], floatfmt=".2f"))
run("col_stacked", lambda: bold_red("007") in tabulate([[1000]], footer=[bold_red("7")], intfmt="03d"))
run("col_float_corrupt", lambda: "\x1b[32.00m" in tabulate([[1.5], [2.25]], footer=[green("2")], floatfmt=".2f"))
# default path
ROWS = [["apples", 3, 1.5], ["pears", 12, 20.25]]
run("dp_extra_header_same", lambda: tabulate(ROWS, headers=["a", "b", "c", "extra"]) == tabulate(ROWS, headers=["a", "b", "c"]))
run("dp_ragged_same", lambda: tabulate([["a", 1], ["b", 2, 3]], headers=["k", "v"]) == "k      v\n---  ---\na      1\nb      2")
# html placement
def html_place():
    o = tabulate(ROWS, headers=["a", "b", "c"], tablefmt="html", footer=["T", 1, 2])
    if "<tfoot>" not in o: return "no tfoot"
    if o.index("<tfoot>") < o.index("<tbody>"): return "after thead"
    if o.index("<tfoot>") > o.index("</tbody>"): return "after tbody"
    return "inside tbody"
run("html_place", html_place)
# empty data line, rst
run("empty_data_line", lambda: tabulate([], headers=["x"], footer=[77]).splitlines())
run("rst_padded_dots", lambda: foot_line(tabulate(ROWS, headers=["a", "b", "c"], tablefmt="rst", footer=[1, 2])).lstrip().startswith(".."))
# validation / unstated inputs
run("overlong_footer", lambda: foot_line(tabulate([["a", 1]], footer=["t", 2, 3])))
run("bad_align", lambda: "G" in tabulate([["a", 1]], headers=["k", "v"], tablefmt="grid", headergroups=[("G", 1, "middle")]))
run("span_too_big", lambda: "G" in tabulate([["a", 1]], headers=["k", "v"], tablefmt="grid", headergroups=[("G", 5)]))
run("groups_on_html", lambda: "G" in tabulate([["a", 1]], headers=["k", "v"], tablefmt="html", headergroups=[("G", 2)]))
# values
run("bytes", lambda: foot_line(tabulate([["a", 1]], footer=[b"abc", True])).split())
run("decimal", lambda: foot_line(tabulate([["a", 1.5]], footer=["t", Decimal("2.00")])).split())
run("decimal_floatfmt", lambda: foot_line(tabulate([["a", 1.5]], footer=["t", Decimal("2.00")], floatfmt=".1f")).split())
run("numstr", lambda: foot_line(tabulate([["a", 1]], footer=["t", "3000"], intfmt=",")).split())
run("multiline_title_ok", lambda: len({len(l) for l in tabulate([[1, 2]], headers=["h1", "h2"], tablefmt="grid", headergroups=[("A\nB", 2)]).splitlines()}) == 1)
run("simple_headerless_rules", lambda: tabulate([["a", 1]], footer=["t", 2]).splitlines()[0].startswith("-"))
run("decimal_align", lambda: len({l.index(".") for l in tabulate([["a", 1.25], ["b", 10.5]], footer=["t", 2.5]).splitlines() if "." in l}) == 1)
run("sepline_footer", lambda: foot_line(tabulate([["a", 1], SEPARATING_LINE, ["b", 2]], footer=["t", 3])).split())
json.dump(R, open(sys.argv[1], "w"), default=str)
```

### aggregate.py
Joins probe results, final-test failures, patch shape and transcript data (description seen, tokens, time, final message) into the behaviour table and per-description-version splits.

```python
import json, os, re, glob, hashlib, collections, datetime
W = "/tmp/claude-0/-home-user-go-yaml/abaa713c-f366-53f8-b0cd-975fe838fcfc/scratchpad"
C = f"{W}/calib"
ref = json.load(open(f"{C}/REFERENCE.probe.json"))
rows = []
for tree in open(f"{C}/trees.txt").read().split():
    key = tree.replace(W + "/", "").replace("/", "__")
    if tree.startswith(f"{W}/replay_all/"):
        b, r = os.path.basename(tree).split("__", 1); src = f"{W}/{b}/{r}"
    elif "runs11rep" in tree: src = f"{W}/runs11/{os.path.basename(tree)}"
    elif "runs13rep" in tree: src = f"{W}/runs13/{os.path.basename(tree)}"
    else: src = f"{W}/runs14/Nova_Nova"
    row = {"key": key, "agent": "Orion" if "Orion" in key else "Nova"}
    fails = sorted({l.strip().split("[")[0] for l in open(f"{C}/{key}.v49") if l.strip()})
    row["fails"] = fails; row["nfail"] = len(fails)
    row["probe"] = json.load(open(f"{C}/{key}.probe.json"))
    patch = open(f"{src}/solution-patch.patch", errors="ignore").read() if os.path.exists(f"{src}/solution-patch.patch") else ""
    files = re.findall(r"^diff --git a/(\S+)", patch, re.M)
    row["own_tests"] = any(f.startswith("test/") and f not in ("test/test_api.py",) for f in files)
    body = patch.split("diff --git a/tabulate/__init__.py")[1].split("diff --git")[0] if "diff --git a/tabulate/__init__.py" in patch else ""
    row["added_lines"] = sum(1 for l in body.splitlines() if l.startswith("+") and not l.startswith("+++"))
    row["reuse_format"] = any(re.search(r"\b_format\(", l) for l in body.splitlines() if l.startswith("+"))
    row["touch_normalize"] = bool(re.search(r"^@@.*def _normalize_tabular_data", body, re.M)) or any("headers_pad" in l for l in body.splitlines() if l[:1] in "+-" and not l.startswith(("+++", "---")))
    tj = f"{src}/trajectory.json"
    if os.path.exists(tj):
        d = json.load(open(tj)); steps = d["steps"]
        desc = next((s["message"] for s in steps if s["source"] == "user" and ("footer" in s["message"])), "")
        row["desc_hash"] = hashlib.md5(desc.encode()).hexdigest()[:8]
        row["desc_words"] = len(re.findall(r"\w+", desc))
        row["desc_flags"] = {"red003": "003" in desc, "abcTrue": "abc True" in desc, "after_thead": "after thead" in desc, "errors_required": bool(re.search(r"raise|ValueError|TypeError", desc)) and "you can throw" not in desc}
        ts = [datetime.datetime.fromisoformat(s["timestamp"].replace("Z", "+00:00")) for s in steps if s.get("timestamp")]
        row["minutes"] = round((max(ts) - min(ts)).total_seconds() / 60, 1) if len(ts) > 1 else None
        row["first_ts"] = min(ts).isoformat() if ts else ""
        fm = d.get("final_metrics", {})
        row["tokens"] = fm.get("extra", {}).get("total_tokens"); row["requests"] = len(fm.get("extra", {}).get("per_request_usage", []))
        final = steps[-1]["message"] if steps and steps[-1]["source"] == "agent" else ""
        row["claims_pass"] = bool(re.search(r"\d+ passed|all tests pass|tests pass", final, re.I))
        row["mentions_colour"] = bool(re.search(r"ansi|colou?r", final, re.I))
    rows.append(row)
json.dump(rows, open(f"{C}/rows.json", "w"), default=str, indent=0)
n = len(rows); P = lambda x: f"{x}/{n} ({100*x/n:.0f}%)"
def rate(pred, sub=None):
    s = [r for r in rows if (sub is None or sub(r))]
    k = sum(1 for r in s if pred(r)); return f"{k}/{len(s)} ({100*k/max(1,len(s)):.0f}%)"
pr = lambda f: (lambda r: r["probe"].get(f))
print("RUNS", n, "| Nova", sum(r["agent"] == "Nova" for r in rows), "| Orion", sum(r["agent"] == "Orion" for r in rows))
print("pass on v49:", rate(lambda r: r["nfail"] == 0), "| <=1 fail:", rate(lambda r: r["nfail"] <= 1), "| <=2:", rate(lambda r: r["nfail"] <= 2))
print("fail-count distribution:", sorted(collections.Counter(min(r["nfail"], 10) for r in rows).items()))
print("most failed tests:", collections.Counter(t for r in rows for t in r["fails"]).most_common(12))
print("\n== behaviours (all / Nova / Orion)")
for name, f in [("colour: desc example red 3", pr("col_desc_red3")), ("colour: negative", pr("col_negative")), ("colour: float green 2", pr("col_float_green2")),
                ("colour: red 3 in float column", pr("col_float_red3")), ("colour: stacked codes", pr("col_stacked")), ("colour: CORRUPTS escape code", lambda r: r["probe"].get("col_float_corrupt") is True),
                ("colour: all 5 right", lambda r: all(r["probe"].get(k) is True for k in ("col_desc_red3", "col_negative", "col_float_green2", "col_float_red3", "col_stacked"))),
                ("default path: extra header unchanged", pr("dp_extra_header_same")), ("default path: ragged unchanged", pr("dp_ragged_same")),
                ("touches _normalize_tabular_data / headers_pad", lambda r: r["touch_normalize"]), ("reuses base _format in new code", lambda r: r["reuse_format"]),
                ("empty data: header line repeated", lambda r: r["probe"].get("empty_data_line") == ref["empty_data_line"]), ("rst: padded first cell '..'", pr("rst_padded_dots")),
                ("decimal alignment of footer", pr("decimal_align")), ("multiline title OK", pr("multiline_title_ok")), ("bytes -> abc True", lambda r: r["probe"].get("bytes") == ["abc", "True"]),
                ("Decimal 2.00 kept", lambda r: r["probe"].get("decimal") == ["t", "2.00"]), ("numeric string '3000' formatted", lambda r: r["probe"].get("numstr") == ["t", "3,000"]),
                ("Decimal + floatfmt .1f -> 2.0 (applies fmt)", lambda r: r["probe"].get("decimal_floatfmt") == ["t", "2.0"]),
                ("headerless simple keeps top rule", pr("simple_headerless_rules")), ("wrote own test file", lambda r: r["own_tests"]),
                ("final message claims tests pass", lambda r: r.get("claims_pass"))]:
    print(f"  {name:48s} {rate(f):>14s} {rate(f, lambda r: r['agent'] == 'Nova'):>14s} {rate(f, lambda r: r['agent'] == 'Orion'):>12s}")
print("\nhtml tfoot placement:", collections.Counter(r["probe"].get("html_place") for r in rows))
print("overlong footer:", collections.Counter(("raises " + v[4:]) if isinstance(v, str) and v.startswith("ERR") else ("extra cells shown" if isinstance(v, str) and v.split()[-1:] == ["3"] else "cut/other") for v in [r["probe"].get("overlong_footer") for r in rows]))
print("bad align:", collections.Counter(str(r["probe"].get("bad_align")) for r in rows), "| span too big:", collections.Counter(str(r["probe"].get("span_too_big")) for r in rows))
print("groups on html:", collections.Counter(str(r["probe"].get("groups_on_html")) for r in rows))
# description versions
vers = collections.defaultdict(list)
for r in rows:
    if r.get("desc_hash"): vers[r["desc_hash"]].append(r)
print("\n== by description version (ordered by first run)")
for h, rs in sorted(vers.items(), key=lambda kv: min(x["first_ts"] for x in kv[1])):
    f = rs[0]["desc_flags"]; k = len(rs)
    col = sum(all(x["probe"].get(c) is True for c in ("col_desc_red3", "col_negative", "col_float_green2", "col_float_red3", "col_stacked")) for x in rs)
    print(f"  {h} {min(x['first_ts'] for x in rs)[:10]} words={rs[0]['desc_words']:4d} runs={k:2d} near(<=2)={sum(x['nfail']<=2 for x in rs):2d} colour_all={col:2d} html_after_thead={sum(x['probe'].get('html_place')=='after thead' for x in rs):2d} raise_overlong={sum(str(x['probe'].get('overlong_footer')).startswith('ERR') for x in rs):2d} flags={f}")
print("\n== effort vs outcome (median)")
import statistics as st
for label, sub in [("near (<=2 fails)", lambda r: r["nfail"] <= 2), ("far (>2)", lambda r: r["nfail"] > 2), ("colour all right", lambda r: all(r["probe"].get(c) is True for c in ("col_desc_red3", "col_negative", "col_float_green2", "col_float_red3", "col_stacked"))), ("own tests", lambda r: r["own_tests"]), ("no own tests", lambda r: not r["own_tests"])]:
    s = [r for r in rows if sub(r)]
    med = lambda k: st.median([r[k] for r in s if r.get(k) is not None]) if any(r.get(k) is not None for r in s) else None
    print(f"  {label:18s} n={len(s):2d} added_lines={med('added_lines')} tokens={med('tokens')} requests={med('requests')} minutes={med('minutes')} nfail_median={st.median([r['nfail'] for r in s]) if s else None}")
```
