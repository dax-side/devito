# Gates (v2)

Gates run in order. Each has a pass condition, a stop condition (what to do when it cannot pass) and what an edit makes stale. "Runner" means `runner/prove.sh` checks it automatically.

## G0 Repo and capability
- Pass: 500+ stars; every license is on the allowed list; no existing PR, issue or prior task covers the capability; the change crosses at least two files; a minimal honest solution clears 200 effective LOC.
- Stop: overlap at Scope Gate, or the minimal design falls under the floor. Pick a different capability.

## G0a Originality and scope probe (SCOUT mode)
- Visible half: no open or merged PR, issue thread, branch, fork or later upstream commit holds working code for the capability. Record the searches. Repeat just before submission.
- Hidden half: Scope Gate compares against the platform's corpus of past submissions, which cannot be searched. Lower the risk by choice (niche library, domain knowledge, genuinely new behaviour, not an obvious gap in a popular library), then confirm with an early Scope Gate run on a small probe (about 4 tokens).
- Stop: overlap or derivative verdict on the probe. Drop the capability; rewording does not help, because Scope Gate measures the capability, not the wording.
- Once committed, run Scope Gate last, since every description edit re-stales it; scaling inside the same capability keeps passing.

## G1 Behaviour inventory
- Pass: every behaviour in the solution diff is listed and marked either primary or validation. Validation (refusals, guards) is at most ~40% of new executable lines. Each row is tagged with its effective LOC (`effloc.py` on a patch containing just that group).
- Stop: validation dominates. Grow the primary feature, or pick a smaller task.

## G2 Description (runner: format scan)
- Pass: no headings, labels or lists; paragraphs of at most 150 words; ASCII only; no em-dash; no hard wrapping. Each inventory row has exactly one sentence, and each sentence carries one requirement.
- Pass: every universal word the scanner lists (any, every, all, whichever, always, never, exactly) is enforced on every entry route and sampled by a test. If not, name the tested cases instead.
- Pass: no restated legacy behaviour, and no list of exclusions.
- Stop: a behaviour can only be stated by naming an implementation detail. Cut the behaviour.
- Stale on edit: everything, including Scope Gate.

## G3 Tests (runner: grep gates, red state, green x3, base parity)
- Pass: zero new tests pass on clean base (JUnit count); new tests pass 3x with identical per-case outcomes; the existing suite gives identical per-case outcomes with and without the solution; grep gates clean (`match=`, exception text, private attributes, comments, tuple parametrisation, CRLF, `git diff --check`).
- Pass: each sentence is tested on the routes it names; breadth only where the sentence lists it.
- Rerun the red state after any change to an assertion's oracle (removing a match, loosening a tolerance, dropping a control), because a weaker oracle can turn a base failure into a base pass. Round 4 lost Verify Solution this way.
- Stop: a new test passes on base and no base-failing case exists for it. Delete it.
- Stale on edit: Verify Tests, Verify Solution, TQ, Task Quality.

## G4 Solution (runner: LOC floor, lint)
- Pass: effective LOC at least 250 by the effective executable count (added production lines, excluding blank lines, comments and docstrings; `runner/exec_loc.py` matches Auto Review). The passing agents' median should also clear 200, but a median under 200 is a warning sign rather than a rejection when the reference clearly clears 200 with no padding: wait for the human verdict before building a scope increase; `ruff check` and `flake8` clean on touched files; touches only the allowed production files.
- Pass: every stated refusal holds on every entry route. Probe each route by hand: array, pre-built object, rebuild, pickle, copy, and a shape that coincides with the legacy layout.
- Stale on edit: Verify Solution, SQ.

## G5 Mutants (runner: applies and runs each one)
- Pass: one mutant per promise and route; each is killed, or it survived and was triaged as dead path (move it), redundant on all routes (delete the code), or redundant on tested routes only (keep the code, record it).
- Stop: an in-scope survivor on a stated promise with no retargetable test case. Accept and record it, or narrow the sentence.

## G5a Coverage pre-check (before TQ)
- Run `coverage_precheck.md` in a fresh agent with only the description and the test file.
- Pass: every requirement row is "ok", or the remaining rows are recorded as accepted advisories.
- Fixes use parameter values or tighter assertions before new tests. Rerun the red state after any widened parameter list, then rerun the pre-check.
- Skip once the tests are frozen for rollouts.

## G6 Cheap platform checks
- Pass: prechecks, Verify Tests, Verify Solution (read the detail notes), and Flakiness are green on the exact bytes that passed the runner.

## G7 Quality checks
- Pass: TQ and SQ PASS on the same version with zero unfair tests; DQ and Task Quality PASS.
- Bulbs and partial rows are advisory. Record them and do not chase them (CLAUDE.md, who owns a finding).
- Stop: TQ and SQ trade findings for two rounds. The description is the suspect; narrow it.
- Stale: see G2 to G4.

## G8 Scope Gate
- Green on the final description. Stale after any description edit.

## G9 Auto Review
- No actionable finding, or a contest note that leads with a verifiable harness fact.

## G10 Rollouts
- Grade every run locally without caps. Run effloc.py on each passing run's production files (tests excluded); a median under 200 routes Auto Review to human review. Pass: at least one passes and at most 50% pass (aim for 20-30%), over at least ten counted runs.
- Stop: three runs fail on the same test. Clarify that sentence (consequence, not method) or trim scope 20-30% coherently. If all runs pass, add a discriminator drawn from real passing code.

- After the first 3-4 runs, before the rest: run `runner/traj_features.py <runs dir> <hint keywords>`. If passers and failers use the hints equally and the passing patches show no suspicious lines, the difficulty is real; do not strip hints. If only passers use a hint, that hint is doing the work. Then measure any candidate discriminator against the stored agent solutions (it must pass on the reference and fail some current passers) before adding it.

## G11 FP panel
- Audit every passing run locally. Close each real gap with a fair test (candidate fails, reference passes).

## G12 Submit
- Pre-submit checklist ticked on the exact uploaded bytes. md5s recorded.

## Budget
Estimated cost per round: test-only ~36 tokens, solution-only ~33, description ~73. Plan at most 2 description rounds and 6 other rounds. Stop description changes when the remaining revision tokens would drop below ~75.

## G13 Stop-loss (check at every platform round)
Pushing through a hard task is not wrong; it is a time choice. Each round costs tokens and part of a day that could start another task. So the tripwires below trigger a decision, not an automatic drop. Count them at every round and put the count in the report. One tripwire: note it. Two: ask the user whether to keep going as is, cut scope (MODE SCOPE-CUT), or move on, and recommend one. Three, or two after a cut: recommend moving on (MODE SCOUT) unless the user has said this task is worth the full day. The user's time budget (INPUTS) decides; without one, assume a task should reach rollouts within about a day.
- Rounds: more than 3 upload rounds on the same check (SQ, TQ or rollouts) without a pass.
- Whack-a-mole: each fix produces new findings of a different kind, twice in a row (the fix grows scope instead of closing it).
- Solver cost: a simulated agent (a stronger model than the platform's) needs more than 45 minutes, or passes no more than 90% of the tests, from the description alone.
- Rollouts: 0 passes in the first batch with more than 5 distinct failing tests per run (too wide, not one subtle core).
- Unguaranteeable core: the central promise needs a guarantee no finite method gives (an exact optimum over a continuum, arbitrary precision); SQ will keep finding counterexamples. Redefine it on a finite set or move on.
- Uncharted: the fix needs something nobody has written (new numerical method, compiler work, a proof of a bound) rather than code the repo or a textbook already shows.
- Size drift: the description passes about 600 words or the solution grows more than 30% beyond the first draft while fixing.
Decide early: the cheapest cut is before the first upload, the next cheapest before the first rollout batch.
