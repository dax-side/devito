# Platform patterns: every real flag, and the check that catches it before upload

Built from the platform's own results on max_stable_dt and curvilinear, not from local emulations. Run this list on every description and test file before any LLM pre-check. A row is done when its check passes on the exact files you will upload.

## TQ: partial rows and coverage suggestions

| # | Real flag | Pattern | Check |
|---|---|---|---|
| T1 | "A cartesian Grid behaves as before" -> partial | Broad wording no assertion can pin ("as before", "unchanged", "any other use", "correctly") | Every sentence names only what an assertion checks. Grep the description for: before, unchanged, correctly, properly, always, never, any other use |
| T2 | "raises ... before any other use of these arguments" -> partial | Ordering or timing words ("before", "first", "then") with only an exception-class assert | Drop ordering words unless a test observes the order |
| T3 | "converges as the spacing tends to zero" with one refinement pair -> partial | A limit or asymptotic claim tested at one step | A limit claim needs at least two successive steps on every cell it covers, or drop the limit wording |
| T4 | "one less than the number of points" with shape always (5, 5, 5) -> partial (predicted, fixed before upload) | A stated quantity never varied | For every quantity the text names (point count, dtype, sign, system, dimension, family) the tests use at least 2 values, and a value that differs across axes where axes matter |
| T5 | 3D only at the coarse bound -> suggestion | A stated range sampled at one end | Sample the end and one interior value of every stated range |
| T6 | Threshold 1.6 vs promised factor 3.1 -> "not discriminating" | Test threshold weaker than the stated number | Every number in a test equals the number in the text, or the test is stricter only where the text is stricter |
| T7 | "may" sentence with no test (max_stable_dt) | A permission with no test | Each "may" needs a test that passes on either outcome, or it is a "not required to work" list |
| T8 | Sentinels (0.0, inf) with no range (max_stable_dt) | Open promise | Every sentinel has a stated, tested window; "may" outside it |

## TQ: unfair

| # | Real flag | Pattern | Check |
|---|---|---|---|
| U1 | Asymptotic promise, finite cutoff 1.6 at fixed sizes | Test pins a number the text does not state | Every threshold, size and tolerance in a test is stated in the text as a property of the result |
| U2 | Extent plus spacing both given (VCA proposal, removed) | Test pins behaviour on a combination the text never mentions | Drop, or state it |

## Pre-check (leakage)

| # | Real flag | Pattern | Check |
|---|---|---|---|
| P1 | "The tests measure this order on two domains ..." | Text describes the tests | Never write "test", "tests", "checked by"; state numbers as properties of the solution |
| P2 | Description over 1000 words (max_stable_dt) | Length | gates.py desc at most 950 |

## SQ (the reference must hold on everything the API accepts)

| # | Real flag | Pattern | Check |
|---|---|---|---|
| S1 | Grid built with a ConditionalDimension crashed the reference | New code builds devito shortcut names from d.name | Probe the reference with every Dimension kind Grid accepts (SpaceDimension, ConditionalDimension, custom names); use d.root.name for shortcuts |
| S2 | MPI empty rank (max_stable_dt) | Distributed layouts | Probe under the MPI layouts the repo tests use, or scope them out in words |
| S3 | Float32 default made a convergence promise false | Default dtype | Probe every numeric promise at the default dtype, or state the dtype |
| S4 | A new field broke a finite promise (curvilinear, found locally) | Open class of inputs | Probe a random and a targeted worst case over the stated window before writing the number; keep 15% margin |

## FP (passers)

| # | Real flag | Pattern | Check |
|---|---|---|---|
| F1 | Two sentences pulling apart (max_stable_dt) | Passer disagrees with the reference inside a stated range | Sentence-by-sentence sweep on every passer (fp_screen.py) |
| F2 | Passer correct only on the tested path (run 4: dtype check skipped on the spacing path) | A rule reachable by two routes, tested on one | Every stated rule tested on every route the text names (extent and spacing, weights and w) |

## Order

1. T1 to T8, U1, U2, P1, P2 by reading the two files side by side (15 minutes).
2. S1 to S4 as probes on the reference.
3. One Opus adversarial round (clause by clause, told these patterns). Stop after three rounds.
4. Upload once.

## Auto Review (approved with notes)

| # | Real flag | Pattern | Check |
|---|---|---|---|
| A1 | `float(np.real(x))` in validation rejected a positive np.longdouble | Narrowing numeric values before comparing | Grep the solution for `float(`; probe every validation with float16/32/64/longdouble |
| A2 | Polar-angle sentence overloaded | Several rules in one sentence | One rule per sentence; gates.py flags sentences over about 45 words |

## Go tasks (cobra probe)

| # | Real flag | Pattern | Check |
|---|---|---|---|
| G1 | Pre-check "problem and tests aligned": tests matched exact AddArgument error strings the description did not give | Exact error text asserted but not stated | Assert only that an error is returned, unless the description quotes the text word for word |
| G2 | Pre-check sanity: `go test -skip` called unsupported | Flags newer than the base image's Go | Use `go test -list` plus `-run` to exclude tests; works on every Go version |
| G3 | (found locally) New `_test.go` in the package breaks the build of the old tests on the clean repo | Go compiles all test files of a package together | Put new tests in their own folder as an external test package; base mode runs only the old packages |
| G4 | Dockerfile must start with the olympus-base-go image and WORKDIR /app | Results file | Install go-junit-report in the Dockerfile; test.sh adds $(go env GOPATH)/bin to PATH |

## From tabulate (dropped after 50 versions; full detail in postmortems/tabulate.md, lessons 43-84)

| # | Real flag | Pattern | Check |
|---|---|---|---|
| D1 | DQ minor wording notes, contest refused | DQ can no longer be contested | Fix every DQ finding; batch them with the round's other description edits |
| D2 | DQ AI detector 0.74-1.0 on spec-style prose, cannot be contested | Dense rule-per-sentence prose scores as AI, whoever writes it | Author writes the prose; probe a 250-word sample before writing the whole text |
| D3 | DQ length gate: pass <=200, warn 201-400, fail >400 (`\w+`) | Long specs | Budget <=385 from the first draft |
| S9 | Same solution, three SQ runs, three different mediums | SQ samples edges each run | A medium on a PASS is not a blocker; close known mediums in one bundle, re-run once |
| S10 | "If omitted/None nothing different" broken by normalisation run on every call | Shared code changed without gating | Default-path differential (omitted AND None), wide matrix, 0 differences |
| S11 | Footer reused a base helper and inherited its bug (colour regex has no minus sign; wrap helper crashes on coloured numbers) | Promise reuses a buggy base helper | Probe the helper's input classes (sign, numeric strings, bytes, digits inside codes); crash-fuzz value kinds x options |
| U6 | Test demanded a base-bug fix the text never stated (ragged rows + maxcolwidths) | Better-than-base without saying so | A test may require a base fix only when the text states it, with an example |
| U7 | Test over-demanded the literal wording ("after thead") | Placement words read literally by agents | When a reviewer says a test over-demands the wording, relax it before the next batch |
| F3 | Passer showed bytes as b'abc' and lost Decimal precision; text silent | Panel grounds findings in base behaviour, not only the text | Every value class the new code renders gets an exact-output test where base has a data-cell equivalent |
| F4 | Passer padded every table on every call (5724/23328 default calls differed) | Default path changed | Default-path differential before every panel; any difference = do not send |
| F5 | Header line missing above the footer when there are no rows | Degenerate inputs never swept | Pre-FP sweep: no rows, headers only, new part only, no headers, every format |
| F6 | Separator dropped with groups + footer, no headers, no rows | Product of optional parts | Sweep the full product of optional parts in every format |
| R1 | Every run failed a graded check placed in an existing repo test file | Platform merges test.patch into the agent's edited copy | Graded checks only in new test files |
| P3 | Test file name predictable (tests/test_url_template.py) | The checker guesses ~90 likely names from the feature | Name every new test file with a random hex suffix: test_<name>_<openssl rand -hex 3>.py; for toolchain-mandated names randomise the parent directory |
| D4 | Dedupe "derivative" with no PR on GitHub (yarl #327) | Other writers' submissions on the same open issue | Open issues are mined; prefer unfiled gaps, and submit the small probe before any build-out |

## Dockerfile base images (platform list, Oct 2026)
Python `olympus-base-python`, TypeScript/JavaScript `olympus-base-typescript`, Go `olympus-base-go`, Rust `olympus-base-rust`, Java/JVM `olympus-base-jvm`, C++ `olympus-base-cpp`, all at `public.ecr.aws/d3j8x8q7/<image>:latest`. Template: FROM image, WORKDIR /app, COPY . ., install everything at build time (the runtime container is offline), CMD ["/bin/bash"]. Avoid `pip install -e .` (warning); prefer pinned installs.
