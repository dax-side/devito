# Runner

All scripts are in `runner/`. They need Python 3.10+, git, and a virtualenv with the repo's dependencies plus pytest, ruff and flake8.

## One-time setup
```bash
WORK=/path/to/scratch            # anything writable
git clone <repo-url> $WORK/base && git -C $WORK/base checkout <pinned-sha>
python -m venv $WORK/venv && $WORK/venv/bin/pip install -e $WORK/base pytest ruff flake8
```

## Full proof (run before every platform round)
```bash
WORK=$WORK BASE=$WORK/base VENV=$WORK/venv \
  runner/prove.sh <sha> solution.patch test.patch description.txt out/proof [mutants/] [previous/proof]
```
The last line of `out/proof/log.txt` is `RESULT GO` or `RESULT NO-GO` with the reasons.

| Step | Check | NO-GO when |
|---|---|---|
| 1 | md5 of the three artifacts | never (record only) |
| 2 | files each patch touches; CRLF | any CRLF |
| 3 | description scan (`gates.py desc`) | label, list, paragraph over 150 words, non-ASCII, dash, hard wrap. Universal words are listed as advisory |
| 4 | test grep gates (`gates.py tests`) | `match=`, exception text, private attribute, comment, CRLF, tuple parametrise |
| 5 | effective LOC (`effloc.py`) | below `LOC_FLOOR` (default 200) |
| 6 | fresh worktrees, patches apply, `git diff --check` | any failure |
| 7 | `ruff check` and `flake8` on touched .py files | any finding |
| 8 | red state: new tests on base (`junitcmp.py passing`) | any new test passes on base |
| 9 | green x3 identical, and base parity with and without the solution | any difference or failure |
| 10 | mutants, run in parallel (`JOBS`) | a mutant that does not apply. Survivors are reported for triage (gates.md G5), not NO-GO |

## Skipping slow mutants on reruns
Set `SKIP_MUTANTS` to an extended regex of mutant names, e.g. `SKIP_MUTANTS='M4_no_allowance'`. Skip only a mutant that was already killed by many tests in an earlier full proof of the same tests, and run the full set again whenever the tests change. On max_stable_dt, M4 (no growth allowance) took about 20 minutes, four times the rest of the mutant step, and was always killed by 50 tests.

## Hangs
Every test.sh run is wrapped in `timeout $TEST_TIMEOUT` (default 1800 s); a timeout is a NO-GO. The only real hang seen so far was not slowness: a run killed mid-compile leaves `/tmp/devito-codepy-uid*/<hash>/lock` behind, and every later compile waits on it forever (a stuck run sits at low CPU inside `codepy/jit.py` CacheLockManager). prove.sh deletes stale locks at start; delete them by hand after killing any run. Never kill processes with `pkill -f <pattern>` when the pattern also appears in your own command line: it kills your own shell.

## Mutants
Write a spec file (see `runner/mutants_spec.example.py`): `MUTANTS = {name: (file, exact old text, new text)}`, one per promise and per route. Then:
```bash
runner/mkmut.py spec.py <tree-with-solution-applied> mutants/
```
Every anchor must occur exactly once; the script says which ones do not.

## Single tools
```bash
runner/gates.py desc description.txt      # format scan
runner/gates.py tests test.patch          # grep gates
runner/gates.py touched solution.patch    # files touched
runner/effloc.py solution.patch           # effective LOC, total and per file
runner/exec_loc.py <tree> solution.patch  # effective executable LOC (A), the count Auto Review uses
runner/junitcmp.py passing red.xml        # red state
runner/junitcmp.py same a.xml b.xml       # identical outcomes
```

## Rules the runner cannot check (do these by hand)
- Every stated refusal holds on every entry route (G4). Write a short probe script that builds each route and prints what happens.
- Each sentence carries one requirement, and each universal word is backed by the code and a test (G2).
- Survivor triage (G5).
