# Handoff (pick up here)

## Digest status
- Submitted: solution.patch 2aaead35, test.patch 79b05829, description 1db79703 (all in outputs/resterm_digest, md5.txt).
- TQ PASS, SQ PASS 3/3, FP panel clean, pass rate 3/10, flakiness fixed (4 flaky base tests left out).
- Waiting on Auto Review. If S1 (empty Authorization header) comes back: paste outputs/resterm_digest/CONTEST_NOTES.md (human route).
- Working copy: scratchpad/rt/ref (both patches applied, uncommitted). Agent runs: scratchpad/digest_runs1-3.

## Maintenance to do (in order)
1. One short playbook: merge ONE_SHOT.md, lessons.md, rulings.md, calibration.md, outputs/rollout_analysis/REPORT.md rules. Drop stale parts.
2. Scripts: quickcheck.sh (clean/ref new mode + lint + touched pkgs), rebuild.sh (patches + NEW_TESTS + test-count guard vs last upload), grade_runs.sh (apply each agent patch + tests/probes, print fails).
3. After the platform's check updates: read release notes, adjust playbook.
Skipped: SigV4 (deleted), outputs/ trim (optional).
