# FP gap prompt (10 points)

Run this on the tests before every upload and after every FP verdict (lesson 70). Source: postmortems/tabulate.md, Appendix C.


Do a deep and complete analysis on finding critical gaps that could allow an incorrect, incomplete,
hardcoded, overly simplified, or otherwise buggy implementation to pass all tests.
Review the following points; if missing from the tests, fix them:

1. Missing behavioral scenarios that are required by the problem description.
2. Edge cases that are not validated.
3. Boundary conditions that are not exercised.
4. Error handling or failure cases that are not covered.
5. State transitions, interactions, or combinations of behaviors that are not tested.
6. Cases where a partially correct implementation could still pass.
7. Cases where a hardcoded or shortcut solution could pass.
8. Cases where an implementation that handles only the tested examples, rather than the general behavior, could pass.
9. Cases where tests verify only common paths and miss important alternative paths.
10. Situations where different valid inputs should produce different outcomes but the tests do not verify those distinctions.

How to apply it here (keeps tests permissive, lesson 69):
- Walk the description clause by clause; each clause needs a test that a wrong implementation fails.
- Fix a gap with a behaviour check (position, order, merged or not, exact value), never a whole-table string.
- Do not add a test for anything the description does not state (unstated = untested).
- Then replay every run and sweep any passer (RUN step 11) before the FP panel.

