# Rollout playbook (run this the moment agent results land)

Source: tabulate post-mortem §8 (independent analyst) and §10, plus the CBOR round. Everything here is
mechanical: execute, paste the numbers, act on the decision row.

## 0. Inputs
- The platform zip: one folder per run with `junit-new.xml`, `junit-baseline.xml`, `eval-result.json`,
  `solution-patch.patch`, `trajectory.json`.
- `runner/rollout_analyze.py`, `runner/<task>/units.json` (test -> behaviour unit), `runner/<task>/all_tests.txt`.
- Probes: `runner/<task>/probe_default/` (old API only) and `runner/<task>/probe_feature/` (new API, S/O tagged).

## 1. Order of work
1. Read every failing run's `eval-result.json` first. A failure the evaluator calls "reasonable" or
   "undocumented" is OUR bug (unfair test or open sentence). Fix it before anything else.
   CBOR: run 6 failed 72/72 at compile time because `Rat()` returned `(*big.Rat, error)`; the text never
   fixed the signature. Fix: call `Rat` through reflection in the test, or state the signature.
2. Run the analyzer (section 2).
3. Run the FP probes on EVERY passer before deciding anything (section 4). The FP findings are the cheapest
   source of discriminators: a passer that differs from the reference on a stated sentence is both an FP
   risk and a ready-made test that lowers the pass rate.
4. Decide with the table in section 3. Change tests first; change the description only if a test needs a
   sentence that is not there.

## 2. The maths (what rollout_analyze.py computes)
| Quantity | Formula | Use |
|---|---|---|
| Pass rate | p = (passes + 0.5) / (k + 1) | headline estimate (MAE ~0.06 at k = 8) |
| Interval | 95% Wilson on passes/k | how sure |
| Unit rate | r_u = (runs passing every test of unit u + 0.5)/(k + 1) | which behaviour is hard |
| Predicted pass rate | product of r_u | early forecast; lowest r_u is an upper bound |
| Wall | a test failing in >= k-1 of k runs | spec or trap problem |
| Blocker | r_u < 0.30 | must add an example/rule or relax a test |
| Redesign | product < 0.05 with 0 passes | cut or redesign before more runs |
| Band | >= 1 pass and <= 50% over >= 10 counted runs; aim 20-30% | gate |
| Forecast | P(>=1 pass in n) = 1-(1-p)^n; P(>50%) = binomial tail | how risky the next batch is |
| LOC | median effective production lines of passers >= 200 | Auto Review floor |
Caveats: a compile failure fails every unit at once (ignore the product, use the raw rate). Never pool runs
across description versions (70% false alarms). Identical wrong output in >= 3 runs = spec/test problem.

## 3. Decision table
| Result | Action |
|---|---|
| A failure the evaluator calls reasonable/undocumented | Fix the test (or state the rule). Not an agent failure. |
| > 50% pass | Add discriminators from FP probe S-differences (passers wrong on a stated rule). Each new test must pass on the reference and fail at least one current passer. |
| 0 passes, product < 5% | Redesign; find the wall; add an example for it (A1/A2). |
| A wall with identical outputs | Spec or test is wrong; fix that, not the agents. |
| 20-50% and FP probes clean | Freeze; run the counted batch. |

## 4. Pre-FP checklist (post-mortem §4 targets, CBOR wording)
Run on every passer; compare with the reference (and with base for target 1).
| # | Target | CBOR probe | Do not send if |
|---|---|---|---|
| 1 | Default path unchanged | probe_default: 2,330 encode/decode cases on old API, base vs passer | any difference |
| 2 | Degenerate values | zero, -0, zero-value big.Float/big.Rat/DecimalFraction, nil pointers, omitempty | difference on a stated rule |
| 3 | Base-helper collisions | parts decoded through generic paths (IntDec, BigIntDec leak), BigIntConvertNone | difference |
| 4 | Every accepted form | value vs pointer, struct fields, any, map values | difference |
| 5 | Existing options x new | TagsMd, IndefLength, UnrecognizedTagToAny, IntDec, BigIntDec, Canonical | crash; difference on a stated rule |
| 6 | Siblings | TagSet, Wellformed, RawMessage/Tag destinations, stream Decoder position | broken behaviour |
| 7 | Literal words | "smallest int", "smallest decimal", "either positive or negative", "bigger then" (boundary) | contradicts the literal reading and the tests allow it |
| 8 | Open sentences | exactly-at-limit, tag 21-23 wrappers, Rat() signature, pointer vs value in any | decide before the panel |
| 9 | Unstated bad input | huge exponents (hang/OOM), int64-overflowing exponents, indefinite arrays | crash, hang (TIMEOUT), or unclean error |
| 10 | Product of options | value mode + UnrecognizedTagContentToAny + IntDec | difference on a stated rule |
Verdict rule: a difference on a stated (S) line = do not send; add a test. A difference on an open (O)
line = compare with base convention; if base has an equivalent, match it; otherwise decide and state it.

## 5. Levers that raise or lower pass rate (analyst A1-A11)
- Lower (too easy): turn S-differences into tests; replace an example that gives the answer away with one
  that does not (an example is copied 9/9; a variation without its own example falls to ~1/9, A2).
  Prefer a test value the naive approach gets wrong over a new sentence.
- Raise (too hard): add an example for the wall behaviour (21/73 -> 9/9 with one example); state errors
  you test (unstated validation 0/9); fix open sentences (coin flip 50/50).
- Never: judge by agent self-reports (82/82 claim success); expect agents' own tests to help (A8).
