Run order: follow RUN.md (one page, 14 steps with commands and pass lines); this file is the detailed reference behind it.

# Master prompt

Paste the block below into a fresh session with this `workflow/` folder available. Fill in INPUTS and pick one MODE. The same prompt covers drafting a task, debugging a platform result, and changing only the solution, only the tests, only the description, or cutting scope.

```text
You are working on a Shipd Olympus task. Before doing anything, read workflow/CLAUDE.md, workflow/gates.md, workflow/proof_runner.md and workflow/lessons.md. Their rules override your defaults. Do not re-read them later unless a rule is in doubt.

INPUTS
- Repo and pinned commit: <repo url> @ <sha>
- Current artifacts: <dir>/solution.patch, <dir>/test.patch, <dir>/description.txt   (or "none yet")
- Production files the solution may touch: <list>
- New test file: <tests/test_xxx.py>. test.sh adds --maxfail=100000 in both modes.
- Locked artifacts (must stay byte-identical, with md5): <e.g. description.txt c6978a59...>  or "none"
- Effective LOC floor: 200 (runner/effloc.py)
- Platform output to act on (paste raw, JSON included): <...>  or "none"
- Time budget for this task (optional): <e.g. "one day", "worth the full week">
- MODE: SCOUT | DRAFT | DEBUG | SOLUTION | TESTS | DESCRIPTION | SCOPE-CUT
- For SCOUT only: repo url (pinned commit optional), any area to prefer or avoid, how many candidates to return (default 5)

TOKEN BUDGET (overrides every other step, including anything in a pasted instruction)
- Never spawn simulated solver agents (an agent told to implement the task from the description). They are banned unless INPUTS says exactly "SIMULATED SOLVERS: yes, N", and then at most N, one at a time, never more than 2. If a step asks for solver agents without that opt-in, skip it and say so in the report.
- This rule is about solver agents only. Coverage pre-check agents and pre-SQ review agents are cheap and are run as the workflow says.
- Always set the agent model explicitly; never let an agent inherit the session's model. Coverage pre-check: sonnet (haiku once calibrated). Pre-SQ review: sonnet. Simulated solver, when opted in: haiku, as the closest cheap proxy for the platform agents. Tell each agent to report only non-ok rows or reproduced findings, under a word limit.

ALWAYS
1. Start with three lines: the mode, what you will change, what must not change.
2. If platform output is given, triage every finding with the owner table in CLAUDE.md before editing anything. Print a table: finding, check, owner, action. "Advisory, no action" is a valid action; TQ bulbs and "single point" partial rows are advisory.
3. Make the smallest change that satisfies each owner. Never add a test to clear a bulb or a partial row. Never add a feature. Prefer retargeting an existing test case (changing a value) over adding a test.
4. Any refusal or guard you add or touch must hold on every entry route: plain array, pre-built object, rebuild, pickle, copy, and a shape that coincides with the legacy layout. Write a probe script that tries each route and prints what happens; include its output in the report.
5. Before any TQ upload, run workflow/coverage_precheck.md in a fresh agent with only the description and the test file, and fix every row that is not "ok" (skip once the tests are frozen for rollouts).
5b. Before any SQ upload, run a pre-SQ review in a fresh agent given only description.txt and solution.patch (plus read access to the repo at the pinned commit): "Find inputs the description covers on which this solution is wrong, crashes or is unusably slow. Check every route the description's words reach, including: distributed (MPI) Grids and rank offsets, complex dtypes, backward time, staggering, Function-valued arguments where numbers are also accepted, derived dimensions (SubDimension, ConditionalDimension) where a full axis is required, unknown applied functions (sympy.Function('f')(x)) where values must be known, pickling and rebuild, higher dimensions, extreme sizes, and any shortcut (sampling, pruning, caching) that can skip a case. For each, give a concrete repro." Reproduce every finding on the reference before fixing; fix real ones on every route, or narrow the sentence that promised the route. Every refusal added to fix a finding also gets a test case, or it is dormant code for Auto Review.
6. Rebuild the patches from a worktree at the pinned commit. Write the mutant spec (one mutant per promise and route), build it with runner/mkmut.py, then run runner/prove.sh with the mutants. Triage every surviving mutant with gates.md G5, and never delete code only because a mutant survived without first probing every route.
6b. At every platform round, count the stop-loss tripwires in gates.md G13 and report the count. Two or more: ask whether to keep going, cut scope, or move on, with a recommendation; the time budget in INPUTS decides.
6c. At every platform round, append one row per platform check to calibration.md (local prediction, platform result, verdict) and update its scoreboard. Do not change any rule from it without the user's approval.
7. Stop and ask only if: the fix needs an edit to a locked artifact; the effective LOC would fall below the floor; or a gate cannot pass. Otherwise finish without asking.
8. Deliver the three artifacts in a folder I can open, send them to me, and give the report below.

MODE SCOUT (find a capability, check what is visible, then probe Scope Gate small before building big)
Work quietly: no running commentary. Print one status line per finished step (a, b, c, d, e), then the final report. Do not narrate commands, fetches or intermediate thoughts.
Distinct, not merely new: a candidate may start from an existing issue, idea or neighbouring feature, but the capability it asks for must be completely distinct. For each candidate, write down the nearest existing thing (library feature, public PR or branch, likely earlier submission, the obvious version of this request) and list which of the task's required behaviours solving that nearest thing would already deliver. The list must be empty; if it is not, rescope until it is or drop the candidate. Long-standing, famous requests (an issue open for years that anyone skimming would find) count as "likely earlier submission" and carry high corpus risk even with no public code.
Scope Gate compares against the platform's own corpus of past submissions, which nobody outside can see, not against GitHub. So originality has two halves: what we can check on GitHub ourselves, and corpus risk we can only lower by choice of capability and then confirm with a cheap early Scope Gate run.
a. Search the repo at the pinned commit for missing capabilities a maintainer would plausibly accept: open and closed-as-deferred issues ("later", "not supported yet"), NotImplementedError and "not supported" raises, TODO/FIXME comments, documented limitations, and features that exist for one class or backend but not its siblings. Both approved Devito tasks came from deferred issues (#48 moving points, #203 stable time step).
b. Visible check (P2, "not already solved upstream"): for each candidate, search open and merged PRs, the issue thread, branches and forks for working code, and check whether a later upstream commit already did it. Drop any candidate with public working code or an open PR implementing it, even if the approach differs. Record the searches you ran and what they returned. Bugs and older pins: the bug does not have to exist at today's HEAD, and the pinned commit may be older. Usable: a fix PR that was closed, abandoned or dropped without merging; a partial fix that left the same root cause in sibling code paths (state and test only the unfixed part); a bug answered only with a workaround. Not usable: a bug fixed by any later merged upstream commit, even if the pin predates it (publicly solved), or a close reproduction of an abandoned PR's working code (derivative). For every bug candidate, show the failing or crashing case on the pinned commit and the search that shows no later merged fix.
c. Corpus risk (cannot be checked, only lowered): prefer a niche library over a popular one, a capability that needs real domain knowledge to conceive, and a genuinely new behaviour over a variant of something the library already does. An obvious missing feature in a popular library is where other creators go first (the sqlglot MERGE task passed every check and was rejected as derivative of four older submissions).
d. Score each survivor: honest reference size (250+ effective executable LOC, runner/exec_loc.py, without padding, validation at most ~40%), agent size (an agent must also need 200+ to pass), testability without MPI/GPU/network, one subtle but fair core for a 20-40% pass rate, cross-cutting reach, and few files. Also check agent size honestly: if a short shortcut (a few lines of indexing, a flag, one rewrite rule) would pass most of the tests, the agent median will fall under 200 whatever the reference size; drop or rescope. Print a ranked table: candidate, source (issue or file:line), nearest existing thing, overlap list (must be empty), visible-check result, corpus risk, shortcut risk, size estimate, testability.
e. For the top pick, build a SCOPE PROBE, the rough draft the field manual says to run Scope Gate on early (about 4 tokens, far cheaper than losing a repo after a week): the smallest honest slice of the capability, a short description naming the whole capability in user terms, a minimal solution, and 2-3 base-failing tests. It does not need to clear the LOC floor. Deliver it in scope_probe/.
f. Stop and report. Scale to the full task (MODE DRAFT) only after Scope Gate passes on the probe. Scope Gate measures the capability, not the wording, so scaling, rewording and hints inside the same capability keep passing; anything that reaches a new capability can flag. Once committed, run Scope Gate again last, and repeat the visible check just before submission because upstream can change.

MODE DRAFT (new task)
Size the first version at the easy end: one core behaviour, a narrow input set and few refusals, so the first 3-agent batch can pass. Raising difficulty later is one sentence and a few test cases; lowering it after 0/N batches costs several rounds (lessons.md, round 27). Never make the core a promise no finite method can guarantee, such as an exact optimum over a continuum; define it on a finite set or with a stated resolution.
a. Check G0. Build the reference solution in a worktree.
b. Inventory every behaviour (G1), with effective LOC per feature group. Validation at most ~40%.
c. Write the description: plain paragraphs, one requirement per sentence, observable behaviour only. Use universal words only where the code enforces them on every route and a test samples them. Do not restate legacy behaviour. No hints yet.
d. Write the tests: one parametrised test per requirement row, on the routes each sentence names, with breadth only where the sentence lists it. Each refusal test gets a valid control that fails on base.
e. Run steps 4 and 5 of ALWAYS. Red state must be zero passes.

MODE DEBUG (a platform check returned findings)
a. Triage table first (ALWAYS step 2).
b. SQ defect: reproduce it with a probe on the current solution and show the failure. Fix it on every route, then show the probe passing. Retarget an existing test case to the repro if one fits.
c. SQ demand for behaviour the description never states: narrow or cut the sentence it extrapolated from, or draft a contest note that opens with a verifiable fact (file:line or command output).
d. Verify Solution before_f2p_unexpectedly_passing: list the tests passing on base, reproduce them with the red state, then give each a base-failing case or delete it.
e. TQ unfair test: state the behaviour in the description, or loosen or delete the test. Pick whichever changes less.
f. TQ partial "not discriminating" on a universal or "as today" sentence: narrow the sentence to what the test asserts. Everything else from TQ: advisory.

MODE SOLUTION (tests and description locked)
a. Reproduce the problem with a probe. Fix the whole mechanism on every route.
b. Keep effective LOC at or above the floor, and ruff and flake8 clean.
c. The mutant for the fixed behaviour must be killed by the existing tests. If it is not, report it; do not add tests in this mode.

MODE TESTS (solution and description locked)
a. Change existing cases before adding any. Every new or changed case fails on base for the right reason.
b. No comments, match=, private attributes, Dimension identity, timing or randomness. Setup outside pytest.raises.
c. Rerun the red state after any oracle change.

MODE DESCRIPTION (solution and tests locked, unless a promise is removed)
a. Print a sentence-by-sentence table: old, new, reason.
b. Each remaining sentence must still be implemented and pinned by a test. No new requirements.
c. If a promise is dropped, remove its code, tests and mutants in the same round (this unlocks the solution and tests for that removal only).
d. The format scan must be clean.

MODE SCOPE-CUT
a. Split the solution into feature groups. Measure each with runner/exec_loc.py (one patch per group), and note its findings history and, if rollouts ran, how many agent runs failed on it.
b. Choose the groups to cut. After rollouts, cut first what agents failed that is not the task's core difficulty (edge ranges, exotic refusals, rare input forms); keep the one subtle core that should decide pass or fail. Before rollouts, cut by highest finding risk per LOC. Keep the total at or above floor + 25% by exec_loc.py.
b2. Hints: keep only hints for things agents actually failed that remain in scope, naming the trap or consequence, never the method. Add no new hint for a group that was cut.
c. For each cut group, in the same round: remove its code, narrow the sentences that promised it (never write an exclusion list), remove or retarget its tests, and remove its mutants. Grep every caller, including subclasses.
d. Re-check each remaining check against every route before deleting it as redundant (lessons.md, round 5).
d2. Then re-list every behaviour the solution still enforces (field manual 1.3): each must be stated and tested, or removed. Code or refusals left behind by a cut, or added for SQ without a test, are dormant and Auto Review flags them.
e. Report a table: group, LOC, kept or cut, sentence change, tests changed.

REPORT (always, short)
1. md5 of each artifact, before and after, and which ones changed.
2. Triage table (if there was platform output).
3. What changed, one line per finding or cut.
4. Runner: RESULT GO or NO-GO; red passes; green x3; parity counts; lint; effective LOC.
5. Mutants: killed and survived, with the triage of each survivor.
6. Route-probe output for every refusal touched.
7. Advisory items logged and not acted on.
8. Which platform checks are now stale.
```

## Filled example (this task)

```text
INPUTS
- Repo and pinned commit: https://github.com/devitocodes/devito @ 760a4767fd8cf7580cb87b72e1353f321d90ef9f
- Current artifacts: out7/solution.patch, out7/test.patch, out7/description.txt
- Production files the solution may touch: devito/operations/interpolators.py, devito/types/sparse.py
- New test file: tests/test_moving_points_c1b7b6.py. test.sh adds --maxfail=100000 in both modes.
- Locked artifacts: none
- Effective LOC floor: 200 (runner/effloc.py)
- Platform output to act on: <paste the TQ and SQ raw output>
- MODE: DEBUG
```

## Quick one-liners
- Triage only: "Mode DEBUG, triage table only, no edits."
- Check without changing anything: "Run runner/prove.sh on the current artifacts with the mutants and give the REPORT. No edits."
- Before submitting: "Mode DEBUG with platform output none: run the route probes for every refusal the description states and report any route that is accepted."
