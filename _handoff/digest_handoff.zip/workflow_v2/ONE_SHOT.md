# One-shot TQ and SQ

Goal: upload once and pass TQ and SQ. Before uploading, the work loops locally against mock graders (at most 3 rounds), never against the platform.

## Why rounds were lost (all real)
| Lost on | Cause | Fix in this file |
|---|---|---|
| TQ unfair (digest cnonce uniqueness) | The pre-TQ agent proposed a stronger assertion and I applied it without checking the text | Rule A: graders only flag; any new assertion must quote the sentence that states it |
| SQ: creds lost on @retry/@poll | Probed only a single plain request | Route matrix R below |
| SQ: https to http redirect answered | Redirect probe covered origin only, not scheme | Route matrix R |
| SQ: qop checked after the pick, so a usable challenge was skipped | A "choose the best" rule applied a usability check too late | Rule C: every usability condition applies at selection time |
| SQ: -sess with no qop | Two stated options never crossed | Rule X: cross every option pair |
| SQ low: no IntelliSense | No parity check against the existing analog | Parity list P |
| tabulate SQ x3 | Same as Rule X and the route matrix (combinations, caller-built objects) | Same |

## Steps (in order; do not upload until step 5 is clean)
1. Local proof: harness new/base x3, lint 0, a mutant per promise.
2. Self-check (15 min, no agent):
   - **R (routes):** list every way a request reaches the feature: a plain request, @retry, @poll, a same-origin redirect, an other-origin redirect, an allowed origin, https to http, http back to https, the user's own header, streaming/ws/grpc (excluded in words). Every row is tested or excluded in the text.
   - **X (crosses):** for every pair of options/parameters the text names, probe the reference on the pair.
   - **C (choice rules):** for any "pick / prefer / first wins" rule, put a challenge that is unusable for each separate reason in front of a usable one, and check that the usable one wins.
   - **P (parity):** the closest existing feature (here basic auth) is touched in: parser, writer, explain, secrets redaction, IntelliSense with its test, docs. Match it.
   - **G (guards):** every refusal in the code has one sentence and one test, and every sentence has a test.
3. Mock TQ (Opus, fresh, given only description + test file + platform_patterns.md T/U rows). Output uses the TQ report format: a verdict, an unfair list and a coverage table. Rule A: it may not suggest an assertion unless it quotes the exact words that state it.
4. Mock SQ (Opus, fresh, given description + solution.patch + repo access, told the route matrix R and S rows). It must write and run real probes against the reference, not just read the code. Output: High/Medium/Low, each with a repro that ran.
5. Fix, rerun only the mock whose input changed. Stop at 3 rounds; if it is still failing, the description is too wide (G13).
6. Upload once.

## Rule A (fairness of any test change)
A test assertion is allowed only if a sentence in the description states it. Quote that sentence next to the assertion in the agent's report. "Good practice" or "RFC says" is not a sentence; for those, either add the sentence or leave it untested.

## Added after digest round 2
- TQ graded an old description: its quotes ("It would be nice...") were already removed. Before each upload, compare the md5 of the pasted description with md5.txt, and check one new sentence appears in the TQ quotes.
- SQ medium: a byte cap (io.CopyN 64KiB) is not a time cap. Any read before a retry must be unread-close or deadline-bound. The mock SQ ran "unending body" but its server sent bytes; also probe a server that sends headers then stalls.

## Closure checklist (from every real TQ/SQ note so far; run before every upload)
TQ "not discriminating" and quality notes come from four test-side patterns:
1. Every describing word (random, case-insensitive, first, sorted) needs an assertion that a constant or ignoring version fails. Use the weakest form: "not the same value 5 times" for random. Never uniqueness: an earlier TQ marked that unfair.
2. Every standard the text names, including in the title, makes the test parsers as strict as that standard's MUSTs. For RFC 7616 that means: username, realm, nonce, uri, response, cnonce and opaque are quoted; algorithm, qop and nc are not; quotes and backslashes are escaped.
3. Each assertion must be as strong as the test's name. "not_sent" means the key is absent, not just empty.
4. Compare echoed values with the input the server sent, not with the output itself.
TQ "unfair" comes from asserting more than the text says: uniqueness for "random", finite numbers for "tends to", combinations the text never covers, or a choice between two sentences that conflict.

SQ findings came from five input or route patterns. Sweep all of them with a script, not by an agent picking cases:
1. Every parameter in a rule sentence: absent / empty / invalid / valid / other case / bare vs quoted / only inside another quoted value.
2. Every wait: a server that sends headers and then stalls, a body that never ends, a connection dropped on the second request.
3. Routes: retry, poll, same-origin and other-origin redirects, https to http, back to https, the user's own header.
4. Every pair of stated options.
5. Parity with the nearest existing feature (grep its enum: AuthBasic).
Fix only what breaks a stated sentence. An SQ medium on a PASS: fix it only in the same round as other changes, never as its own upload.
- Digest round 4: TQ marked TestDigestChallengeBodyNeverEnds unfair. I had added it to answer an SQ medium about behaviour the description never states. Rule: an SQ finding on unstated behaviour gets a code fix and NO hidden test, unless a sentence is added for it.
- Digest round 5: TQ marked cnonce_not_constant unfair (random draws can collide, even 'not all 5 equal'). Never test randomness of a value; leave it as an advisory.
- Digest FP panel: 3/3 passers 'Genuine pass' (high confidence). Each had one judge dissent on an unstated edge (opaque="", algorithm="", timeout across both hops); the adjudicator ruled all three unfair because the prompt and the hidden suite never cover them. Don't add tests for edges like these after rollouts.
- Digest revision: SQ failed because the URL-userinfo check ran AFTER the auth values were expanded (an unset {{var}} failed a request that should skip digest). A "skip" rule must come before any work it skips, matching the repo's existing "Authorization present -> return before expand" pattern.
- Digest revision 2: SQ failed again on the same rule one hop deeper (URL userinfo on a redirect target). When fixing a rule ("existing Authorization wins"), enforce it at the lowest layer that sees every request (the transport, per hop), not only at build time. Each partial fix gives the next SQ sample a new edge.
