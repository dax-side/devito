"""Compare JUnit XML files.

usage:
  junitcmp.py passing RED.xml           red state: exit 1 if any case passed
  junitcmp.py same A.xml B.xml [...]    identical per-case outcomes (exit 1 if not)
  junitcmp.py failing MUT.xml [PREV]    mutant report: failing count, first three names
"""
import sys, json
import xml.etree.ElementTree as ET


def short(tc):
    cls = (tc.get('classname') or '').split('.')[-1]
    return f"{cls}::{tc.get('name')}"


def load(p):
    r = {}
    for tc in ET.parse(p).iter('testcase'):
        st = 'passed'
        for c in tc:
            if c.tag in ('failure', 'error', 'skipped'):
                st = c.tag
                break
        r[short(tc)] = st
    return r


if __name__ == '__main__':
    cmd = sys.argv[1]
    if cmd == 'passing':
        r = load(sys.argv[2])
        p = [k for k, v in r.items() if v == 'passed']
        print(json.dumps({'cases': len(r), 'passed': len(p)}))
        for k in p:
            print('  PASSED-ON-BASE', k)
        sys.exit(1 if p or not r else 0)
    elif cmd == 'same':
        rs = [load(p) for p in sys.argv[2:]]
        same = all(r == rs[0] for r in rs)
        print(json.dumps({'cases': [len(r) for r in rs], 'identical': same,
                          'passed': [sum(v == 'passed' for v in r.values()) for r in rs]}))
        sys.exit(0 if same else 1)
    elif cmd == 'failing':
        r = load(sys.argv[2])
        f = [k for k, v in r.items() if v != 'passed']
        out = {'cases': len(r), 'failing': len(f), 'first3': f[:3]}
        if len(sys.argv) > 3:
            try:
                prev = {k for k, v in load(sys.argv[3]).items() if v != 'passed'}
                out['no_longer_failing'] = sorted(prev - set(f))[:5]
            except Exception:
                pass
        print(json.dumps(out))
        sys.exit(0 if f else 1)
