"""Automatic task scout: finds open feature requests that fit our filters and ranks them.

Needs a GitHub token (any classic or fine-grained token with public read):
    export GITHUB_TOKEN=ghp_...
    python3 scout.py                      # default languages, writes scout_out.md + scout_out.csv
    python3 scout.py --langs Go Java --max-repos 150 --out go_java
    python3 scout.py --selftest           # checks the filters offline, no token needed

What it does, per run (about 1 GraphQL call per repo, well inside the hourly limit):
  1. Finds repos: language, 500-20000 stars, pushed in the last 6 months, permissive licence.
  2. Reads each repo's open issues with a feature-like label or title.
  3. Drops an issue when any hard filter fails:
       - a pull request references it (open, merged or closed) or closes it,
       - more than MAX_THUMBS thumbs-up (popular = already mined),
       - title or labels look like layout/formatting/UI/perf/docs/bug work (the tabulate trap),
       - the repo or issue is on skip_list.txt.
  4. Scores the rest: spec words (RFC, draft, syntax, grammar, keyword, operator...), several
     named items in the body (a sign of 8-12 behaviours), help-wanted labels, age, quietness.
  5. Writes a ranked table. A human (or Claude) then sizes the top few with a lean prototype:
     the 200-line floor cannot be judged from text.
"""
import argparse
import csv
import datetime as dt
import json
import os
import re
import sys
import time
import urllib.request

API = "https://api.github.com/graphql"
LICENCES = {"MIT", "BSD-2-Clause", "BSD-3-Clause", "Apache-2.0", "ISC", "0BSD"}
DEFAULT_LANGS = ["Go", "Java", "Python", "TypeScript", "Rust", "JavaScript", "C++"]
MAX_THUMBS = 15
FEATURE_LABEL = re.compile(r"enhancement|feature|proposal|help wanted|good first|spec|rfc", re.I)
FEATURE_TITLE = re.compile(r"\b(support|add|implement|allow|feature|proposal|request)\b", re.I)
# The tabulate lesson: layout as output, many formats, UI, speed and docs are out.
AVOID = re.compile(
    r"\b(format(ting|ter)?|colou?r|ansi|table|render|display|print|pretty|layout|ui|gui|theme|"
    r"style|css|icon|font|terminal|performance|perf|speed|faster|slow|memory|benchmark|docs?|"
    r"documentation|readme|typo|ci|windows|deprecat\w*|bug|crash|error message|logging|"
    r"translation|i18n|locale|async|thread|concurren\w*|network|http|database|gpu)\b", re.I)
SPEC_WORDS = re.compile(
    r"\b(rfc ?\d+|draft|spec(ification)?|standard|syntax|grammar|keyword|operator|expression|"
    r"semantic|parse[rs]?|validat\w*|schema|pattern|query|selector|filter|rule|dialect|"
    r"iso ?\d+|posix|ecma|pep ?\d+)\b", re.I)
ITEM_LINE = re.compile(r"^\s*([-*+]|\d+[.)])\s+\S", re.M)

REPO_QUERY = """
query($q: String!, $after: String) {
  search(query: $q, type: REPOSITORY, first: 50, after: $after) {
    pageInfo { hasNextPage endCursor }
    nodes { ... on Repository {
      nameWithOwner stargazerCount pushedAt isArchived isFork
      licenseInfo { spdxId } primaryLanguage { name }
      repositoryTopics(first: 10) { nodes { topic { name } } }
    } }
  }
}"""

ISSUE_QUERY = """
query($owner: String!, $name: String!) {
  repository(owner: $owner, name: $name) {
    issues(states: OPEN, first: 100, orderBy: {field: CREATED_AT, direction: DESC}) {
      nodes {
        number title url createdAt body
        reactions(content: THUMBS_UP) { totalCount }
        comments { totalCount }
        labels(first: 10) { nodes { name } }
        closedByPullRequestsReferences(first: 1, includeClosedPrs: true) { totalCount }
        timelineItems(itemTypes: [CROSS_REFERENCED_EVENT, CONNECTED_EVENT], first: 25) {
          nodes {
            ... on CrossReferencedEvent { source { __typename ... on PullRequest { number } } }
            ... on ConnectedEvent { subject { __typename ... on PullRequest { number } } }
          }
        }
      }
    }
  }
}"""


def gql(token, query, variables):
    body = json.dumps({"query": query, "variables": variables}).encode()
    for attempt in range(4):
        req = urllib.request.Request(API, body, {"Authorization": "bearer " + token,
                                                 "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                data = json.load(resp)
            if "errors" in data and not data.get("data"):
                raise RuntimeError(data["errors"])
            return data["data"]
        except Exception as exc:  # rate limit or network: back off and retry
            if attempt == 3:
                raise
            print("  retry after:", str(exc)[:120], file=sys.stderr)
            time.sleep(2 ** (attempt + 2))


def find_repos(token, langs, max_repos, since):
    repos = []
    for lang in langs:
        for licence in ("mit", "apache-2.0", "bsd-3-clause", "bsd-2-clause", "isc"):
            q = f"language:{json.dumps(lang)} stars:500..20000 pushed:>{since} license:{licence} archived:false fork:false"
            after = None
            while True:
                res = gql(token, REPO_QUERY, {"q": q, "after": after})["search"]
                repos += [n for n in res["nodes"] if n]
                if not res["pageInfo"]["hasNextPage"] or sum(r["primaryLanguage"] and r["primaryLanguage"]["name"] == lang for r in repos) >= max_repos:
                    break
                after = res["pageInfo"]["endCursor"]
    seen, out = set(), []
    for r in repos:
        if r["nameWithOwner"] not in seen and (r["licenseInfo"] or {}).get("spdxId") in LICENCES:
            seen.add(r["nameWithOwner"])
            out.append(r)
    return out


def has_pr(issue):
    if issue["closedByPullRequestsReferences"]["totalCount"]:
        return True
    for node in issue["timelineItems"]["nodes"]:
        ref = (node or {}).get("source") or (node or {}).get("subject") or {}
        if ref.get("__typename") == "PullRequest":
            return True
    return False


def judge(repo, issue, skip, now):
    """Returns (score, reasons) or None when a hard filter fails."""
    labels = " ".join(l["name"] for l in issue["labels"]["nodes"])
    title, body = issue["title"], issue["body"] or ""
    key = f'{repo["nameWithOwner"]}#{issue["number"]}'
    if repo["nameWithOwner"].lower() in skip or key.lower() in skip:
        return None
    if not (FEATURE_LABEL.search(labels) or FEATURE_TITLE.search(title)):
        return None
    if re.search(r"\bbug\b|question|wontfix|duplicate|invalid", labels, re.I):
        return None
    if AVOID.search(title) or AVOID.search(labels):
        return None
    if issue["reactions"]["totalCount"] > MAX_THUMBS or has_pr(issue):
        return None
    score, why = 0, []
    spec = {m.group(0).lower() for m in SPEC_WORDS.finditer(title + " " + body)}
    if spec:
        score += min(len(spec), 5) * 2
        why.append("spec:" + ",".join(sorted(spec)[:4]))
    items = len(ITEM_LINE.findall(body))
    if 4 <= items <= 20:
        score += 4
        why.append(f"{items} listed items")
    if re.search(r"help wanted|good first|accepted|approved|pr welcome", labels, re.I) or \
            re.search(r"(pull request|pr)s? (are )?welcome|contributions? welcome", body, re.I):
        score += 3
        why.append("maintainer open to it")
    age = (now - dt.datetime.fromisoformat(issue["createdAt"].replace("Z", "+00:00"))).days
    if age > 180:
        score += 2
        why.append(f"{age // 30} months old")
    if issue["comments"]["totalCount"] <= 10:
        score += 1
    if 300 <= len(body) <= 6000:
        score += 2
    return score, why


def scan(token, repos, skip, now):
    rows = []
    for i, repo in enumerate(repos, 1):
        owner, name = repo["nameWithOwner"].split("/")
        print(f"[{i}/{len(repos)}] {repo['nameWithOwner']}", file=sys.stderr)
        try:
            issues = gql(token, ISSUE_QUERY, {"owner": owner, "name": name})["repository"]["issues"]["nodes"]
        except Exception as exc:
            print("  skipped:", str(exc)[:120], file=sys.stderr)
            continue
        for issue in issues:
            verdict = judge(repo, issue, skip, now)
            if verdict:
                score, why = verdict
                rows.append({
                    "score": score, "repo": repo["nameWithOwner"], "lang": (repo["primaryLanguage"] or {}).get("name"),
                    "stars": repo["stargazerCount"], "licence": repo["licenseInfo"]["spdxId"],
                    "pushed": repo["pushedAt"][:10], "issue": issue["number"], "title": issue["title"],
                    "thumbs": issue["reactions"]["totalCount"], "comments": issue["comments"]["totalCount"],
                    "url": issue["url"], "why": "; ".join(why),
                })
    rows.sort(key=lambda r: (-r["score"], -r["stars"]))
    return rows


def write(rows, out, top):
    with open(out + ".csv", "w", newline="") as f:
        if rows:
            w = csv.DictWriter(f, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)
    per_repo, shown = {}, []
    for r in rows:  # at most 2 per repo in the ranked view
        if per_repo.get(r["repo"], 0) < 2:
            per_repo[r["repo"]] = per_repo.get(r["repo"], 0) + 1
            shown.append(r)
    with open(out + ".md", "w") as f:
        f.write(f"# Scout results ({len(rows)} issues passed the hard filters)\n\n")
        f.write("Next: size the top few with a lean prototype (200+ effective lines), check the five questions.\n\n")
        f.write("| # | score | repo | lang | stars | issue | 👍 | why |\n|---|---|---|---|---|---|---|---|\n")
        for i, r in enumerate(shown[:top], 1):
            title = r["title"].replace("|", "/")[:70]
            f.write(f'| {i} | {r["score"]} | {r["repo"]} | {r["lang"]} | {r["stars"]} | '
                    f'[#{r["issue"]} {title}]({r["url"]}) | {r["thumbs"]} | {r["why"]} |\n')


def selftest():
    now = dt.datetime(2026, 10, 3, tzinfo=dt.timezone.utc)
    repo = {"nameWithOwner": "a/b", "stargazerCount": 900, "pushedAt": "2026-09-01T00:00:00Z",
            "licenseInfo": {"spdxId": "MIT"}, "primaryLanguage": {"name": "Go"}}

    def issue(title, labels=("enhancement",), thumbs=2, body="x" * 400, pr=False, xref=False):
        return {"number": 1, "title": title, "url": "u", "createdAt": "2025-01-01T00:00:00Z", "body": body,
                "reactions": {"totalCount": thumbs}, "comments": {"totalCount": 3},
                "labels": {"nodes": [{"name": l} for l in labels]},
                "closedByPullRequestsReferences": {"totalCount": int(pr)},
                "timelineItems": {"nodes": [{"source": {"__typename": "PullRequest", "number": 9}}] if xref else []}}

    spec_body = "Support RFC 9535 filter functions:\n- length\n- count\n- match\n- search\n- value\n" + "y" * 300
    assert judge(repo, issue("Support RFC 9535 functions", body=spec_body), set(), now)[0] >= 10
    assert judge(repo, issue("Add footer rows to table output"), set(), now) is None      # layout
    assert judge(repo, issue("Support colour codes"), set(), now) is None                 # layout
    assert judge(repo, issue("Support X", thumbs=40), set(), now) is None                 # popular
    assert judge(repo, issue("Support X", pr=True), set(), now) is None                   # closing PR
    assert judge(repo, issue("Support X", xref=True), set(), now) is None                 # referenced by a PR
    assert judge(repo, issue("Support X"), {"a/b"}, now) is None                          # skip list
    assert judge(repo, issue("Support X", labels=("bug",)), set(), now) is None           # bug
    assert judge(repo, issue("Improve performance of parser"), set(), now) is None        # perf
    print("selftest ok")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--langs", nargs="+", default=DEFAULT_LANGS)
    ap.add_argument("--max-repos", type=int, default=100, help="per language")
    ap.add_argument("--top", type=int, default=40)
    ap.add_argument("--out", default="scout_out")
    ap.add_argument("--skip", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "skip_list.txt"))
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    token = os.environ.get("GITHUB_TOKEN") or sys.exit("set GITHUB_TOKEN")
    now = dt.datetime.now(dt.timezone.utc)
    since = (now - dt.timedelta(days=183)).date().isoformat()
    skip = set()
    if os.path.exists(a.skip):
        # one entry per line: owner/repo or owner/repo#123; text after the first space is a note
        skip = {l.split()[0].lower() for l in open(a.skip) if l.strip() and not l.startswith(";")}
    repos = find_repos(token, a.langs, a.max_repos, since)
    print(f"{len(repos)} repos pass the repo filters", file=sys.stderr)
    rows = scan(token, repos, skip, now)
    write(rows, a.out, a.top)
    print(f"{len(rows)} issues passed; wrote {a.out}.md and {a.out}.csv", file=sys.stderr)


if __name__ == "__main__":
    main()
