"""Rollout analysis: pass rate, per-behaviour rates, walls, prediction and next action.

    python3 rollout_analyze.py runs.txt --units cbor/units.json --tests cbor/all_tests.txt [--final 10]

runs.txt: one block per run. A block starts with a line "run <id>" (or "=== <id>"). Inside a block,
the word PASS on the header line means a clean pass; otherwise every token that looks like a test name
(Test.../...) is a FAILING test. Optional lines inside a block:
    out <test> <short failing output>   (used to cluster identical wrong outputs)
    loc <n>                             (effective production lines of that run's patch)

Method (tabulate post-mortem, section 8.2 and the early-prediction table):
- Pass rate p = (passes + 0.5) / (k + 1), with a 95% Wilson interval. Same description version only.
- Unit rate r_u = (runs passing every test of unit u + 0.5) / (k + 1). Predicted pass rate = product of r_u.
  Lowest unit rate is an upper bound. MAE about 0.06 at k = 8.
- Wall: a test failing in at least k - 1 of k runs. Blocker: unit rate < 0.30. Redesign: product < 0.05.
- Band: at least 1 pass and at most 50% over at least 10 counted runs (aim 20-30%).
- Identical wrong outputs across runs (>= 3) point to a spec or test problem, not the agents.
"""
import argparse
import collections
import json
import math
import re
import sys

TEST = re.compile(r"\bTest[A-Za-z0-9_]+(?:/[^\s,;]+)?")


def parse(path):
    runs, cur = [], None
    for raw in open(path, encoding="utf-8", errors="ignore"):
        line = raw.strip()
        if not line:
            continue
        m = re.match(r"^(?:run|===)\s*[:#]?\s*(\S+)(.*)$", line, re.I)
        if m:
            cur = {"id": m.group(1), "pass": bool(re.search(r"\bPASS\b", m.group(2), re.I)) and not TEST.search(m.group(2)),
                   "fail": set(TEST.findall(m.group(2))), "out": {}, "loc": None}
            runs.append(cur)
            continue
        if cur is None:
            continue
        if line.lower().startswith("loc "):
            cur["loc"] = int(re.findall(r"\d+", line)[0])
        elif line.lower().startswith("out "):
            parts = line.split(None, 2)
            if len(parts) == 3:
                cur["out"][parts[1]] = parts[2]
        else:
            cur["fail"] |= set(TEST.findall(line))
    for r in runs:
        r["pass"] = r["pass"] or not r["fail"]
    return runs


def unit_of(name, units):
    for u, prefixes in units.items():
        if u.startswith("_"):
            continue
        for p in prefixes:
            if name == p or (p.endswith("/") and name.startswith(p)) or name.startswith(p + "/"):
                return u
    return "unmapped"


def leaf_failures(fails):
    """Drop parent tests whose failure is explained by a failing subtest."""
    return {t for t in fails if not any(o.startswith(t + "/") for o in fails)}


def wilson(x, n, z=1.96):
    if n == 0:
        return (0.0, 1.0)
    ph = x / n
    d = 1 + z * z / n
    c = ph + z * z / (2 * n)
    h = z * math.sqrt(ph * (1 - ph) / n + z * z / (4 * n * n))
    return max(0.0, (c - h) / d), min(1.0, (c + h) / d)


def binom_tail_ge(n, p, k):
    return sum(math.comb(n, i) * p ** i * (1 - p) ** (n - i) for i in range(k, n + 1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("runs")
    ap.add_argument("--units", required=True)
    ap.add_argument("--tests", help="file with every hidden test name, one per line")
    ap.add_argument("--final", type=int, default=10, help="size of a full counted batch")
    a = ap.parse_args()
    units = json.load(open(a.units))
    runs = parse(a.runs)
    k = len(runs)
    if not k:
        sys.exit("no runs parsed")
    passes = sum(r["pass"] for r in runs)
    all_units = [u for u in units if not u.startswith("_")]

    print(f"# Rollout analysis: {k} runs, {passes} clean passes\n")
    p = (passes + 0.5) / (k + 1)
    lo, hi = wilson(passes, k)
    print(f"Raw pass rate {passes}/{k} = {passes / k:.0%}; smoothed (x+0.5)/(k+1) = {p:.2f}; 95% Wilson [{lo:.2f}, {hi:.2f}]")

    # per-test and per-unit
    test_fail = collections.Counter()
    unit_fail_runs = collections.Counter()
    for r in runs:
        leaves = leaf_failures(r["fail"])
        r["units"] = {unit_of(t, units) for t in leaves}
        for t in leaves:
            test_fail[t] += 1
        for u in r["units"]:
            unit_fail_runs[u] += 1

    print("\n## Per-behaviour unit (rate = runs passing every test of the unit)\n")
    print("| unit | runs failing | smoothed rate | flag |\n|---|---|---|---|")
    product, rates = 1.0, {}
    for u in all_units + (["unmapped"] if unit_fail_runs["unmapped"] else []):
        f = unit_fail_runs[u]
        r_u = (k - f + 0.5) / (k + 1)
        rates[u] = r_u
        product *= r_u
        flag = "BLOCKER (<0.30)" if r_u < 0.30 else ("weak (<0.60)" if r_u < 0.60 else "")
        print(f"| {u} | {f}/{k} | {r_u:.2f} | {flag} |")
    worst = min(rates, key=rates.get)
    print(f"\nPredicted pass rate (product of unit rates): {product:.3f}   upper bound (lowest unit {worst}): {rates[worst]:.2f}")
    # product of smoothed rates is biased low when many units are perfect; report a corrected value too
    perfect = [u for u in rates if unit_fail_runs[u] == 0]
    corr = product / ((k + 0.5) / (k + 1)) ** len(perfect) if perfect else product
    print(f"Product ignoring the {len(perfect)} never-failing units: {corr:.3f}")

    print("\n## Tests (walls = failing in >= k-1 runs)\n")
    print("| test | unit | failing runs | wall |\n|---|---|---|---|")
    for t, n in test_fail.most_common():
        print(f"| {t} | {unit_of(t, units)} | {n}/{k} | {'WALL' if n >= k - 1 and k >= 3 else ''} |")
    if a.tests:
        names = [l.strip() for l in open(a.tests) if l.strip()]
        never = [n for n in names if "/" in n and not test_fail.get(n)]
        print(f"\nTests never failed: {len(never)} of {sum('/' in n for n in names)} subtests")

    print("\n## Identical wrong outputs (>= 3 runs = suspect spec/test)\n")
    clusters = collections.Counter()
    for r in runs:
        for t, o in r["out"].items():
            clusters[(t, o)] += 1
    shown = False
    for (t, o), n in clusters.most_common():
        if n >= 2:
            shown = True
            print(f"- {n} runs: {t} -> {o}{'   <-- SPEC/TEST SUSPECT' if n >= 3 else ''}")
    if not shown:
        print("- none recorded (add `out <test> <output>` lines to use this)")

    print("\n## Band and forecast\n")
    n = a.final
    print(f"With p = {p:.2f} over a {n}-run batch: expected passes {n * p:.1f}; "
          f"P(at least 1 pass) = {1 - (1 - p) ** n:.2f}; P(more than 50% pass) = {binom_tail_ge(n, p, n // 2 + 1):.2f}")
    print(f"Using the unit product {product:.2f}: P(at least 1 pass in {n}) = {1 - (1 - product) ** n:.2f}")

    locs = [r["loc"] for r in runs if r["pass"] and r["loc"] is not None]
    if locs:
        locs.sort()
        med = locs[len(locs) // 2] if len(locs) % 2 else (locs[len(locs) // 2 - 1] + locs[len(locs) // 2]) / 2
        print(f"\nPassing runs' effective production lines: {locs}; median {med} ({'OK' if med >= 200 else 'UNDER 200 -> Auto Review goes to human review'})")

    print("\n## Decision\n")
    blockers = [u for u, r_u in rates.items() if r_u < 0.30]
    if passes == k:
        print("- ALL PASS: too easy. Add a discriminator drawn from real passing code (must pass on the reference and fail some passers).")
    elif passes / k > 0.5:
        print("- Above 50%: add a discriminator from a stated behaviour the passers got right only by luck, or tighten a test.")
    elif product < 0.05 and passes == 0:
        print("- Predicted < 5% with 0 passes: redesign before spending more runs (see levers in ROLLOUT_PLAYBOOK.md).")
    elif blockers:
        print(f"- Blocker units {blockers}: check each wall's failing output. Same wrong output across runs = spec/test problem; "
              "otherwise add the missing example/rule (lever A1/A2) or relax a test that over-demands literal wording.")
    else:
        print("- In band so far: keep the description frozen and finish the batch on this version.")
    print("- Never pool runs across description versions.")


if __name__ == "__main__":
    main()
