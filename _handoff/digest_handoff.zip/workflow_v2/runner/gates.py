"""Static gates for Shipd artifacts.

usage:
  gates.py desc DESCRIPTION.txt      description format scan (exit 1 on any violation)
  gates.py tests TEST.patch          grep gates on added test lines (exit 1 on any hit)
  gates.py touched PATCH             files a patch touches
"""
import re, sys, json
from collections import OrderedDict


def added_lines(patch):
    out, cur = [], None
    for line in open(patch, encoding='utf-8', errors='replace').read().splitlines():
        if line.startswith('+++ '):
            cur = line[6:] if line.startswith('+++ b/') else line[4:]
            continue
        if line.startswith('+') and not line.startswith('+++'):
            out.append((cur, line[1:]))
    return out


def touched(patch):
    lines = open(patch).read().splitlines()
    return sorted({l[6:] for l in lines if l.startswith('+++ b/')} |
                  {l[6:] for l in lines if l.startswith('--- a/')})


def description_scan(path):
    raw = open(path, 'rb').read()
    text = raw.decode('utf-8', errors='replace')
    paras = [p for p in re.split(r'\n\s*\n', text) if p.strip()]
    lines = [l for l in text.splitlines() if l.strip()]
    res = OrderedDict()
    res['words'] = len(text.split())
    res['paragraphs'] = len(paras)
    res['max_paragraph_words'] = max(len(p.split()) for p in paras)
    res['paragraphs_over_150'] = [i for i, p in enumerate(paras, 1) if len(p.split()) > 150]
    res['non_ascii_chars'] = sorted({c for c in text if ord(c) > 127})
    res['em_or_en_dash'] = ('—' in text) or ('–' in text)
    res['crlf'] = b'\r' in raw
    res['label_lines'] = [l for l in lines if (len(l.split()) <= 6 and not l.rstrip().endswith(('.', '?', '!', ':')))
                          or l.lstrip().startswith('#')]
    res['list_lines'] = [l for l in lines if re.match(r'\s*([-*•]|\d+[.)])\s', l)]
    res['hard_wrapped'] = any(len(p.splitlines()) > 1 for p in paras)
    res['universal_words'] = sorted({w.lower() for w in re.findall(r'\b(any|every|whichever|all|always|never|exactly)\b', text, re.I)})
    bad = (res['paragraphs_over_150'] or res['non_ascii_chars'] or res['em_or_en_dash'] or res['crlf']
           or res['label_lines'] or res['list_lines'] or res['hard_wrapped'])
    return res, bool(bad)


def test_grep(patch):
    add = added_lines(patch)
    pats = OrderedDict([
        ('match_kwarg', r'\bmatch\s*='),
        ('exception_value_text', r'\.value\b|str\(\s*e(xc)?\b|excinfo'),
        ('private_attribute', r"\.\_(?!_)[A-Za-z]|getattr\([^)]*,\s*f?['\"]_(?!_)"),
        ('comment', r'(^|\s)#(?!!)'),
        ('crlf', r'\r$'),
        ('literal_tuple_parametrize', r"parametrize\([^)]*,\s*\[\s*\("),
    ])
    return OrderedDict((n, [(f, l.strip()) for f, l in add if re.search(p, l)]) for n, p in pats.items())


if __name__ == '__main__':
    cmd = sys.argv[1]
    if cmd == 'desc':
        res, bad = description_scan(sys.argv[2])
        print(json.dumps(res, indent=1))
        print('universal words are advisory: each one must be enforced on every route and sampled by a test')
        sys.exit(1 if bad else 0)
    elif cmd == 'tests':
        r = test_grep(sys.argv[2])
        print(json.dumps({k: len(v) for k, v in r.items()}, indent=1))
        for k, v in r.items():
            for f, l in v[:5]:
                print(f'  {k}: {f}: {l[:110]}')
        sys.exit(1 if any(r.values()) else 0)
    elif cmd == 'touched':
        print('\n'.join(touched(sys.argv[2])))
