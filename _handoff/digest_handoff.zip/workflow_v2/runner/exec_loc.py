import ast, io, re, subprocess, sys, tokenize
# usage: exec_loc.py <tree-with-patch-applied> <patch>  -> A = effective executable LOC (Auto Review count)

def added_lines(patch):
    res={}; f=None; ln=0
    for l in open(patch).read().split('\n'):
        if l.startswith('+++ b/'): f=l[6:]; res.setdefault(f,set()); continue
        m=re.match(r'@@ -\S+ \+(\d+)',l)
        if m: ln=int(m.group(1)); continue
        if f is None or l.startswith('---'): continue
        if l.startswith('+'): res[f].add(ln); ln+=1
        elif l.startswith('-'): pass
        elif l.startswith(' '): ln+=1
    return {k:v for k,v in res.items() if k.startswith('devito/') and k.endswith('.py')}
def measure(tree, patch):
    tot={'A':0,'B':0,'C':0}
    for f,lines in added_lines(patch).items():
        src=open(f'{tree}/{f}').read(); t=ast.parse(src); srcl=src.split('\n')
        doc=set()
        for n in ast.walk(t):
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef,ast.Module)) and n.body:
                b=n.body[0]
                if isinstance(b,ast.Expr) and isinstance(b.value,ast.Constant) and isinstance(b.value.value,str):
                    doc.update(range(b.lineno,b.end_lineno+1))
        stmt_starts={n.lineno for n in ast.walk(t) if isinstance(n,ast.stmt)}
        for ln in lines:
            s=srcl[ln-1].strip()
            if not s or s.startswith('#') or ln in doc: continue
            tot['A']+=1
            if not re.fullmatch(r'[\)\]\}\s,:]*',s): tot['B']+=1
            if ln in stmt_starts: tot['C']+=1
    return tot
tree,patch=sys.argv[1],sys.argv[2]
print(measure(tree,patch))
