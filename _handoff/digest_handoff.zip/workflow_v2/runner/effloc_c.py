"""Effective added lines for C/C++/Go/Java/JS/TS patches: same rules as effloc.py.
Skips blank lines, // and /* */ comments, preprocessor lines and bracket-only lines."""
import re, sys


def effective(patch_text):
    per, total, cur, in_comment = {}, 0, None, False
    for line in patch_text.splitlines():
        if line.startswith('+++ '):
            cur = line[6:]
            continue
        if not line.startswith('+') or line.startswith('+++'):
            continue
        body = line[1:].strip()
        if in_comment:
            if '*/' in body:
                in_comment = False
            continue
        if body.startswith('/*'):
            in_comment = '*/' not in body
            continue
        if not body or body.startswith(('//', '*', '#')):
            continue
        if re.fullmatch(r'[\)\]\}\(\[\{,;:\s]*', body):
            continue
        per[cur] = per.get(cur, 0) + 1
        total += 1
    return total, per


if __name__ == '__main__':
    t = open(sys.argv[1]).read() if len(sys.argv) > 1 else sys.stdin.read()
    print(*effective(t))
