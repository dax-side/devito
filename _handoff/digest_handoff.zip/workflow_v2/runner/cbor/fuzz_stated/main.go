// fuzz_stated: deterministic randomized differential sweep over every stated behaviour of the
// exact-number task. Run on the reference and on a passer; any differing line is a likely FP finding.
// Output never converts extreme values to big.Rat (that allocation was a probe artifact once).
package main

import (
	"bytes"
	"encoding/hex"
	"fmt"
	"math/big"
	"math/rand"
	"os"
	"reflect"
	"time"

	"github.com/fxamacker/cbor/v2"
)

var rng = rand.New(rand.NewSource(20261003))

func out(cat, name, res string) { fmt.Printf("%s\t%s\t%s\n", cat, name, res) }

func guard(cat, name string, f func() string) {
	c := make(chan string, 1)
	go func() {
		defer func() {
			if r := recover(); r != nil {
				c <- "PANIC"
			}
		}()
		c <- f()
	}()
	select {
	case r := <-c:
		out(cat, name, r)
	case <-time.After(3 * time.Second):
		out(cat, name, "TIMEOUT")
	}
}

func floatStr(f *big.Float) string {
	if f.IsInf() {
		return "Inf"
	}
	if f.Sign() == 0 {
		return "0"
	}
	return f.Text('p', 0)
}

func randBig(maxBits int) *big.Int {
	n := new(big.Int).Rand(rng, new(big.Int).Lsh(big.NewInt(1), uint(1+rng.Intn(maxBits))))
	if rng.Intn(2) == 0 {
		n.Neg(n)
	}
	return n
}

// cborInt encodes an integer as a CBOR int (or as a bignum when asBig or when it does not fit).
func cborInt(n *big.Int, asBig bool) []byte {
	em, _ := cbor.EncOptions{BigIntConvert: cbor.BigIntConvertShortest}.EncMode()
	if asBig {
		em, _ = cbor.EncOptions{BigIntConvert: cbor.BigIntConvertNone}.EncMode()
	}
	b, _ := em.Marshal(n)
	return b
}

func pair(tag byte, a, b []byte) []byte {
	var buf bytes.Buffer
	switch tag {
	case 30:
		buf.Write([]byte{0xd8, 0x1e})
	default:
		buf.WriteByte(0xc0 | tag)
	}
	buf.WriteByte(0x82)
	buf.Write(a)
	buf.Write(b)
	return buf.Bytes()
}

func main() {
	def, _ := cbor.EncOptions{}.EncMode()
	decEnc, _ := cbor.EncOptions{RatEnc: cbor.RatEncodeDecimalFraction}.EncMode()
	dv, _ := cbor.DecOptions{ExponentMantissaDec: cbor.ExponentMantissaDecodeValue}.DecMode()

	// 1. Encode big.Float: random mantissas, exponents across the whole range, precisions.
	for i := 0; i < 1500; i++ {
		m := randBig(300)
		var e int
		switch rng.Intn(4) {
		case 0:
			e = rng.Intn(4000) - 2000
		case 1:
			e = big.MaxExp - rng.Intn(400)
		case 2:
			e = big.MinExp + rng.Intn(400)
		default:
			e = rng.Intn(1<<31-1) - 1<<30
		}
		f := new(big.Float).SetPrec(uint(max(m.BitLen(), 1) + rng.Intn(64))).SetInt(m)
		name := fmt.Sprintf("m=%s e=%d", m.String(), e)
		if os.Getenv("FUZZ_SMALL_ENC") != "" && (e > 100000 || e < -100000) {
			out("encFloat", name, "skipped")
			continue
		}
		guard("encFloat", name, func() string {
			g := new(big.Float).Copy(f)
			g.SetMantExp(g, e-m.BitLen())
			if g.IsInf() {
				return "skip"
			}
			b, err := def.Marshal(g)
			if err != nil {
				return "ERR"
			}
			return hex.EncodeToString(b)
		})
	}

	// 2. Decode tag 5 into big.Float / big.Rat / any(value): exponents near every boundary,
	//    mantissas small or bignum, parts as ints or forced bignums.
	expPool := []int64{0, 1, -1, 1000, -1000, 10000000, -10000000, 10000001, -10000001,
		big.MaxExp, big.MaxExp - 1, big.MaxExp + 1, big.MinExp, big.MinExp - 1, big.MinExp + 1,
		big.MinExp - 64, big.MaxExp - 64, 1 << 32, -(1 << 32), 1<<63 - 1, -1 << 63}
	for i := 0; i < 1500; i++ {
		var e *big.Int
		if rng.Intn(3) == 0 {
			e = big.NewInt(rng.Int63n(1<<40) - 1<<39)
		} else {
			e = big.NewInt(expPool[rng.Intn(len(expPool))] + int64(rng.Intn(130)-65))
		}
		m := randBig([]int{8, 64, 200}[rng.Intn(3)])
		data := pair(5, cborInt(e, rng.Intn(4) == 0), cborInt(m, rng.Intn(4) == 0))
		h := hex.EncodeToString(data)
		guard("decFloat", h, func() string {
			var f big.Float
			if err := cbor.Unmarshal(data, &f); err != nil {
				return "ERR"
			}
			return floatStr(&f)
		})
		guard("decAnyValue5", h, func() string {
			var v any
			if err := dv.Unmarshal(data, &v); err != nil {
				return "ERR"
			}
			if p, ok := v.(*big.Float); ok {
				return floatStr(p)
			}
			if f, ok := v.(big.Float); ok {
				return floatStr(&f)
			}
			return fmt.Sprintf("%T", v)
		})
		if e.IsInt64() && (e.Int64() > 10000001 || e.Int64() < -10000001) || !e.IsInt64() {
			guard("decRat5big", h, func() string {
				var r big.Rat
				if err := cbor.Unmarshal(data, &r); err != nil {
					return "ERR"
				}
				return "OK"
			})
		} else if e.Int64() >= -3000 && e.Int64() <= 3000 {
			guard("decRat5", h, func() string {
				var r big.Rat
				if err := cbor.Unmarshal(data, &r); err != nil {
					return "ERR"
				}
				return r.String()
			})
		}
	}

	// 3. Tag 4: DecimalFraction encode/decode, Rat(), big.Rat limits at the exact boundaries.
	for i := 0; i < 800; i++ {
		e := int64(rng.Intn(200) - 100)
		if rng.Intn(5) == 0 {
			e = []int64{1000000, -1000000, 1000001, -1000001, 1<<63 - 1, -1 << 63}[rng.Intn(6)]
		}
		m := randBig([]int{8, 64, 200}[rng.Intn(3)])
		d := cbor.DecimalFraction{Exponent: e, Mantissa: *m}
		guard("encDF", fmt.Sprintf("%d %s", e, m), func() string {
			b, err := def.Marshal(d)
			if err != nil {
				return "ERR"
			}
			return hex.EncodeToString(b)
		})
		data := pair(4, cborInt(big.NewInt(e), rng.Intn(4) == 0), cborInt(m, rng.Intn(4) == 0))
		h := hex.EncodeToString(data)
		guard("decDF", h, func() string {
			var x cbor.DecimalFraction
			if err := cbor.Unmarshal(data, &x); err != nil {
				return "ERR"
			}
			return fmt.Sprintf("%d %s", x.Exponent, x.Mantissa.String())
		})
		guard("decRat4", h, func() string {
			var r big.Rat
			if err := cbor.Unmarshal(data, &r); err != nil {
				return "ERR"
			}
			if e > 3000 || e < -3000 {
				return "OK"
			}
			return r.String()
		})
		if e >= -300 && e <= 300 {
			guard("DF.Rat", fmt.Sprintf("%d %s", e, m), func() string {
				res := reflect.ValueOf(d).MethodByName("Rat").Call(nil)
				if len(res) == 2 && !res[1].IsNil() {
					return "ERR"
				}
				v := res[0]
				if v.Kind() == reflect.Pointer {
					v = v.Elem()
				}
				r := v.Interface().(big.Rat)
				return r.String()
			})
		}
	}

	// 4. big.Rat encode in both modes; tag 30 decode with random parts and signs.
	for i := 0; i < 1500; i++ {
		num := randBig([]int{8, 64, 150}[rng.Intn(3)])
		var den *big.Int
		switch rng.Intn(3) {
		case 0: // terminating decimal
			den = new(big.Int).Mul(new(big.Int).Exp(big.NewInt(2), big.NewInt(int64(rng.Intn(80))), nil),
				new(big.Int).Exp(big.NewInt(5), big.NewInt(int64(rng.Intn(60))), nil))
		case 1:
			den = big.NewInt(int64(rng.Intn(1000) + 1))
		default:
			den = new(big.Int).Abs(randBig(100))
			den.Add(den, big.NewInt(1))
		}
		r := new(big.Rat).SetFrac(num, den)
		name := r.String()
		guard("encRat", name, func() string {
			b, err := def.Marshal(r)
			if err != nil {
				return "ERR"
			}
			return hex.EncodeToString(b)
		})
		guard("encRatDec", name, func() string {
			b, err := decEnc.Marshal(r)
			if err != nil {
				return "ERR"
			}
			return hex.EncodeToString(b)
		})
		d2 := new(big.Int).Set(den)
		if rng.Intn(6) == 0 {
			d2.Neg(d2)
		}
		if rng.Intn(15) == 0 {
			d2.SetInt64(0)
		}
		data := pair(30, cborInt(num, rng.Intn(4) == 0), cborInt(d2, rng.Intn(4) == 0))
		h := hex.EncodeToString(data)
		guard("decRat30", h, func() string {
			var x big.Rat
			if err := cbor.Unmarshal(data, &x); err != nil {
				return "ERR"
			}
			return x.String()
		})
		guard("decAnyValue30", h, func() string {
			var v any
			if err := dv.Unmarshal(data, &v); err != nil {
				return "ERR"
			}
			if p, ok := v.(*big.Rat); ok {
				return p.String()
			}
			if x, ok := v.(big.Rat); ok {
				return x.String()
			}
			return fmt.Sprintf("%T", v)
		})
		guard("decAnyDefault30", h, func() string {
			var v any
			if err := cbor.Unmarshal(data, &v); err != nil {
				return "ERR"
			}
			if t, ok := v.(cbor.Tag); ok {
				return fmt.Sprintf("Tag%d", t.Number)
			}
			return fmt.Sprintf("%T", v)
		})
	}

	// 5. Value mode in containers, streams, UnmarshalFirst, indefinite arrays.
	items := [][]byte{h("c48221196ab3"), h("c5822003"), h("d81e820103"), h("c59f2003ff"), h("d81e9f0103ff"), h("07"), h("6161"), h("c48203c249010000000000000000")}
	for i := 0; i < 400; i++ {
		n := 1 + rng.Intn(5)
		var buf bytes.Buffer
		buf.WriteByte(0x80 | byte(n))
		for j := 0; j < n; j++ {
			buf.Write(items[rng.Intn(len(items))])
		}
		data := buf.Bytes()
		x := hex.EncodeToString(data)
		guard("nestedValue", x, func() string {
			var v any
			if err := dv.Unmarshal(data, &v); err != nil {
				return "ERR"
			}
			s := ""
			for _, e := range v.([]any) {
				s += describe(e) + ";"
			}
			return s
		})
		guard("nestedDefault", x, func() string {
			var v any
			if err := cbor.Unmarshal(data, &v); err != nil {
				return "ERR"
			}
			s := ""
			for _, e := range v.([]any) {
				if t, ok := e.(cbor.Tag); ok {
					s += fmt.Sprintf("Tag%d;", t.Number)
				} else {
					s += fmt.Sprintf("%T;", e)
				}
			}
			return s
		})
		guard("stream", x, func() string {
			dec := dv.NewDecoder(bytes.NewReader(data[1:]))
			s := ""
			for k := 0; k < n; k++ {
				var v any
				if err := dec.Decode(&v); err != nil {
					s += "ERR;"
					continue
				}
				s += describe(v) + ";"
			}
			return s
		})
		guard("unmarshalFirst", x, func() string {
			var v any
			rest, err := dv.UnmarshalFirst(data[1:], &v)
			if err != nil {
				return "ERR"
			}
			return describe(v) + " rest=" + hex.EncodeToString(rest)
		})
	}
	for _, c := range []string{"a2616ac5822003616bd81e820103", "a1c482200301", "d9d9f7c5822003", "82d9d9f7c48221196ab3c5822003"} {
		data := h(c)
		guard("mapsAndSelfDescribe", c, func() string {
			var v any
			if err := dv.Unmarshal(data, &v); err != nil {
				return "ERR"
			}
			return describe(v)
		})
	}

	// 6. Round trips through structs, slices, maps, pointers.
	type S struct {
		F  big.Float
		P  *big.Float
		D  cbor.DecimalFraction
		R  big.Rat
		RP *big.Rat
		L  []big.Rat
		M  map[string]*big.Float
	}
	for i := 0; i < 300; i++ {
		f := new(big.Float).SetMantExp(new(big.Float).SetInt(randBig(80)), rng.Intn(400)-200)
		s := S{F: *f, P: f, D: cbor.DecimalFraction{Exponent: int64(rng.Intn(40) - 20), Mantissa: *randBig(90)},
			R: *new(big.Rat).SetFrac(randBig(70), big.NewInt(int64(rng.Intn(999)+1))), RP: big.NewRat(int64(rng.Intn(99)), 7),
			L: []big.Rat{*big.NewRat(1, 3), *big.NewRat(-5, 8)}, M: map[string]*big.Float{"a": f}}
		guard("roundTrip", fmt.Sprint(i), func() string {
			b, err := cbor.Marshal(s)
			if err != nil {
				return "ERR"
			}
			var o S
			if err := cbor.Unmarshal(b, &o); err != nil {
				return "ERR2"
			}
			ok := o.F.Cmp(&s.F) == 0 && o.P.Cmp(s.P) == 0 && o.D.Exponent == s.D.Exponent && o.D.Mantissa.Cmp(&s.D.Mantissa) == 0 &&
				o.R.Cmp(&s.R) == 0 && o.RP.Cmp(s.RP) == 0 && len(o.L) == 2 && o.L[1].Cmp(&s.L[1]) == 0 && o.M["a"].Cmp(f) == 0
			return fmt.Sprint(ok)
		})
	}
}

func h(s string) []byte { b, _ := hex.DecodeString(s); return b }

func describe(e any) string {
	switch x := e.(type) {
	case cbor.DecimalFraction:
		return fmt.Sprintf("DF(%d,%s)", x.Exponent, x.Mantissa.String())
	case *cbor.DecimalFraction:
		return describe(*x)
	case big.Float:
		return "F(" + floatStr(&x) + ")"
	case *big.Float:
		return "F(" + floatStr(x) + ")"
	case big.Rat:
		return "R(" + x.String() + ")"
	case *big.Rat:
		return "R(" + x.String() + ")"
	case map[any]any:
		s := "map{"
		for _, k := range []any{"j", "k"} {
			if v, ok := x[k]; ok {
				s += fmt.Sprint(k) + ":" + describe(v) + ","
			}
		}
		return s + fmt.Sprintf("n=%d}", len(x))
	case []any:
		s := "["
		for _, v := range x {
			s += describe(v) + ","
		}
		return s + "]"
	}
	return fmt.Sprintf("%T:%v", e, e)
}
