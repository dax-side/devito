// probe_default: pre-FP target 1 (default path unchanged). Uses only the API that exists before the
// task, so it runs on base, on the reference and on every passer. Any line that differs between base
// and a passer is a regression in behaviour the task did not ask to change.
//
//	cd <tree> && mkdir -p zzprobe && cp <this>/main.go zzprobe/ && go run ./zzprobe > out.txt
package main

import (
	"encoding/hex"
	"fmt"
	"math"
	"math/big"
	"reflect"
	"time"

	"github.com/fxamacker/cbor/v2"
)

type omit struct {
	A int    `cbor:"a,omitempty"`
	B string `cbor:"b,omitempty"`
	C []int  `cbor:"c,omitempty"`
}

type toArray struct {
	_ struct{} `cbor:",toarray"`
	X int
	Y string
}

type keyAsInt struct {
	A int `cbor:"1,keyasint"`
	B int `cbor:"2,keyasint"`
}

func enc(name string, em cbor.EncMode, v any) {
	b, err := em.Marshal(v)
	if err != nil {
		fmt.Printf("enc\t%s\tERR %T\n", name, err)
		return
	}
	fmt.Printf("enc\t%s\t%x\n", name, b)
}

func dec(name string, dm cbor.DecMode, h string, into func() any) {
	b, _ := hex.DecodeString(h)
	v := into()
	err := dm.Unmarshal(b, v)
	if err != nil {
		fmt.Printf("dec\t%s\t%s\tERR %T\n", name, h, err)
		return
	}
	fmt.Printf("dec\t%s\t%s\t%s\n", name, h, show(reflect.ValueOf(v).Elem().Interface()))
}

func show(v any) string {
	switch x := v.(type) {
	case big.Int:
		return "bigint:" + x.String()
	case *big.Int:
		if x == nil {
			return "nil*bigint"
		}
		return "*bigint:" + x.String()
	case cbor.Tag:
		return fmt.Sprintf("Tag{%d,%s}", x.Number, show(x.Content))
	case []any:
		s := "["
		for i, e := range x {
			if i > 0 {
				s += ","
			}
			s += show(e)
		}
		return s + "]"
	case map[any]any:
		return fmt.Sprintf("map%d:%v", len(x), x)
	case time.Time:
		return "time:" + x.UTC().Format(time.RFC3339Nano)
	case float64:
		if math.IsNaN(x) {
			return "NaN"
		}
	}
	return fmt.Sprintf("%T:%#v", v, v)
}

func main() {
	encModes := map[string]cbor.EncOptions{
		"default":   {},
		"canonical": cbor.CanonicalEncOptions(),
		"ctap2":     cbor.CTAP2EncOptions(),
		"coredet":   cbor.CoreDetEncOptions(),
		"bigintnone": {BigIntConvert: cbor.BigIntConvertNone},
		"tagsforbid": {TagsMd: cbor.TagsForbidden},
		"indefforbid": {IndefLength: cbor.IndefLengthForbidden},
		"float16":   {ShortestFloat: cbor.ShortestFloat16},
	}
	values := map[string]any{
		"int": 5, "neg": -7, "u64max": uint64(math.MaxUint64), "i64min": int64(math.MinInt64),
		"f64": 1.5, "f64tenth": 0.1, "nan": math.NaN(), "inf": math.Inf(1), "negzero": math.Copysign(0, -1),
		"f32": float32(2.5), "str": "héllo", "bytes": []byte{1, 2, 3}, "nilslice": []int(nil),
		"slice": []any{1, "a", []int{2}}, "map": map[string]int{"b": 2, "a": 1, "cc": 3},
		"intmap": map[int]string{10: "x", -1: "y", 2: "z"}, "omit": omit{A: 1}, "omitzero": omit{},
		"toarray": toArray{X: 1, Y: "y"}, "keyasint": keyAsInt{A: 1, B: 2},
		"bigsmall": big.NewInt(42), "bignegsmall": big.NewInt(-42),
		"biglarge": new(big.Int).Lsh(big.NewInt(1), 80), "bigneglarge": new(big.Int).Neg(new(big.Int).Lsh(big.NewInt(1), 80)),
		"bigval": *big.NewInt(9), "nilptr": (*int)(nil), "time": time.Unix(1700000000, 5).UTC(),
		"tag2": cbor.Tag{Number: 2, Content: []byte{1, 0}}, "tag100": cbor.Tag{Number: 100, Content: "x"},
		"tag4ok": cbor.Tag{Number: 4, Content: []int{-2, 27315}}, "tag5ok": cbor.Tag{Number: 5, Content: []int{-1, 3}},
		"tag30ok": cbor.Tag{Number: 30, Content: []int{1, 3}},
		"rawtag": cbor.RawTag{Number: 100, Content: cbor.RawMessage{0x01}},
		"raw": cbor.RawMessage{0x82, 0x01, 0x02}, "nested": map[string]any{"k": []any{map[string]any{"z": 1}}},
		"structptr": &omit{B: "b"},
	}
	names := sortedKeys(values)
	for _, mn := range sortedKeys(encModes) {
		em, err := encModes[mn].EncMode()
		if err != nil {
			fmt.Printf("encmode\t%s\tERR\n", mn)
			continue
		}
		sorted := mn == "canonical" || mn == "ctap2" || mn == "coredet"
		for _, n := range names {
			if (n == "map" || n == "intmap") && !sorted {
				continue // Go map order is random without a sort mode
			}
			enc(mn+"/"+n, em, values[n])
		}
	}

	decModes := map[string]cbor.DecOptions{
		"default":       {},
		"intsigned":     {IntDec: cbor.IntDecConvertSigned},
		"intsignedfail": {IntDec: cbor.IntDecConvertSignedOrFail},
		"bigptr":        {BigIntDec: cbor.BigIntDecodePointer},
		"tagcontent":    {UnrecognizedTagToAny: cbor.UnrecognizedTagContentToAny},
		"mapstr":        {DefaultMapType: reflect.TypeOf(map[string]any(nil))},
		"tagsforbid":    {TagsMd: cbor.TagsForbidden},
		"indefforbid":   {IndefLength: cbor.IndefLengthForbidden},
		"timerfc":       {TimeTagToAny: cbor.TimeTagToRFC3339},
	}
	inputs := []string{
		"05", "20", "1bffffffffffffffff", "3bffffffffffffffff", "f93e00", "fb3ff8000000000000", "f97e00",
		"6161", "4101", "820102", "9f0102ff", "a161610102", "a2616101616202", "bf616101ff",
		"c249010000000000000000", "c349010000000000000000", "c24100", "c11a6553f100", "c074323031332d30332d32315432303a30343a30305a",
		"d86401", "d864820102", "d9d9f705", "d5410a", "d6d86401",
		"c48221196ab3", "c5822003", "d81e820103", "82c48221196ab3d864f5",
		"f5", "f6", "f7", "e0", "a1c482200301",
	}
	exactNumberInput := map[string]bool{"c48221196ab3": true, "c5822003": true, "d81e820103": true, "82c48221196ab3d864f5": true, "a1c482200301": true}
	intos := map[string]func() any{
		"any": func() any { return new(any) }, "tag": func() any { return new(cbor.Tag) },
		"raw": func() any { return new(cbor.RawMessage) }, "bigint": func() any { return new(big.Int) },
		"int64": func() any { return new(int64) }, "slice": func() any { return new([]any) },
		"float64": func() any { return new(float64) },
	}
	for _, mn := range sortedKeys(decModes) {
		dm, err := decModes[mn].DecMode()
		if err != nil {
			fmt.Printf("decmode\t%s\tERR\n", mn)
			continue
		}
		for _, h := range inputs {
			if mn == "tagcontent" && exactNumberInput[h] {
				continue // intentional change: tags 4, 5, 30 stay a Tag (probe_feature covers it)
			}
			for _, in := range sortedKeys(intos) {
				dec(mn+"/"+in, dm, h, intos[in])
			}
		}
	}
	// TagSet registration of unrelated numbers keeps working.
	for _, n := range []uint64{6, 100, 1000} {
		ts := cbor.NewTagSet()
		err := ts.Add(cbor.TagOptions{EncTag: cbor.EncTagRequired, DecTag: cbor.DecTagRequired}, reflect.TypeOf(omit{}), n)
		fmt.Printf("tagset\t%d\t%v\n", n, err == nil)
	}
	for _, h := range []string{"c48221196ab3", "c5822003", "d81e820103", "d86401", "c249010000000000000000"} {
		b, _ := hex.DecodeString(h)
		fmt.Printf("valid\t%s\t%v\n", h, cbor.Wellformed(b) == nil)
	}
}

func sortedKeys[V any](m map[string]V) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	for i := 1; i < len(out); i++ {
		for j := i; j > 0 && out[j] < out[j-1]; j-- {
			out[j], out[j-1] = out[j-1], out[j]
		}
	}
	return out
}
