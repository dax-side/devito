// probe_feature: pre-FP targets 2-10 for the exact-number task. Needs the new API, so it runs on the
// reference and on passers only. Diff a passer's output against the reference's.
// Lines are tagged S (stated in the description: a difference = do not send, add a test) or
// O (open/unstated: a difference = check against base convention, decide before the panel).
package main

import (
	"bytes"
	"time"
	"encoding/hex"
	"fmt"
	"math/big"
	"reflect"

	"github.com/fxamacker/cbor/v2"
)

func h(s string) []byte { b, _ := hex.DecodeString(s); return b }

func out(kind, name, res string) { fmt.Printf("%s\t%s\t%s\n", kind, name, res) }

func encR(kind, name string, em cbor.EncMode, v any) {
	withTimeout(kind, name, func() { encR0(kind, name, em, v) })
}

// withTimeout runs one probe case; a case that does not finish in 3s prints TIMEOUT (a hang or a huge allocation).
func withTimeout(kind, name string, f func()) {
	done := make(chan struct{})
	go func() {
		defer func() {
			if r := recover(); r != nil {
				out(kind, name, "PANIC")
			}
			close(done)
		}()
		f()
	}()
	select {
	case <-done:
	case <-time.After(3 * time.Second):
		out(kind, name, "TIMEOUT")
	}
}

func encR0(kind, name string, em cbor.EncMode, v any) {
	b, err := em.Marshal(v)
	if err != nil {
		out(kind, name, "ERR")
		return
	}
	out(kind, name, hex.EncodeToString(b))
}

func ratOf(v any) string {
	switch x := v.(type) {
	case big.Float:
		if x.IsInf() {
			return "inf"
		}
		r, _ := x.Rat(nil)
		return "Float " + r.String()
	case *big.Float:
		if x == nil {
			return "nil*Float"
		}
		return "*" + ratOf(*x)
	case big.Rat:
		return "Rat " + x.String()
	case *big.Rat:
		if x == nil {
			return "nil*Rat"
		}
		return "*" + ratOf(*x)
	case cbor.DecimalFraction:
		return fmt.Sprintf("DF %d %s", x.Exponent, x.Mantissa.String())
	case *cbor.DecimalFraction:
		if x == nil {
			return "nil*DF"
		}
		return "*" + ratOf(*x)
	case cbor.Tag:
		return fmt.Sprintf("Tag{%d,%v}", x.Number, x.Content)
	case []any:
		s := "["
		for i, e := range x {
			if i > 0 {
				s += ","
			}
			s += ratOf(e)
		}
		return s + "]"
	}
	return fmt.Sprintf("%T:%v", v, v)
}

func decR(kind, name string, dm cbor.DecMode, data string, into func() any) {
	withTimeout(kind, name+" "+data, func() { decR0(kind, name, dm, data, into) })
}

func decR0(kind, name string, dm cbor.DecMode, data string, into func() any) {
	v := into()
	if err := dm.Unmarshal(h(data), v); err != nil {
		out(kind, name+" "+data, "ERR")
		return
	}
	out(kind, name+" "+data, ratOf(reflect.ValueOf(v).Elem().Interface()))
}

// ratString calls DecimalFraction.Rat whatever its result shape (*big.Rat, or (*big.Rat, error)).
func ratString(d cbor.DecimalFraction) string {
	res := reflect.ValueOf(d).MethodByName("Rat").Call(nil)
	if len(res) == 2 && !res[1].IsNil() {
		return "ERR"
	}
	return fmt.Sprint(res[0].Interface())
}

func mustEnc(o cbor.EncOptions) cbor.EncMode { m, err := o.EncMode(); if err != nil { panic(err) }; return m }
func mustDec(o cbor.DecOptions) cbor.DecMode { m, err := o.DecMode(); if err != nil { panic(err) }; return m }

func main() {
	def := mustEnc(cbor.EncOptions{})
	decEnc := mustEnc(cbor.EncOptions{RatEnc: cbor.RatEncodeDecimalFraction})
	dd := mustDec(cbor.DecOptions{})
	dv := mustDec(cbor.DecOptions{ExponentMantissaDec: cbor.ExponentMantissaDecodeValue})

	// S: big.Float encoding (shortest mantissa, signs, zero, precision variants, extremes).
	pow := func(m int64, e int) *big.Float { return new(big.Float).SetMantExp(big.NewFloat(float64(m)), e) }
	floats := map[string]*big.Float{
		"1.5": big.NewFloat(1.5), "-1.5": big.NewFloat(-1.5), "0": big.NewFloat(0), "-0": new(big.Float).Neg(big.NewFloat(0)),
		"0.1": big.NewFloat(0.1), "12": big.NewFloat(12), "1": big.NewFloat(1), "-1": big.NewFloat(-1), "2^100": pow(1, 100),
		"2^-100": pow(1, -100), "3*2^-1074": pow(3, -1074), "prec200_1/3": new(big.Float).SetPrec(200).Quo(big.NewFloat(1).SetPrec(200), big.NewFloat(3)),
		"prec10_0.1": new(big.Float).SetPrec(10).SetFloat64(0.1), "huge_exp": pow(1, 1<<30), "tiny_exp": pow(1, -(1 << 30)),
		"zero_value": new(big.Float), "7*2^63": pow(7, 63),
	}
	for _, k := range keys(floats) {
		encR("S", "enc Float "+k, def, floats[k])
		encR("S", "enc Float value "+k, def, *floats[k])
	}
	encR("S", "enc +Inf", def, new(big.Float).SetInf(false))
	encR("S", "enc -Inf", def, new(big.Float).SetInf(true))

	// S: DecimalFraction encoding.
	dfs := map[string]cbor.DecimalFraction{
		"rfc": {Exponent: -2, Mantissa: *big.NewInt(27315)}, "zero_value": {}, "neg_mant": {Exponent: 1, Mantissa: *big.NewInt(-5)},
		"trailing_zeros_kept": {Exponent: 0, Mantissa: *big.NewInt(1000)}, "int64_min_exp": {Exponent: -1 << 63, Mantissa: *big.NewInt(1)},
		"int64_max_exp": {Exponent: 1<<63 - 1, Mantissa: *big.NewInt(1)}, "big_mant": {Exponent: -5, Mantissa: *new(big.Int).Lsh(big.NewInt(1), 100)},
	}
	for _, k := range keys(dfs) {
		encR("S", "enc DF "+k, def, dfs[k])
		d := dfs[k]
		if k != "int64_min_exp" && k != "int64_max_exp" {
			withTimeout("S", "DF.Rat "+k, func() { out("S", "DF.Rat "+k, ratString(d)) })
		}
	}

	// S: big.Rat in both modes.
	rats := map[string]*big.Rat{
		"1/3": big.NewRat(1, 3), "-1/3": big.NewRat(-1, 3), "1/6": big.NewRat(1, 6), "1/8": big.NewRat(1, 8), "100": big.NewRat(100, 1),
		"-7/20": big.NewRat(-7, 20), "0": big.NewRat(0, 1), "zero_value": new(big.Rat), "5": big.NewRat(5, 1), "1/1024": big.NewRat(1, 1024),
		"3/125": big.NewRat(3, 125), "1/10": big.NewRat(1, 10), "2^70": new(big.Rat).SetInt(new(big.Int).Lsh(big.NewInt(1), 70)),
		"1/2^70": new(big.Rat).SetFrac(big.NewInt(1), new(big.Int).Lsh(big.NewInt(1), 70)), "10^30": new(big.Rat).SetInt(new(big.Int).Exp(big.NewInt(10), big.NewInt(30), nil)),
		"1/7": big.NewRat(1, 7), "-1/40": big.NewRat(-1, 40),
	}
	for _, k := range keys(rats) {
		encR("S", "enc Rat default "+k, def, rats[k])
		encR("S", "enc Rat decimal "+k, decEnc, rats[k])
		encR("S", "enc Rat value decimal "+k, decEnc, *rats[k])
	}

	// O: interaction with other encode options.
	for name, o := range map[string]cbor.EncOptions{"bigintnone": {BigIntConvert: cbor.BigIntConvertNone}, "tagsforbid": {TagsMd: cbor.TagsForbidden},
		"canonical": cbor.CanonicalEncOptions(), "indefforbid": {IndefLength: cbor.IndefLengthForbidden}} {
		em := mustEnc(o)
		encR("O", "opt "+name+" Float 1.5", em, big.NewFloat(1.5))
		encR("O", "opt "+name+" Rat 1/3", em, big.NewRat(1, 3))
		encR("O", "opt "+name+" DF rfc", em, dfs["rfc"])
		if name == "canonical" {
			encR("O", "opt "+name+" map of Rat", em, map[string]*big.Rat{"b": big.NewRat(1, 2), "a": big.NewRat(3, 1)})
		}
	}
	type S struct {
		F  *big.Float           `cbor:"f,omitempty"`
		R  *big.Rat             `cbor:"r,omitempty"`
		D  *cbor.DecimalFraction `cbor:"d,omitempty"`
		FV big.Float            `cbor:"fv"`
	}
	encR("O", "struct nil ptrs omitempty", def, S{})
	encR("O", "struct set", def, S{F: big.NewFloat(2), R: big.NewRat(1, 2), D: &cbor.DecimalFraction{Exponent: 1, Mantissa: *big.NewInt(3)}})

	// S: decoding into concrete types.
	type into = func() any
	bf := func() any { return new(big.Float) }
	br := func() any { return new(big.Rat) }
	df := func() any { return new(cbor.DecimalFraction) }
	an := func() any { return new(any) }
	decodeCases := []string{
		"c5822003", "c5822022", "c5820000", "c58238361b000ccccccccccccd", "c582186401", "c58200c349ffffffffffffffffff",
		"c48221196ab3", "c4820307", "c48203c249010000000000000000", "d81e820103", "d81e822003", "d81e820204",
		"d81e82c24901000000000000000003", "c59f2003ff", "d81e9f0103ff", "c582c3410003", "d81e8202c24104",
		"c4821a000f424001", "c4823a000f423f01", "c4821a000f424101", "c4823a000f424001",
		"c5821a0098968001", "c5823a0098967f01", "c5821a0098968101", "c5823a0098968001",
		"c503", "c58120", "c583200304", "c582f93c0003", "c582206161", "d81e820100", "d81e820120", "822003",
		"d9d9f7c5822003", "d5c5822003", "c5821a7fffffff02", "c5821b7fffffffffffffff00", "c4821b7fffffffffffffff01",
		"c5821b800000000000000001",
	}
	for _, c := range decodeCases {
		for name, f := range map[string]into{"Float": bf, "Rat": br, "DF": df} {
			decR("S", "dec "+name, dd, c, f)
		}
		decR("S", "dec any default", dd, c, an)
		decR("S", "dec any value", dv, c, an)
	}

	// O: other decode options with the new tags.
	for name, o := range map[string]cbor.DecOptions{
		"tagcontent": {UnrecognizedTagToAny: cbor.UnrecognizedTagContentToAny}, "intsignedfail": {IntDec: cbor.IntDecConvertSignedOrFail},
		"bigptr": {BigIntDec: cbor.BigIntDecodePointer}, "indefforbid": {IndefLength: cbor.IndefLengthForbidden},
		"value+tagcontent": {ExponentMantissaDec: cbor.ExponentMantissaDecodeValue, UnrecognizedTagToAny: cbor.UnrecognizedTagContentToAny},
	} {
		dm := mustDec(o)
		for _, c := range []string{"c48221196ab3", "c5822003", "d81e820103", "d81e821bffffffffffffffff01", "c59f2003ff", "82c5822003d81e820103"} {
			decR("O", "opt "+name+" any", dm, c, an)
			decR("O", "opt "+name+" Rat", dm, c, br)
		}
	}
	for _, c := range []string{"c401", "c48221196ab3", "d81e820100", "c46178"} {
		decR("O", "dec Tag", dd, c, func() any { return new(cbor.Tag) })
		decR("O", "dec RawMessage", dd, c, func() any { return new(cbor.RawMessage) })
		b := h(c)
		out("O", "Wellformed "+c, fmt.Sprint(cbor.Wellformed(b) == nil))
	}

	// O: streaming decoder position after an error.
	for _, c := range []string{"c48221196ab301", "c40101", "d81e82010001"} {
		dec := cbor.NewDecoder(bytes.NewReader(h(c)))
		var f big.Float
		e1 := dec.Decode(&f)
		var n int
		e2 := dec.Decode(&n)
		out("O", "stream "+c, fmt.Sprintf("%v %v %d", e1 != nil, e2 == nil, n))
	}

	// O: TagSet.
	type myT struct{ X int }
	for _, n := range []uint64{4, 5, 30, 6} {
		ts := cbor.NewTagSet()
		err := ts.Add(cbor.TagOptions{EncTag: cbor.EncTagRequired, DecTag: cbor.DecTagRequired}, reflect.TypeOf(myT{}), n)
		out("O", fmt.Sprintf("TagSet.Add num %d", n), fmt.Sprint(err == nil))
	}
	for name, t := range map[string]reflect.Type{"Float": reflect.TypeOf(big.Float{}), "Rat": reflect.TypeOf(big.Rat{}), "DF": reflect.TypeOf(cbor.DecimalFraction{})} {
		ts := cbor.NewTagSet()
		err := ts.Add(cbor.TagOptions{EncTag: cbor.EncTagRequired, DecTag: cbor.DecTagRequired}, t, 1000)
		out("O", "TagSet.Add type "+name, fmt.Sprint(err == nil))
	}

	// S: options round trip and validation.
	out("S", "EncOptions round trip", fmt.Sprint(decEnc.EncOptions().RatEnc == cbor.RatEncodeDecimalFraction))
	out("S", "DecOptions round trip", fmt.Sprint(dv.DecOptions().ExponentMantissaDec == cbor.ExponentMantissaDecodeValue))
}

func keys[V any](m map[string]V) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	for i := 1; i < len(out); i++ {
		for j := i; j > 0 && out[j] < out[j-1]; j-- {
			out[j], out[j-1] = out[j-1], out[j]
		}
	}
	return out
}
