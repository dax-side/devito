"""Compare what passing and failing agent runs did, from a rollout zip.

usage: traj_features.py RUNS_DIR [keyword ...]

RUNS_DIR holds one folder per run with trajectory.json, eval-result.json and
solution-patch.patch (the platform's agent-runs zip, unzipped). For each run it
prints pass/fail, the number of tool calls, how often each keyword appears in the
agent's commands (use the traps the description names, e.g. "p_t=" "float32"),
the effective LOC of its solution, and suspicious lines in the patch (hardcoded
test constants, swallowed exceptions). If passers and failers use the hint
keywords equally, the hints are not what separates them; if only passers use a
hint, the description is doing the work for them.
"""
import glob, json, os, re, subprocess, sys

runs_dir, keywords = sys.argv[1], sys.argv[2:]
here = os.path.dirname(os.path.abspath(__file__))
suspicious = re.compile(r"except Exception|except:|\bpass$|# *noqa|nt *== *\d|shape\[\d\] *== *\d")
for path in sorted(glob.glob(os.path.join(runs_dir, '*', 'trajectory.json'))):
    run = os.path.dirname(path)
    steps = json.load(open(path))['steps']
    agent = [s for s in steps if s.get('source') == 'agent']
    calls = [c for s in agent for c in s.get('tool_calls', [])]
    text = ' '.join(json.dumps(c.get('arguments', '')) for c in calls)
    ok = json.load(open(os.path.join(run, 'eval-result.json')))['test_results']['new_tests_passed']
    patch = os.path.join(run, 'solution-patch.patch')
    loc = subprocess.run([sys.executable, os.path.join(here, 'effloc.py'), patch],
                         capture_output=True, text=True).stdout.split(' ')[0]
    sus = [l for l in open(patch).read().splitlines() if l.startswith('+') and suspicious.search(l)]
    counts = ' '.join(f'{k}={text.count(k)}' for k in keywords)
    print(f"{os.path.basename(run):16s} {'PASS' if ok else 'fail'} calls={len(calls)} effLOC={loc} "
          f"suspicious={len(sus)} {counts}")
