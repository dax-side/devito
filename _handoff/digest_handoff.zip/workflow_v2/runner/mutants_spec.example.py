# Example spec for mkmut.py, from the moving sparse points task (devito).
# Each entry: name -> (file, exact text in the solved tree, replacement).
# One mutant per promise and per route; name it after the promise it breaks.
S = 'devito/types/sparse.py'
I = 'devito/operations/interpolators.py'

MUTANTS = {
    'M1_gridpoints_from_first_step': (
        I,
        "            tables = {gp: _cell_indices(coords, grid, shifts, spacing, origin)}\n",
        "            tables = {gp: _cell_indices(np.broadcast_to(coords[:1], coords.shape) "
        "if coords.ndim == 3 else coords, grid, shifts, spacing, origin)}\n"),
    'M2_matrix_clears_self_not_row': (
        S,
        "        cleared = lhs if self._moving_locations else self\n",
        "        cleared = self\n"),
    'M3_rank_check_removed': (
        S,
        "        if key.ndim > 3:\n            raise ValueError(",
        "        if False:\n            raise ValueError("),
}
