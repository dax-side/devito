"""Spec-coverage scout: finds spec features a library never mentions anywhere (unwritten gaps).

    python3 scout_spec.py --out spec_out

For each spec, libraries come from packages.ecosyste.ms keyword search (500-20000 stars,
permissive licence, pushed in the last 6 months). Each repo is shallow-cloned and its source
(not tests, docs or changelogs) is searched for every feature of the spec. A feature with no
match in source, README, docs, tests or CHANGELOG is a candidate unwritten gap; check its issues
by hand before sizing it.
"""
import argparse
import datetime as dt
import json
import os
import re
import subprocess
import sys
import tempfile
import urllib.request

LICENCES = {"mit", "bsd-2-clause", "bsd-3-clause", "apache-2.0", "isc", "0bsd"}
SPECS = {
    "rrule (RFC 5545)": {
        "keywords": ["rrule", "icalendar", "ical", "recurrence"],
        "features": {
            "BYSETPOS": r"bysetpos", "BYWEEKNO": r"byweekno", "BYYEARDAY": r"byyearday",
            "BYEASTER": r"byeaster", "RSCALE (RFC 7529)": r"rscale", "SKIP (RFC 7529)": r"\bskip\b.*(omit|backward|forward)",
            "EXRULE": r"exrule", "RDATE": r"rdate", "EXDATE": r"exdate", "WKST": r"wkst",
        },
    },
    "JSONPath (RFC 9535)": {
        "keywords": ["jsonpath", "json-path"],
        "features": {
            "length()": r"[\"']length[\"']", "count()": r"[\"']count[\"']", "match()": r"[\"']match[\"']",
            "search()": r"[\"']search[\"']", "value()": r"[\"']value[\"']",
            "normalized paths": r"normali[sz]ed.?path", "I-Regexp (RFC 9485)": r"i-?regexp|9485",
        },
    },
    "ISO 8601": {
        "keywords": ["iso8601", "iso-8601", "datetime", "date-parser"],
        "features": {
            "week dates": r"week.?date|iso.?week|\bW\d\d", "ordinal dates": r"ordinal", "durations": r"duration",
            "intervals": r"interval", "repeating intervals": r"repeat|recurr", "fractional units": r"fraction",
        },
    },
    "CBOR (RFC 8949)": {
        "keywords": ["cbor"],
        "features": {
            "bignum tags": r"bignum|big.?int", "decimal fraction (tag 4)": r"decimal.?fraction", "bigfloat (tag 5)": r"bigfloat",
            "deterministic encoding": r"deterministic|canonical", "indefinite length": r"indefinite",
            "half float": r"half|float16|f16", "sets (tag 258)": r"\b258\b",
        },
    },
    "MessagePack": {
        "keywords": ["msgpack", "messagepack"],
        "features": {"timestamp ext (-1)": r"timestamp", "ext types": r"\bext", "bin/str separation": r"\bbin\b|binary"},
    },
    "YAML 1.2": {
        "keywords": ["yaml"],
        "features": {
            "merge keys": r"<<|merge", "!!binary": r"binary", "!!set": r"!!set|tag:yaml.org,2002:set",
            "!!omap": r"omap", "!!timestamp": r"timestamp", "YAML 1.2 core schema": r"1\.2|core.?schema",
            "%TAG directive": r"%tag|tag.?directive",
        },
    },
    "Structured Fields (RFC 8941/9651)": {
        "keywords": ["http", "http-headers", "headers"],
        "features": {"structured fields": r"structured.?field|8941|9651", "sf dates": r"@\d|sf-date|display.?string"},
    },
    "JMESPath": {
        "keywords": ["jmespath"],
        "features": {f: rf"[\"']{f}[\"']" for f in ("abs", "avg", "ceil", "contains", "ends_with", "floor", "join", "keys",
                                                     "length", "map", "max_by", "merge", "min_by", "not_null", "reverse",
                                                     "sort_by", "starts_with", "sum", "to_array", "to_number", "type", "values")},
    },
}
SRC_EXT = (".go", ".java", ".kt", ".ts", ".js", ".mjs", ".rs", ".py", ".cs", ".swift", ".rb", ".php", ".cpp", ".hpp", ".c", ".h")
ANY_EXT = SRC_EXT + (".md", ".rst", ".txt", ".json", ".yaml", ".yml")


def get(url):
    for attempt in range(3):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "task-scout (research)"})
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.load(r)
        except Exception:
            if attempt == 2:
                return None


def repos_for(keywords, since, pages):
    out = {}
    for kw in keywords:
        for page in range(1, pages + 1):
            d = get(f"https://packages.ecosyste.ms/api/v1/keywords/{kw}?per_page=100&page={page}")
            pk = (d or {}).get("packages") or []
            for p in pk:
                rm = p.get("repo_metadata") or {}
                url = (p.get("repository_url") or "").lower()
                if not url.startswith("https://github.com/") or rm.get("archived") or rm.get("fork"):
                    continue
                if not (500 <= (rm.get("stargazers_count") or 0) <= 20000) or (rm.get("license") or "").lower() not in LICENCES:
                    continue
                if (rm.get("pushed_at") or "") < since:
                    continue
                out[rm["full_name"]] = {"repo": rm["full_name"], "stars": rm["stargazers_count"], "lang": rm.get("language")}
            if len(pk) < 100:
                break
    return out


def corpus(root, exts, skip_tests):
    text = []
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if not x.startswith(".") and x not in ("node_modules", "vendor", "target", "dist", "build")]
        if skip_tests and re.search(r"(^|/)(tests?|spec|__tests__|testdata|docs?|examples?)(/|$)", os.path.relpath(d, root)):
            continue
        for f in files:
            if f.endswith(exts) and not (skip_tests and re.search(r"test|spec|changelog", f, re.I)):
                try:
                    text.append(open(os.path.join(d, f), encoding="utf-8", errors="ignore").read(300_000))
                except Exception:
                    pass
    return "\n".join(text)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="spec_out")
    ap.add_argument("--pages", type=int, default=3)
    ap.add_argument("--specs", nargs="*", default=list(SPECS))
    a = ap.parse_args()
    here = os.path.dirname(os.path.abspath(__file__))
    skip = {l.split()[0].lower() for l in open(os.path.join(here, "skip_list.txt")) if l.strip() and not l.startswith(";")}
    since = (dt.date.today() - dt.timedelta(days=183)).isoformat()
    rows = []
    with tempfile.TemporaryDirectory() as tmp:
        for spec in a.specs:
            cfg = SPECS[spec]
            repos = [r for r in repos_for(cfg["keywords"], since, a.pages).values() if r["repo"].lower() not in skip]
            print(f"{spec}: {len(repos)} repos", file=sys.stderr)
            for r in repos:
                dest = os.path.join(tmp, "repo")
                ok = subprocess.run(["git", "clone", "-q", "--depth", "1", "--filter=blob:limit=1m",
                                     f"https://github.com/{r['repo']}", dest], capture_output=True, timeout=300).returncode == 0
                if ok:
                    src = corpus(dest, SRC_EXT, True)
                    everywhere = corpus(dest, ANY_EXT, False)
                    present = [f for f, pat in cfg["features"].items() if re.search(pat, src, re.I)]
                    unwritten = [f for f, pat in cfg["features"].items() if not re.search(pat, everywhere, re.I)]
                    if present and unwritten:
                        rows.append(dict(r, spec=spec, has=present, unwritten=unwritten))
                        print(f"  {r['repo']}: missing {unwritten}", file=sys.stderr)
                subprocess.run(["rm", "-rf", dest])
    rows.sort(key=lambda x: (x["spec"], -len(x["has"])))
    json.dump(rows, open(a.out + ".json", "w"), indent=1)
    with open(a.out + ".md", "w") as f:
        f.write("# Spec coverage: features never mentioned anywhere in the repo\n\n| spec | repo | lang | stars | implements | never mentioned |\n|---|---|---|---|---|---|\n")
        for r in rows:
            f.write(f"| {r['spec']} | {r['repo']} | {r['lang']} | {r['stars']} | {', '.join(r['has'])} | {', '.join(r['unwritten'])} |\n")
    print(f"wrote {a.out}.md ({len(rows)} rows)", file=sys.stderr)


if __name__ == "__main__":
    main()
