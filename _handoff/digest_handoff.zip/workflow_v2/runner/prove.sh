#!/bin/bash
# Local proof for a Shipd task. Every step logs to OUT/log.txt; the last line is GO or NO-GO.
#
# usage: prove.sh SHA SOLUTION.patch TEST.patch DESCRIPTION.txt OUT [MUTANTS_DIR] [PREV_OUT]
#
# env (optional):
#   WORK   scratch root (default: parent of this script's folder)
#   BASE   clean clone of the repo, used to create worktrees (default: $WORK/base)
#   VENV   virtualenv with the repo's deps, ruff, flake8, pytest (default: $WORK/venv)
#   JOBS   mutants run in parallel (default: 4)
#   LOC_FLOOR  minimum effective solution lines (default: 200)
#   TEST_TIMEOUT  seconds before any single test.sh run is killed (default: 1800)
#   SKIP_MUTANTS  extended regex of mutant names to skip on reruns, e.g. 'M4_no_allowance' (default: none)
#
# The test patch must add test.sh with `new` and `base` modes that accept --output_path (Shipd convention),
# and test.sh must pass --maxfail=100000 to pytest.
set -u
SHA=$1; SOL=$(realpath $2); TST=$(realpath $3); DESC=$(realpath $4); OUT=$5; MUTS=${6:+$(realpath $6)}; PREV=${7:-}
R=$(cd "$(dirname "$0")" && pwd)
WORK=${WORK:-$(dirname "$R")}; BASE=${BASE:-$WORK/base}; VENV=${VENV:-$WORK/venv}
JOBS=${JOBS:-4}; LOC_FLOOR=${LOC_FLOOR:-200}; TEST_TIMEOUT=${TEST_TIMEOUT:-1800}; SKIP_MUTANTS=${SKIP_MUTANTS:-}
# A run killed mid-compile leaves codepy's cache lock behind and every later compile waits on it
# forever. No other run of this script may be active when it starts.
rm -f /tmp/devito-codepy-uid*/*/lock
export PATH=$VENV/bin:$PATH; PY=$VENV/bin/python
mkdir -p $OUT; OUT=$(realpath $OUT); LOG=$OUT/log.txt; : > $LOG; : > $OUT/nogo.txt
say() { echo "[$(date +%H:%M:%S)] $*" | tee -a $LOG; }
nogo() { say "NO-GO: $*"; echo "$*" >> $OUT/nogo.txt; }
tree() { git -C $BASE worktree remove --force $1 2>/dev/null; rm -rf $1; git -C $BASE worktree add -q $1 $SHA; }
chk() { local name=$1; shift; "$@" 2>&1 | tee -a $LOG; [ ${PIPESTATUS[0]} -eq 0 ] || nogo "$name"; }

say "STEP1 identity"; md5sum $SOL $TST $DESC | tee -a $LOG
say "STEP2 scope"; say "solution touches:"; $PY $R/gates.py touched $SOL | tee -a $LOG
say "test patch touches:"; $PY $R/gates.py touched $TST | tee -a $LOG
if grep -q $'\r' $SOL $TST $DESC; then nogo "CRLF in an artifact"; fi
say "STEP3 description scan"; chk "description scan" $PY $R/gates.py desc $DESC
say "STEP4 test grep gates"; chk "test grep gates" $PY $R/gates.py tests $TST
say "STEP5 effective LOC"; LOC=$($PY $R/effloc.py $SOL | tee -a $LOG | cut -d' ' -f1)
[ "$LOC" -ge "$LOC_FLOOR" ] || nogo "effective LOC $LOC below $LOC_FLOOR"

say "STEP6 trees"; tree $OUT/t_tests; tree $OUT/t_sol
( cd $OUT/t_tests && git apply --check $TST && git apply $TST ) 2>&1 | tee -a $LOG; [ ${PIPESTATUS[0]} -eq 0 ] || nogo "test patch does not apply"
( cd $OUT/t_sol && git apply $TST && git apply --check $SOL && git apply $SOL ) 2>&1 | tee -a $LOG; [ ${PIPESTATUS[0]} -eq 0 ] || nogo "solution patch does not apply"
( cd $OUT/t_sol && git diff --check ) 2>&1 | tee -a $LOG; [ ${PIPESTATUS[0]} -eq 0 ] || nogo "git diff --check"

say "STEP7 lint (ruff + flake8, repo config) on touched python files"
PYFILES=$( ( $PY $R/gates.py touched $SOL; $PY $R/gates.py touched $TST ) | grep '\.py$' | sort -u | tr '\n' ' ')
( cd $OUT/t_sol && ruff check $PYFILES ) 2>&1 | tee -a $LOG; [ ${PIPESTATUS[0]} -eq 0 ] || nogo "ruff"
( cd $OUT/t_sol && flake8 $PYFILES ) 2>&1 | tee -a $LOG; [ ${PIPESTATUS[0]} -eq 0 ] || nogo "flake8"

run() { local t=$1 mode=$2 x=$3; ( cd $t && PYTHONPATH=$t timeout $TEST_TIMEOUT ./test.sh --output_path $x $mode > $x.log 2>&1 ) || [ $? -ne 124 ] || nogo "$mode in $(basename $t) timed out after ${TEST_TIMEOUT}s"; say "$mode in $(basename $t): $(tail -1 $x.log)"; }
say "STEP8 red state (new tests on base must all fail, error or skip)"
run $OUT/t_tests new $OUT/red_new.xml
chk "new tests pass on base" $PY $R/junitcmp.py passing $OUT/red_new.xml

say "STEP9 green x3 and base parity"
run $OUT/t_sol new $OUT/green1.xml & run $OUT/t_tests base $OUT/base_tests.xml & wait
run $OUT/t_sol new $OUT/green2.xml & run $OUT/t_sol base $OUT/base_sol.xml & wait
run $OUT/t_sol new $OUT/green3.xml
chk "green runs differ" $PY $R/junitcmp.py same $OUT/green1.xml $OUT/green2.xml $OUT/green3.xml
if grep -qE 'failed|error' <(tail -1 $OUT/green1.xml.log); then nogo "new tests fail with the solution"; fi
chk "base parity" $PY $R/junitcmp.py same $OUT/base_tests.xml $OUT/base_sol.xml

if [ -n "$MUTS" ] && ls $MUTS/*.patch >/dev/null 2>&1; then
  say "STEP10 mutants (each must fail at least one new test)"
  for mp in $MUTS/*.patch; do
    m=$(basename $mp .patch); d=$OUT/mut_$m
    if [ -n "$SKIP_MUTANTS" ] && echo "$m" | grep -Eq "$SKIP_MUTANTS"; then say "$m: SKIPPED (SKIP_MUTANTS)"; continue; fi
    tree $d
    ( cd $d && git apply $TST && git apply $SOL ) >/dev/null 2>&1
    ( cd $d && git apply $mp ) >/dev/null 2>&1 || { nogo "$m does not apply: REBUILD it"; rm -rf $d; }
  done
  one() { m=$1; d=$OUT/mut_$m; [ -d $d ] || return 0
    ( cd $d && PYTHONPATH=$d timeout $TEST_TIMEOUT ./test.sh --output_path $OUT/mut_$m.xml new > $OUT/mut_$m.log 2>&1 )
    r=$($PY $R/junitcmp.py failing $OUT/mut_$m.xml ${PREV:+$PREV/mut_$m.xml}); st=$?
    [ $st -eq 0 ] && echo "$m: KILLED $r" || echo "$m: SURVIVED $r"; }
  export -f one; export OUT PY R PREV TEST_TIMEOUT
  ls $MUTS/*.patch | xargs -n1 basename | sed 's/\.patch$//' | xargs -P $JOBS -I{} bash -c 'one {}' | tee -a $LOG
  say "survivors are not automatically NO-GO: triage each one (see gates.md G5)"
fi

if [ -s $OUT/nogo.txt ]; then say "RESULT NO-GO"; cat $OUT/nogo.txt | tee -a $LOG; else say "RESULT GO"; fi
