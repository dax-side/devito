#!/usr/bin/env python3
"""
SQ lint: catch what Solution Quality keeps finding, locally and in seconds.

1. Unbounded words: every sentence of the description with a universal word
   (any, every, all, whole, arbitrary, ...) and no number or finite set in it
   is listed. SQ stress-tests each one at an extreme (lessons.md, round 28).
2. Probes: runs each probe of a task's probe file against the reference, one
   subprocess each, under a time and memory limit, and reports crashes with
   the wrong exception, timeouts and memory blow-ups. Write probes for every
   pair of stated features used together, and for every bound at its limit.

Usage:
    sq_lint.py description.txt [probes.py] [--timeout 60] [--memory-mb 2048]

The probe file defines PROBES = {name: (function, expect)}, where function
takes no arguments and runs the reference, and expect is "ok" (must return),
"refuse" (must raise ValueError), or a callable checking the returned value.
Run it from the tree with the solution applied (PYTHONPATH set).
"""
import argparse
import importlib.util
import multiprocessing as mp
import re
import resource
import sys
import traceback

UNIVERSAL = r"\b(any|every|all|whole|arbitrary|always|never|each|whatever|whichever|unbounded)\b"
BOUND = r"(\d|\bone\b|\btwo\b|\bthree\b|\bfour\b|\bfive\b|\bsix\b|\bseven\b|\beight\b|" \
        r"\bnine\b|\bten\b|\bat most\b|\bup to\b|\bbetween\b)"


def unbounded(text):
    sentences = re.split(r"(?<=[.!?])\s+", text.replace("\n", " "))
    found = []
    for s in sentences:
        words = sorted({w.lower() for w in re.findall(UNIVERSAL, s, re.I)})
        if words and not re.search(BOUND, s, re.I):
            found.append((words, s.strip()))
    return found


def _run(fn, memory_mb, queue):
    try:
        limit = memory_mb * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
    except (ValueError, OSError):
        pass
    try:
        queue.put(("returned", repr(fn())[:120]))
    except ValueError as e:
        queue.put(("ValueError", str(e)[:120]))
    except MemoryError:
        queue.put(("MemoryError", "over the memory limit"))
    except BaseException as e:  # noqa: B036
        queue.put((type(e).__name__, traceback.format_exc(limit=2)[-300:]))


def probe(name, fn, expect, timeout, memory_mb):
    queue = mp.Queue()
    proc = mp.Process(target=_run, args=(fn, memory_mb, queue))
    proc.start()
    proc.join(timeout)
    if proc.is_alive():
        proc.kill()
        return "FAIL", f"timeout after {timeout}s"
    if queue.empty():
        return "FAIL", f"died (exit {proc.exitcode}), likely memory"
    kind, detail = queue.get()
    if expect == "refuse":
        return ("ok" if kind == "ValueError" else "FAIL"), f"{kind}: {detail}"
    if kind != "returned":
        return "FAIL", f"{kind}: {detail}"
    if callable(expect):
        return ("ok" if expect(eval(detail)) else "FAIL"), detail  # noqa: S307
    return "ok", detail


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("description")
    ap.add_argument("probes", nargs="?")
    ap.add_argument("--timeout", type=float, default=60)
    ap.add_argument("--memory-mb", type=int, default=2048)
    a = ap.parse_args()

    flags = unbounded(open(a.description).read())
    print(f"== Unbounded words: {len(flags)} sentence(s)")
    for words, s in flags:
        print(f"  [{', '.join(words)}] {s[:220]}")

    fails = 0
    if a.probes:
        spec = importlib.util.spec_from_file_location("probes", a.probes)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        print(f"== Probes: {len(mod.PROBES)}")
        for name, (fn, expect) in mod.PROBES.items():
            verdict, detail = probe(name, fn, expect, a.timeout, a.memory_mb)
            fails += verdict != "ok"
            print(f"  {verdict:4s} {name}: {detail}")
    print(f"RESULT {len(flags)} unbounded, {fails} probe failures")
    return 1 if fails else 0


if __name__ == "__main__":
    mp.set_start_method("fork")
    sys.exit(main())
