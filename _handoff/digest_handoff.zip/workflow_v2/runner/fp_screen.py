#!/usr/bin/env python3
"""
FP screen: run the same fair probes on the reference and on every passing run,
and list each probe where a passer disagrees with the reference. Do this after
every batch with passes, before the FP panel runs (field manual 13.10, guide 11).

Usage (from a tree with one solution applied, PYTHONPATH set to it):
    fp_screen.py probes.py --out result.json [--timeout 60] [--memory-mb 2048]
    fp_screen.py --compare ref.json cand1.json cand2.json ... [--rel 1e-4]

The probe file defines PROBES = {name: (function, expect)} as for sq_lint.py;
only the functions are used here. Write probes for: every stated feature at the
ends of its stated range and one step beyond, every pair of stated features,
every refusal reason with an input it does not name literally, every sentinel
or classification promise (0.0, inf, None, empty) at extreme magnitudes, and
inputs the description is silent on (the reference's answer must be one a
reader could defend from the prompt).

Reading the comparison:
- A disagreement on a stated, tested-range behaviour: a real FP. Add a test.
- A disagreement past a stated bound or on a silent input: the prompt is open
  there. Either bound it in words ("may"), or make the reference match the
  passers, never test it without a sentence that states it.
"""
import argparse
import importlib.util
import json
import math
import multiprocessing as mp
import resource
import sys


def _run(fn, memory_mb, queue):
    try:
        limit = memory_mb * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
    except (ValueError, OSError):
        pass
    try:
        value = fn()
        try:
            queue.put(("value", float(value)))
        except (TypeError, ValueError):
            queue.put(("value", repr(value)[:120]))
    except BaseException as e:  # noqa: B036
        # Subclasses of ValueError (a task's own error type) count as ValueError
        queue.put(("raises", "ValueError" if isinstance(e, ValueError) else type(e).__name__))


def run(fn, timeout, memory_mb):
    queue = mp.Queue()
    proc = mp.Process(target=_run, args=(fn, memory_mb, queue))
    proc.start()
    proc.join(timeout)
    if proc.is_alive():
        proc.kill()
        return ("timeout", timeout)
    if queue.empty():
        return ("died", proc.exitcode)
    return queue.get()


def same(a, b, rel):
    if a[0] != b[0]:
        return False
    if a[0] == "raises":
        known = ("ValueError", "StabilityError")
        return (a[1] in known) == (b[1] in known)
    x, y = a[1], b[1]
    if isinstance(x, float) and isinstance(y, float):
        if math.isinf(x) or math.isinf(y) or x == 0 or y == 0:
            return x == y
        return abs(x / y - 1) <= rel
    return x == y


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("probes", nargs="?")
    ap.add_argument("--out")
    ap.add_argument("--compare", nargs="+")
    ap.add_argument("--rel", type=float, default=1e-4)
    ap.add_argument("--timeout", type=float, default=60)
    ap.add_argument("--memory-mb", type=int, default=2048)
    a = ap.parse_args()

    if a.compare:
        ref = json.load(open(a.compare[0]))
        bad = 0
        for path in a.compare[1:]:
            cand = json.load(open(path))
            diffs = [n for n in ref if n not in cand or not same(ref[n], cand[n], a.rel)]
            bad += bool(diffs)
            print(f"== {path}: {len(diffs)} disagreement(s)")
            for n in diffs:
                print(f"  {n}: reference {ref[n]}, passer {cand.get(n)}")
        return 1 if bad else 0

    spec = importlib.util.spec_from_file_location("probes", a.probes)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    results = {}
    for name, (fn, _) in mod.PROBES.items():
        results[name] = run(fn, a.timeout, a.memory_mb)
        print(f"  {name}: {results[name]}", flush=True)
    json.dump(results, open(a.out, "w"), indent=1)
    return 0


if __name__ == "__main__":
    mp.set_start_method("fork")
    sys.exit(main())
