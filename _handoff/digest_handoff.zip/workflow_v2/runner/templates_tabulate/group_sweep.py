"""Group titles must behave like header cells: multiline, colour, wide chars, wrapped headers."""
import itertools, re
from tabulate import tabulate
ANSI = re.compile(r"\x1b\[[0-9;]*m")
SEP = "|│┃║"
GRID = ["grid", "simple_grid", "rounded_grid", "heavy_grid", "mixed_grid", "double_grid",
        "fancy_grid", "colon_grid", "outline", "simple_outline", "rounded_outline",
        "heavy_outline", "mixed_outline", "double_outline", "fancy_outline"]
BORDERED = ["psql", "pretty", *GRID]
FMTS = ["simple", "plain", *BORDERED]
try:
    import wcwidth
    vis = lambda s: wcwidth.wcswidth(ANSI.sub("", s))
except ImportError:
    vis = lambda s: len(ANSI.sub("", s))
TITLES = ["A\nB", "Two\nline title here", "x\n\ny", "\x1b[31mred\nline\x1b[0m", "日本語\nタイトル", "naïve\nok",
          "", " ", "A very long single line title"]
DATA = {
    "plain": ([["aaa", 11, 22], ["bbb", 33, 44]], ["key", "xval", "yval"]),
    "multi_head": ([["aaa", 11, 22]], ["key\nk2", "xval", "yval"]),
    "multi_data": ([["a\nb", 11, 22]], ["key", "xval", "yval"]),
    "wide_data": ([["日本", 11, 22]], ["key", "xval", "yval"]),
}
bad, n = [], 0
for fmt, title, (dn, (rows, head)), hdr, idx, span, align in itertools.product(
        FMTS, TITLES, DATA.items(), [True, False], [False, True], [1, 2, 3], ["left", "center", "right"]):
    ncols = 3 + idx
    if span > ncols:
        continue
    kw = {"headers": head} if hdr else {}
    n += 1
    try:
        out = tabulate(rows, tablefmt=fmt, showindex=idx, headergroups=[(title, span, align)], **kw)
        out2 = tabulate(rows, tablefmt=fmt, showindex=idx, headergroups=[(title, span, align)], footer=["f"], maxheadercolwidths=3 if hdr else None, **kw)
    except Exception as e:
        bad.append((fmt, repr(title), dn, hdr, idx, span, align, "ERR " + repr(e)[:80])); continue
    for o in (out, out2):
        lines = o.splitlines()
        if fmt in BORDERED and len({vis(l) for l in lines}) != 1:
            bad.append((fmt, repr(title), dn, hdr, idx, span, align, "ragged lines")); break
        for t_line in [x for x in title.splitlines() if x.strip()]:
            if not any(ANSI.sub("", t_line) in ANSI.sub("", l) for l in lines):
                bad.append((fmt, repr(title), dn, hdr, idx, span, align, f"title line {t_line!r} missing")); break
print(n, "cases,", len(bad), "problems")
for b in bad[:12]: print("  ", b)
