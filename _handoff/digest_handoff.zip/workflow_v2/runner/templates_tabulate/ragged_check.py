"""With a footer or groups, the rest of a ragged table must look exactly as without them."""
import re
from tabulate import tabulate, tabulate_formats, SEPARATING_LINE
DATA = {
    "short_first": [["r1"], ["r2", 3]],
    "long_first": [["r1", 1, 2], ["r2"]],
    "text": [["r1"], ["r2", "long text"], ["r3", "x", "yy"]],
    "sepline": [["r1", 1], SEPARATING_LINE, ["r2", 2]],
}
HEAD = {"none": (), "short": ["h1"], "equal": ["h1", "h2"], "long": ["h1", "h2", "h3", "h4"]}
GROUP_FMTS = {"simple", "plain", "psql", "pretty"} | {f for f in tabulate_formats if "grid" in f or "outline" in f}
bad, errors, n = [], [], 0
for dn, rows in DATA.items():
    for hn, hd in HEAD.items():
        for fmt in tabulate_formats:
            for idx in (False, True):
                base = tabulate(rows, headers=hd, tablefmt=fmt, showindex=idx)
                for kind, kw in (("footer", {"footer": ["Z"]}), ("groups", {"headergroups": [("Q", 1)]})):
                    if kind == "groups" and fmt not in GROUP_FMTS:
                        continue
                    n += 1
                    try:
                        out = tabulate(rows, headers=hd, tablefmt=fmt, showindex=idx, **kw)
                    except Exception as e:
                        errors.append((dn, hn, fmt, idx, kind, repr(e)))
                        continue
                    if kind == "footer":
                        if fmt in ("html", "unsafehtml"):
                            ok = out.split("<tfoot>")[0] == base.split("</table>")[0]
                        else:
                            bl = base.splitlines()
                            last = max(i for i, l in enumerate(bl) if "r2" in l or "r3" in l)
                            ok = out.splitlines()[: last + 1] == bl[: last + 1] and "Z" in out
                    else:
                        ol = out.splitlines()
                        g = next(i for i, l in enumerate(ol) if re.search(r"\bQ\b", l))
                        bl = base.splitlines()
                        strip = lambda ls: [l for l in ls if re.search(r"[A-Za-z0-9]", l)]
                        ok = strip(ol[g + 1 :]) == strip(bl)
                    if not ok:
                        bad.append((dn, hn, fmt, idx, kind))
print(n, "cases;", len(bad), "changed;", len(errors), "errors")
for b in bad[:10]: print("  CHANGED", b)
for e in errors[:10]: print("  ERROR", e)
