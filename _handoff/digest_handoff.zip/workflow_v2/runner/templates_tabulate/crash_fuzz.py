"""Every footer value kind / title kind x existing options: our code must not raise where base
tabulate (same call without footer/headergroups) does not."""
import itertools, json, sys
from decimal import Decimal
from tabulate import tabulate
red = "\x1b[31m{}\x1b[0m".format
class Obj:
    def __str__(self): return "obj"
COLS = {"int": [1, 22], "float": [1.5, 22.25], "text": ["ab", "cdef"], "numstr": ["1", "22"],
        "colint": [red(1), 22], "none": [None, 3], "bool": [True, False], "bytes": [b"ab", b"cd"],
        "dec": [Decimal("1.5"), Decimal("2.25")], "multi": ["a\nb", "c"]}
VALS = [None, 3, -3, 2.5, 3000, "x", "", red("3"), red("2.5"), red("x"), "\x1b[1m\x1b[31m7\x1b[0m",
        "3000", "1,000", red("1,000"), b"abc", b"7", b"", True, False, Decimal("2.50"), Obj(),
        "long footer text here", red("long red text here"), "a\nb", 10**20, float("nan"), float("inf")]
OPTS = [{}, {"maxcolwidths": 5}, {"maxcolwidths": [None, 3]}, {"maxcolwidths": 1},
        {"maxheadercolwidths": 2}, {"disable_numparse": True}, {"disable_numparse": [1]},
        {"missingval": "?"}, {"showindex": True}, {"colalign": ("right", "left")},
        {"numalign": "decimal"}, {"stralign": "center"}, {"intfmt": "03d", "floatfmt": ".2f"},
        {"intfmt": ",", "floatfmt": ",.1f"}, {"floatfmt": [".1f", ".3f"]},
        {"maxcolwidths": 5, "intfmt": "03d"}, {"maxcolwidths": 5, "floatfmt": ".2f"},
        {"maxcolwidths": 3, "disable_numparse": True}]
HEADS = [(), ["k", "v"], ["v"]]
FMTS = ["simple", "grid", "html", "rst", "pipe", "latex_longtable", "psql", "moinmoin", "jira"]
TITLES = ["G", red("G"), 7, b"bt", "A very long group title", "a\nb", ""]
crash = {}
n = 0
def note(key, call):
    global n
    n += 1
    try:
        call()
    except Exception as e:
        crash.setdefault(f"{type(e).__name__}: {str(e)[:70]}", []).append(key)
for (cn, col), opt, hd, fmt in itertools.product(COLS.items(), OPTS, HEADS, FMTS):
    rows = [["r", c] for c in col]
    try:
        tabulate(rows, headers=hd, tablefmt=fmt, **opt)
    except Exception:
        continue  # base-style call already fails; not ours
    for v in VALS:
        note(("footer", cn, repr(v), str(opt), str(hd), fmt),
             lambda: tabulate(rows, headers=hd, tablefmt=fmt, footer=["t", v], **opt))
    if fmt in ("simple", "grid", "psql"):
        for t in TITLES:
            for span in (1, 2):
                note(("groups", cn, repr(t), span, str(opt), str(hd), fmt),
                     lambda: tabulate(rows, headers=hd, tablefmt=fmt, headergroups=[(t, span)], **opt))
                note(("both", cn, repr(t), span, str(opt), str(hd), fmt),
                     lambda: tabulate(rows, headers=hd, tablefmt=fmt, headergroups=[(t, span)],
                                      footer=["t", red("3")], **opt))
print(n, "calls,", sum(map(len, crash.values())), "crashes")
for k, v in sorted(crash.items(), key=lambda x: -len(x[1])):
    print(f"{len(v):6d}  {k}")
    for ex in v[:3]: print("          ", ex)
