"""Record what one agent implementation does on every behaviour that mattered."""
import json, re, sys
from decimal import Decimal
from tabulate import tabulate, SEPARATING_LINE
red, green = "\x1b[31m{}\x1b[0m".format, "\x1b[32m{}\x1b[0m".format
bold_red = "\x1b[1m\x1b[31m{}\x1b[0m".format
R = {}
def run(k, f):
    try:
        R[k] = f()
    except Exception as e:
        R[k] = "ERR " + type(e).__name__
def foot_line(t):
    lines = [l for l in t.splitlines() if l.strip() and re.search(r"[A-Za-z0-9]", l)]
    return lines[-1] if lines else ""
# colour
run("col_desc_red3", lambda: red("003") in tabulate([[1], [2]], footer=[red("3")], intfmt="03d"))
run("col_negative", lambda: red("-03") in tabulate([[1], [2]], footer=[red("-3")], intfmt="03d"))
run("col_float_green2", lambda: green("2.00") in tabulate([[1.5], [2.25]], footer=[green("2")], floatfmt=".2f"))
run("col_float_red3", lambda: red("3.00") in tabulate([[1.5], [2.25]], footer=[red("3")], floatfmt=".2f"))
run("col_stacked", lambda: bold_red("007") in tabulate([[1000]], footer=[bold_red("7")], intfmt="03d"))
run("col_float_corrupt", lambda: "\x1b[32.00m" in tabulate([[1.5], [2.25]], footer=[green("2")], floatfmt=".2f"))
# default path
ROWS = [["apples", 3, 1.5], ["pears", 12, 20.25]]
run("dp_extra_header_same", lambda: tabulate(ROWS, headers=["a", "b", "c", "extra"]) == tabulate(ROWS, headers=["a", "b", "c"]))
run("dp_ragged_same", lambda: tabulate([["a", 1], ["b", 2, 3]], headers=["k", "v"]) == "k      v\n---  ---\na      1\nb      2")
# html placement
def html_place():
    o = tabulate(ROWS, headers=["a", "b", "c"], tablefmt="html", footer=["T", 1, 2])
    if "<tfoot>" not in o: return "no tfoot"
    if o.index("<tfoot>") < o.index("<tbody>"): return "after thead"
    if o.index("<tfoot>") > o.index("</tbody>"): return "after tbody"
    return "inside tbody"
run("html_place", html_place)
# empty data line, rst
run("empty_data_line", lambda: tabulate([], headers=["x"], footer=[77]).splitlines())
run("rst_padded_dots", lambda: foot_line(tabulate(ROWS, headers=["a", "b", "c"], tablefmt="rst", footer=[1, 2])).lstrip().startswith(".."))
# validation / unstated inputs
run("overlong_footer", lambda: foot_line(tabulate([["a", 1]], footer=["t", 2, 3])))
run("bad_align", lambda: "G" in tabulate([["a", 1]], headers=["k", "v"], tablefmt="grid", headergroups=[("G", 1, "middle")]))
run("span_too_big", lambda: "G" in tabulate([["a", 1]], headers=["k", "v"], tablefmt="grid", headergroups=[("G", 5)]))
run("groups_on_html", lambda: "G" in tabulate([["a", 1]], headers=["k", "v"], tablefmt="html", headergroups=[("G", 2)]))
# values
run("bytes", lambda: foot_line(tabulate([["a", 1]], footer=[b"abc", True])).split())
run("decimal", lambda: foot_line(tabulate([["a", 1.5]], footer=["t", Decimal("2.00")])).split())
run("decimal_floatfmt", lambda: foot_line(tabulate([["a", 1.5]], footer=["t", Decimal("2.00")], floatfmt=".1f")).split())
run("numstr", lambda: foot_line(tabulate([["a", 1]], footer=["t", "3000"], intfmt=",")).split())
run("multiline_title_ok", lambda: len({len(l) for l in tabulate([[1, 2]], headers=["h1", "h2"], tablefmt="grid", headergroups=[("A\nB", 2)]).splitlines()}) == 1)
run("simple_headerless_rules", lambda: tabulate([["a", 1]], footer=["t", 2]).splitlines()[0].startswith("-"))
run("decimal_align", lambda: len({l.index(".") for l in tabulate([["a", 1.25], ["b", 10.5]], footer=["t", 2.5]).splitlines() if "." in l}) == 1)
run("sepline_footer", lambda: foot_line(tabulate([["a", 1], SEPARATING_LINE, ["b", 2]], footer=["t", 3])).split())
json.dump(R, open(sys.argv[1], "w"), default=str)
