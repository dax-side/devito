import json, os, re, glob, hashlib, collections, datetime
W = "/tmp/claude-0/-home-user-go-yaml/abaa713c-f366-53f8-b0cd-975fe838fcfc/scratchpad"
C = f"{W}/calib"
ref = json.load(open(f"{C}/REFERENCE.probe.json"))
rows = []
for tree in open(f"{C}/trees.txt").read().split():
    key = tree.replace(W + "/", "").replace("/", "__")
    if tree.startswith(f"{W}/replay_all/"):
        b, r = os.path.basename(tree).split("__", 1); src = f"{W}/{b}/{r}"
    elif "runs11rep" in tree: src = f"{W}/runs11/{os.path.basename(tree)}"
    elif "runs13rep" in tree: src = f"{W}/runs13/{os.path.basename(tree)}"
    else: src = f"{W}/runs14/Nova_Nova"
    row = {"key": key, "agent": "Orion" if "Orion" in key else "Nova"}
    fails = sorted({l.strip().split("[")[0] for l in open(f"{C}/{key}.v49") if l.strip()})
    row["fails"] = fails; row["nfail"] = len(fails)
    row["probe"] = json.load(open(f"{C}/{key}.probe.json"))
    patch = open(f"{src}/solution-patch.patch", errors="ignore").read() if os.path.exists(f"{src}/solution-patch.patch") else ""
    files = re.findall(r"^diff --git a/(\S+)", patch, re.M)
    row["own_tests"] = any(f.startswith("test/") and f not in ("test/test_api.py",) for f in files)
    body = patch.split("diff --git a/tabulate/__init__.py")[1].split("diff --git")[0] if "diff --git a/tabulate/__init__.py" in patch else ""
    row["added_lines"] = sum(1 for l in body.splitlines() if l.startswith("+") and not l.startswith("+++"))
    row["reuse_format"] = any(re.search(r"\b_format\(", l) for l in body.splitlines() if l.startswith("+"))
    row["touch_normalize"] = bool(re.search(r"^@@.*def _normalize_tabular_data", body, re.M)) or any("headers_pad" in l for l in body.splitlines() if l[:1] in "+-" and not l.startswith(("+++", "---")))
    tj = f"{src}/trajectory.json"
    if os.path.exists(tj):
        d = json.load(open(tj)); steps = d["steps"]
        desc = next((s["message"] for s in steps if s["source"] == "user" and ("footer" in s["message"])), "")
        row["desc_hash"] = hashlib.md5(desc.encode()).hexdigest()[:8]
        row["desc_words"] = len(re.findall(r"\w+", desc))
        row["desc_flags"] = {"red003": "003" in desc, "abcTrue": "abc True" in desc, "after_thead": "after thead" in desc, "errors_required": bool(re.search(r"raise|ValueError|TypeError", desc)) and "you can throw" not in desc}
        ts = [datetime.datetime.fromisoformat(s["timestamp"].replace("Z", "+00:00")) for s in steps if s.get("timestamp")]
        row["minutes"] = round((max(ts) - min(ts)).total_seconds() / 60, 1) if len(ts) > 1 else None
        row["first_ts"] = min(ts).isoformat() if ts else ""
        fm = d.get("final_metrics", {})
        row["tokens"] = fm.get("extra", {}).get("total_tokens"); row["requests"] = len(fm.get("extra", {}).get("per_request_usage", []))
        final = steps[-1]["message"] if steps and steps[-1]["source"] == "agent" else ""
        row["claims_pass"] = bool(re.search(r"\d+ passed|all tests pass|tests pass", final, re.I))
        row["mentions_colour"] = bool(re.search(r"ansi|colou?r", final, re.I))
    rows.append(row)
json.dump(rows, open(f"{C}/rows.json", "w"), default=str, indent=0)
n = len(rows); P = lambda x: f"{x}/{n} ({100*x/n:.0f}%)"
def rate(pred, sub=None):
    s = [r for r in rows if (sub is None or sub(r))]
    k = sum(1 for r in s if pred(r)); return f"{k}/{len(s)} ({100*k/max(1,len(s)):.0f}%)"
pr = lambda f: (lambda r: r["probe"].get(f))
print("RUNS", n, "| Nova", sum(r["agent"] == "Nova" for r in rows), "| Orion", sum(r["agent"] == "Orion" for r in rows))
print("pass on v49:", rate(lambda r: r["nfail"] == 0), "| <=1 fail:", rate(lambda r: r["nfail"] <= 1), "| <=2:", rate(lambda r: r["nfail"] <= 2))
print("fail-count distribution:", sorted(collections.Counter(min(r["nfail"], 10) for r in rows).items()))
print("most failed tests:", collections.Counter(t for r in rows for t in r["fails"]).most_common(12))
print("\n== behaviours (all / Nova / Orion)")
for name, f in [("colour: desc example red 3", pr("col_desc_red3")), ("colour: negative", pr("col_negative")), ("colour: float green 2", pr("col_float_green2")),
                ("colour: red 3 in float column", pr("col_float_red3")), ("colour: stacked codes", pr("col_stacked")), ("colour: CORRUPTS escape code", lambda r: r["probe"].get("col_float_corrupt") is True),
                ("colour: all 5 right", lambda r: all(r["probe"].get(k) is True for k in ("col_desc_red3", "col_negative", "col_float_green2", "col_float_red3", "col_stacked"))),
                ("default path: extra header unchanged", pr("dp_extra_header_same")), ("default path: ragged unchanged", pr("dp_ragged_same")),
                ("touches _normalize_tabular_data / headers_pad", lambda r: r["touch_normalize"]), ("reuses base _format in new code", lambda r: r["reuse_format"]),
                ("empty data: header line repeated", lambda r: r["probe"].get("empty_data_line") == ref["empty_data_line"]), ("rst: padded first cell '..'", pr("rst_padded_dots")),
                ("decimal alignment of footer", pr("decimal_align")), ("multiline title OK", pr("multiline_title_ok")), ("bytes -> abc True", lambda r: r["probe"].get("bytes") == ["abc", "True"]),
                ("Decimal 2.00 kept", lambda r: r["probe"].get("decimal") == ["t", "2.00"]), ("numeric string '3000' formatted", lambda r: r["probe"].get("numstr") == ["t", "3,000"]),
                ("Decimal + floatfmt .1f -> 2.0 (applies fmt)", lambda r: r["probe"].get("decimal_floatfmt") == ["t", "2.0"]),
                ("headerless simple keeps top rule", pr("simple_headerless_rules")), ("wrote own test file", lambda r: r["own_tests"]),
                ("final message claims tests pass", lambda r: r.get("claims_pass"))]:
    print(f"  {name:48s} {rate(f):>14s} {rate(f, lambda r: r['agent'] == 'Nova'):>14s} {rate(f, lambda r: r['agent'] == 'Orion'):>12s}")
print("\nhtml tfoot placement:", collections.Counter(r["probe"].get("html_place") for r in rows))
print("overlong footer:", collections.Counter(("raises " + v[4:]) if isinstance(v, str) and v.startswith("ERR") else ("extra cells shown" if isinstance(v, str) and v.split()[-1:] == ["3"] else "cut/other") for v in [r["probe"].get("overlong_footer") for r in rows]))
print("bad align:", collections.Counter(str(r["probe"].get("bad_align")) for r in rows), "| span too big:", collections.Counter(str(r["probe"].get("span_too_big")) for r in rows))
print("groups on html:", collections.Counter(str(r["probe"].get("groups_on_html")) for r in rows))
# description versions
vers = collections.defaultdict(list)
for r in rows:
    if r.get("desc_hash"): vers[r["desc_hash"]].append(r)
print("\n== by description version (ordered by first run)")
for h, rs in sorted(vers.items(), key=lambda kv: min(x["first_ts"] for x in kv[1])):
    f = rs[0]["desc_flags"]; k = len(rs)
    col = sum(all(x["probe"].get(c) is True for c in ("col_desc_red3", "col_negative", "col_float_green2", "col_float_red3", "col_stacked")) for x in rs)
    print(f"  {h} {min(x['first_ts'] for x in rs)[:10]} words={rs[0]['desc_words']:4d} runs={k:2d} near(<=2)={sum(x['nfail']<=2 for x in rs):2d} colour_all={col:2d} html_after_thead={sum(x['probe'].get('html_place')=='after thead' for x in rs):2d} raise_overlong={sum(str(x['probe'].get('overlong_footer')).startswith('ERR') for x in rs):2d} flags={f}")
print("\n== effort vs outcome (median)")
import statistics as st
for label, sub in [("near (<=2 fails)", lambda r: r["nfail"] <= 2), ("far (>2)", lambda r: r["nfail"] > 2), ("colour all right", lambda r: all(r["probe"].get(c) is True for c in ("col_desc_red3", "col_negative", "col_float_green2", "col_float_red3", "col_stacked"))), ("own tests", lambda r: r["own_tests"]), ("no own tests", lambda r: not r["own_tests"])]:
    s = [r for r in rows if sub(r)]
    med = lambda k: st.median([r[k] for r in s if r.get(k) is not None]) if any(r.get(k) is not None for r in s) else None
    print(f"  {label:18s} n={len(s):2d} added_lines={med('added_lines')} tokens={med('tokens')} requests={med('requests')} minutes={med('minutes')} nfail_median={st.median([r['nfail'] for r in s]) if s else None}")
