"""Run tabulate without footer/headergroups over many inputs; print a JSON map of results."""
import itertools, json, sys, inspect
from tabulate import tabulate, tabulate_formats, SEPARATING_LINE
explicit = len(sys.argv) > 2 and sys.argv[2] == "explicit"
red = "\x1b[31m{}\x1b[0m".format
DATA = {
    "plain": [["apples", 3, 1.5], ["pears", 12, 20.25]],
    "ragged_short_first": [[1], [2, 3]],
    "ragged_long_first": [[1, 2, 3], [4]],
    "ragged_text": [["a"], ["b", "long text here"], ["c", "x", "yy"]],
    "empty_row": [[], [1, 2]],
    "sepline": [["a", 1], SEPARATING_LINE, ["b", 2]],
    "none_vals": [["a", None], [None, 2.5]],
    "ansi": [[red("x"), red(12)], ["y", 3]],
    "bytes": [[b"ab", 1], [b"cd", 2]],
    "multiline": [["a\nb", 1], ["c", "2\n3"]],
    "dicts": [{"a": 1, "b": 2}, {"a": 3, "c": 4}],
    "empty": [],
}
HEADERS = {"none": (), "short": ["h1"], "equal": ["h1", "h2"], "long": ["h1", "h2", "h3", "h4"], "keys": "keys", "firstrow": "firstrow"}
EXTRA = {
    "default": {},
    "showindex": {"showindex": True},
    "maxcol3": {"maxcolwidths": 3},
    "maxcol_list": {"maxcolwidths": [None, 4]},
    "maxhead2": {"maxheadercolwidths": 2},
    "missing": {"missingval": "?"},
    "colalign": {"colalign": ("right", "left")},
    "fmt": {"floatfmt": ".1f", "intfmt": ","},
    "noparse": {"disable_numparse": True},
}
out = {}
fmts = tabulate_formats
for (dn, data), (hn, headers), (en, extra), fmt in itertools.product(DATA.items(), HEADERS.items(), EXTRA.items(), fmts):
    kw = dict(extra)
    if explicit:
        kw.update(footer=None, headergroups=None)
    try:
        r = ["ok", tabulate(data, headers=headers, tablefmt=fmt, **kw)]
    except Exception as e:
        r = ["exc", type(e).__name__]
    out[f"{dn}|{hn}|{en}|{fmt}"] = r
json.dump(out, open(sys.argv[1], "w"))
print(len(out), "cases")
