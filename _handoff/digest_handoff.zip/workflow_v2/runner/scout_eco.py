"""Task scout that needs no GitHub token: uses the public ecosyste.ms mirror of GitHub data.

    python3 scout_eco.py --pages 10 --out eco_out      # ~1000 packages per registry

Phase 1: library repos from package registries (pypi, npm, Go, crates, Maven), most-depended-on
first, filtered to 500-20000 stars, permissive licence, pushed in the last 6 months, not archived.
Phase 2: open issues of each repo, filtered and scored with the same rules as scout.py
(feature-like, not layout/perf/docs/bug, at most MAX_COMMENTS comments, no open PR whose title
cites the issue number). ecosyste.ms has no issue bodies or reactions, so comments stand in for
popularity, and PR links are only checked by title here: re-check the top hits with the PR-refs
grep (lesson 85) before sizing them.
"""
import argparse
import concurrent.futures as cf
import datetime as dt
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request

from scout import AVOID, FEATURE_LABEL, FEATURE_TITLE, SPEC_WORDS

PKG = "https://packages.ecosyste.ms/api/v1/registries/{reg}/packages?sort=dependent_repos_count&order=desc&per_page=100&page={page}"
ISSUES = "https://issues.ecosyste.ms/api/v1/hosts/GitHub/repositories/{repo}/issues?state=open&per_page=100&page={page}"
REGISTRIES = {"pypi.org": "Python", "npmjs.org": "JavaScript TypeScript", "proxy.golang.org": "Go",
              "crates.io": "Rust", "repo1.maven.org": "Java Kotlin"}
LICENCES = {"mit", "bsd-2-clause", "bsd-3-clause", "apache-2.0", "isc", "0bsd"}
MAX_COMMENTS = 15
BIG_ORGS = re.compile(r"^(googleapis|google|golang|aws|azure|microsoft|kubernetes|kubernetes-sigs|hashicorp|"
                      r"prometheus|grpc|open-telemetry|apache|facebook|meta|vercel|getsentry|elastic|docker)/", re.I)
NOISE = re.compile(r"\b(cloud|aws|azure|gcp|bigquery|s3|kubernetes|k8s|docker|plugin|ide|lsp|vscode|editor|"
                   r"file ?system|fs|watch|event|metric|tracing|telemetry|auth|oauth|token|password|encrypt\w*|"
                   r"install|build|release|packag\w*|benchmark|test(ing|s)?|cli|command|flag|config|env)\b", re.I)


def get(url):
    for attempt in range(4):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "task-scout (research)"})
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.load(r)
        except Exception as exc:
            if attempt == 3 or "404" in str(exc):
                return None
            time.sleep(2 ** (attempt + 1))


def repos_from_registry(reg, langs, pages, since):
    out = {}
    for page in range(1, pages + 1):
        data = get(PKG.format(reg=reg, page=page)) or []
        for p in data:
            rm = p.get("repo_metadata") or {}
            url = (p.get("repository_url") or "").lower()
            if not url.startswith("https://github.com/") or rm.get("archived") or rm.get("fork"):
                continue
            stars, lic = rm.get("stargazers_count") or 0, (rm.get("license") or "").lower()
            if not (500 <= stars <= 20000) or lic not in LICENCES or (rm.get("pushed_at") or "") < since:
                continue
            if rm.get("language") not in langs.split() or BIG_ORGS.search(rm.get("full_name", "")):
                continue
            out[rm["full_name"]] = {"repo": rm["full_name"], "stars": stars, "licence": lic,
                                    "lang": rm.get("language"), "pushed": rm["pushed_at"][:10]}
        if len(data) < 100:
            break
    return out


def judge(issue, prs_titles, skip, repo, now):
    labels = " ".join(l if isinstance(l, str) else l.get("name", "") for l in issue.get("labels") or [])
    title = issue["title"] or ""
    if f'{repo}#{issue["number"]}'.lower() in skip:
        return None
    if not (FEATURE_LABEL.search(labels) or FEATURE_TITLE.search(title)):
        return None
    if re.search(r"\bbug\b|question|wontfix|duplicate|invalid|stale", labels, re.I) or AVOID.search(title) or AVOID.search(labels) or NOISE.search(title):
        return None
    if issue["comments_count"] > MAX_COMMENTS:
        return None
    if any(re.search(rf"#{issue['number']}\b", t) for t in prs_titles):
        return None
    score, why = 0, []
    spec = {m.group(0).lower() for m in SPEC_WORDS.finditer(title)}
    if spec:
        score += 3 * min(len(spec), 3)
        why.append("spec:" + ",".join(sorted(spec)))
    if re.search(r"help wanted|good first|accepted|approved|enhancement|feature", labels, re.I):
        score += 2
        why.append("label:" + labels[:40])
    age = (now - dt.datetime.fromisoformat(issue["created_at"].replace("Z", "+00:00"))).days
    if age > 180:
        score += 2
        why.append(f"{age // 30}mo")
    if 1 <= issue["comments_count"] <= 8:
        score += 1
    return score, why


def scan_repo(meta, skip, now):
    repo = meta["repo"]
    items = []
    for page in range(1, 4):
        data = get(ISSUES.format(repo=urllib.parse.quote(repo, safe=""), page=page)) or []
        items += data
        if len(data) < 100:
            break
    prs = [i["title"] or "" for i in items if i.get("pull_request")]
    rows = []
    for issue in items:
        if issue.get("pull_request") or issue.get("state") != "open":
            continue
        v = judge(issue, prs, skip, repo, now)
        if v:
            rows.append(dict(meta, score=v[0], issue=issue["number"], title=issue["title"],
                             comments=issue["comments_count"], url=issue["html_url"], why="; ".join(v[1])))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pages", type=int, default=10)
    ap.add_argument("--registries", nargs="+", default=list(REGISTRIES))
    ap.add_argument("--out", default="eco_out")
    ap.add_argument("--top", type=int, default=60)
    a = ap.parse_args()
    now = dt.datetime.now(dt.timezone.utc)
    since = (now - dt.timedelta(days=183)).date().isoformat()
    skip_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "skip_list.txt")
    skip = {l.split()[0].lower() for l in open(skip_file) if l.strip() and not l.startswith(";")}
    repos = {}
    for reg in a.registries:
        found = repos_from_registry(reg, REGISTRIES[reg], a.pages, since)
        print(f"{reg}: {len(found)} repos", file=sys.stderr)
        repos.update(found)
    repos = {k: v for k, v in repos.items() if k.lower() not in skip}
    print(f"{len(repos)} repos to scan", file=sys.stderr)
    rows = []
    with cf.ThreadPoolExecutor(8) as ex:
        for i, r in enumerate(ex.map(lambda m: scan_repo(m, skip, now), repos.values()), 1):
            rows += r
            if i % 50 == 0:
                print(f"  {i}/{len(repos)} scanned, {len(rows)} candidates", file=sys.stderr)
    rows.sort(key=lambda r: (-r["score"], -r["stars"]))
    json.dump(rows, open(a.out + ".json", "w"), indent=0)
    per, shown = {}, []
    for r in rows:
        if per.get(r["repo"], 0) < 2:
            per[r["repo"]] = per.get(r["repo"], 0) + 1
            shown.append(r)
    with open(a.out + ".md", "w") as f:
        f.write(f"# Scout (ecosyste.ms): {len(rows)} issues passed, {len(repos)} repos scanned\n\n")
        f.write("| # | score | repo | lang | stars | issue | comments | why |\n|---|---|---|---|---|---|---|---|\n")
        for i, r in enumerate(shown[:a.top], 1):
            f.write(f'| {i} | {r["score"]} | {r["repo"]} | {r["lang"]} | {r["stars"]} | [#{r["issue"]} '
                    f'{r["title"].replace("|", "/")[:70]}]({r["url"]}) | {r["comments"]} | {r["why"]} |\n')
    print(f"wrote {a.out}.md ({len(rows)} candidates)", file=sys.stderr)


if __name__ == "__main__":
    main()
