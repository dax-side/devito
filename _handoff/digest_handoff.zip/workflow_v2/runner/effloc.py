import re, sys, subprocess


def effective(patch_text):
    per, total = {}, 0
    cur = None
    in_doc = False
    for line in patch_text.splitlines():
        if line.startswith('+++ '):
            cur = line[6:]
            in_doc = False
            continue
        if line.startswith('@@'):
            in_doc = False
            continue
        if not line.startswith(('+', ' ')) or line.startswith('+++'):
            continue
        body = line[1:].strip()
        added = line.startswith('+')
        quotes = body.count('"""') + body.count("'''")
        if in_doc:
            if quotes % 2 == 1:
                in_doc = False
            continue
        if body.startswith(('"""', "'''", 'r"""')):
            if quotes == 1:
                in_doc = True
            continue
        if not added:
            continue
        if not body or body.startswith('#'):
            continue
        if re.match(r'^(from|import)\s', body) or re.fullmatch(r'[\)\]\}\(\[\{,:\s]*', body):
            continue
        if re.match(r'^[A-Za-z_][\w, ]*\)?$', body) and body.endswith(','):
            continue
        per[cur] = per.get(cur, 0) + 1
        total += 1
    return total, per


if __name__ == '__main__':
    t = open(sys.argv[1]).read() if len(sys.argv) > 1 else sys.stdin.read()
    total, per = effective(t)
    print(total, per)
