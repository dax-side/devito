"""Refactor scout: reads the code of Python library repos (no issues, so it finds unfiled gaps).

    python3 scout_refactor.py --repos eco_full.json --max 150 --out refactor_out

Repos come from scout_eco.py's JSON (Python ones only). Each is shallow-cloned and scanned with
`ast` for refactors that would create a new public shape (so hidden tests can fail on the clean
repo) and are big enough to clear 200 effective lines:

  global_state   module-level mutable registries/caches/config changed through `global` or
                 module-level dict/list writes -> "make it an instance (Registry/Context) so two
                 can coexist"
  god_function   functions over 120 lines -> "split into a pluggable pipeline/strategy API"
  god_module     modules over 1500 lines -> "split into a package with a stable public surface"
  if_chain       long if/elif chains dispatching on a type or string (>= 8 branches)
                 -> "replace with a registry users can extend"
  duplicate      function bodies duplicated across files (same normalised AST)
                 -> "extract a shared base/helper"

Scores favour repos with several signals and mid-size codebases. A human then picks one, checks
the five questions, and sizes a lean refactor; nothing here proves 200 lines.
"""
import argparse
import ast
import collections
import hashlib
import json
import os
import subprocess
import sys
import tempfile

SKIP_DIRS = {"tests", "test", "testing", "docs", "doc", "examples", "benchmarks", "scripts", ".git",
             "build", "dist", "vendor", "_vendor", "third_party"}


def py_files(root):
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS and not x.startswith(".")]
        for f in files:
            if f.endswith(".py") and not f.startswith("test_"):
                yield os.path.join(d, f)


def norm_hash(node):
    dump = ast.dump(node, annotate_fields=False, include_attributes=False)
    return hashlib.md5(dump.encode()).hexdigest()


def scan(root):
    sig = collections.defaultdict(list)
    bodies = collections.defaultdict(list)
    total = 0
    for path in py_files(root):
        rel = os.path.relpath(path, root)
        try:
            src = open(path, encoding="utf-8").read()
            tree = ast.parse(src)
        except Exception:
            continue
        lines = src.count("\n")
        total += lines
        if lines > 1500:
            sig["god_module"].append(f"{rel} ({lines} lines)")
        module_mutables = set()
        for node in tree.body:
            if isinstance(node, (ast.Assign, ast.AnnAssign)):
                value = node.value
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                if isinstance(value, (ast.Dict, ast.List, ast.Set)) or (
                        isinstance(value, ast.Call) and getattr(value.func, "id", "") in ("dict", "list", "set", "defaultdict", "OrderedDict")):
                    module_mutables |= {t.id for t in targets if isinstance(t, ast.Name)}
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                length = (node.end_lineno or node.lineno) - node.lineno
                if length > 120:
                    sig["god_function"].append(f"{rel}:{node.name} ({length} lines)")
                if length >= 8 and not node.name.startswith("test"):
                    bodies[norm_hash(ast.Module(body=node.body, type_ignores=[]))].append(f"{rel}:{node.name}")
                globals_used = [n for n in ast.walk(node) if isinstance(n, ast.Global)]
                writes = [n for n in ast.walk(node) if isinstance(n, ast.Subscript) and isinstance(n.ctx, ast.Store)
                          and isinstance(n.value, ast.Name) and n.value.id in module_mutables]
                if globals_used or writes:
                    names = {g for n in globals_used for g in n.names} | {w.value.id for w in writes}
                    sig["global_state"].append(f"{rel}:{node.name} -> {','.join(sorted(names))}")
            if isinstance(node, ast.If):
                branches, cur = 1, node
                while len(cur.orelse) == 1 and isinstance(cur.orelse[0], ast.If):
                    branches += 1
                    cur = cur.orelse[0]
                if branches >= 8:
                    sig["if_chain"].append(f"{rel}:{node.lineno} ({branches} branches)")
    for h, where in bodies.items():
        if len({w.split(':')[0] for w in where}) > 1:
            sig["duplicate"].append(" = ".join(where[:3]))
    return sig, total


def score(sig, total):
    weights = {"global_state": 3, "if_chain": 3, "duplicate": 2, "god_function": 2, "god_module": 1}
    s = sum(min(len(v), 4) * weights[k] for k, v in sig.items())
    if 3000 <= total <= 40000:
        s += 4
    return s + 2 * len([k for k in sig if sig[k]])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repos", required=True, help="scout_eco.py JSON output")
    ap.add_argument("--max", type=int, default=150)
    ap.add_argument("--out", default="refactor_out")
    a = ap.parse_args()
    here = os.path.dirname(os.path.abspath(__file__))
    skip = {l.split()[0].lower() for l in open(os.path.join(here, "skip_list.txt")) if l.strip() and not l.startswith(";")}
    seen, repos = set(), []
    for r in json.load(open(a.repos)):
        if r["lang"] == "Python" and r["repo"] not in seen and r["repo"].lower() not in skip:
            seen.add(r["repo"])
            repos.append(r)
    repos = repos[:a.max]
    rows = []
    with tempfile.TemporaryDirectory() as tmp:
        for i, r in enumerate(repos, 1):
            dest = os.path.join(tmp, r["repo"].replace("/", "__"))
            ok = subprocess.run(["git", "clone", "-q", "--depth", "1", f"https://github.com/{r['repo']}", dest],
                                capture_output=True, timeout=300).returncode == 0
            if not ok:
                continue
            sig, total = scan(dest)
            subprocess.run(["rm", "-rf", dest])
            rows.append({"repo": r["repo"], "stars": r["stars"], "lines": total, "score": score(sig, total),
                         "signals": {k: v[:5] for k, v in sig.items() if v}})
            print(f"[{i}/{len(repos)}] {r['repo']} score={rows[-1]['score']}", file=sys.stderr)
    rows.sort(key=lambda x: -x["score"])
    json.dump(rows, open(a.out + ".json", "w"), indent=1)
    with open(a.out + ".md", "w") as f:
        f.write(f"# Refactor scout: {len(rows)} Python repos\n\n")
        for r in rows[:40]:
            f.write(f"## {r['repo']} ({r['stars']} stars, {r['lines']} lines, score {r['score']})\n")
            for k, v in r["signals"].items():
                f.write(f"- **{k}**: " + "; ".join(v[:3]) + "\n")
            f.write("\n")
    print(f"wrote {a.out}.md", file=sys.stderr)


if __name__ == "__main__":
    main()
