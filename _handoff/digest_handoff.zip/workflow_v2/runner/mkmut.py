"""Build mutant patches from a spec, without touching the tree.

usage: mkmut.py SPEC.py TREE OUTDIR

SPEC.py defines MUTANTS = {name: (relpath, old, new)}. TREE is a checkout with the
solution applied. Each `old` must occur exactly once in TREE/relpath. Each mutant is
written to OUTDIR/<name>.patch and applies on top of the solution with `git apply`.
Name mutants after the promise they break, e.g. M3_matrix_clears_self_not_row.
"""
import difflib, os, runpy, sys

spec, tree, outdir = sys.argv[1:4]
os.makedirs(outdir, exist_ok=True)
ok = True
for name, (rel, old, new) in runpy.run_path(spec)['MUTANTS'].items():
    src = open(os.path.join(tree, rel)).read()
    n = src.count(old)
    if n != 1:
        print(f'{name}: anchor found {n} times in {rel}; make it unique')
        ok = False
        continue
    diff = difflib.unified_diff(src.splitlines(True), src.replace(old, new).splitlines(True),
                                f'a/{rel}', f'b/{rel}')
    open(os.path.join(outdir, f'{name}.patch'), 'w').write(f'diff --git a/{rel} b/{rel}\n' + ''.join(diff))
    print(f'{name}: written')
sys.exit(0 if ok else 1)
