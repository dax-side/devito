"""Conformance-gap scout: finds spec features a library knowingly skips in its official test suite.

    python3 scout_conformance.py --repos eco_full.json --langs Go Java TypeScript JavaScript Rust --out conf_out

Libraries that implement a spec often vendor its official test suite and keep a skip list of cases
they do not pass yet (fastjsonschema: "TODO: new stuff, not implemented yet"). Those are gaps the
maintainers know about but rarely file as issues, which makes them less likely to be in other
submissions. For each repo this shallow-clones the code, finds test files that mention a known
suite, and collects skip/xfail/TODO/unsupported lines near the suite references.
"""
import argparse
import json
import os
import re
import subprocess
import sys
import tempfile

SUITES = {
    "JSON-Schema-Test-Suite": r"JSON-Schema-Test-Suite|json-schema-test-suite|draft2019|draft2020|draft-?7",
    "yaml-test-suite": r"yaml-test-suite|yaml_test_suite",
    "toml-test": r"toml-test|toml_test",
    "CommonMark spec": r"commonmark|spec\.txt|CommonMark",
    "GFM spec": r"gfm|github flavored",
    "WPT URL": r"urltestdata|url-setters|web-platform-tests",
    "JSONPath CTS": r"jsonpath-compliance|cts\.json|rfc ?9535",
    "uritemplate-test": r"uritemplate-test|spec-examples\.json",
    "JMESPath compliance": r"jmespath.*compliance|compliance/.*\.json",
    "Unicode/CLDR": r"cldr|ucd|unicode-test",
    "msgpack/cbor vectors": r"appendix_a|cbor.*vectors|msgpack-test",
    "RFC test vectors": r"test.?vectors|rfc\d{4}",
    "SQL logic tests": r"sqllogictest|slt",
    "HTML5 tests": r"html5lib-tests|tree-construction",
    "XPath/XSLT tests": r"qt3tests|xslt30-test",
    "ECMAScript test262": r"test262",
}
SKIP = re.compile(r"\b(skip|skipped|xfail|todo|fixme|not (yet )?(implemented|supported)|unsupported|pending|ignore[d]?|known.?fail|failing)\b", re.I)
TEST_PATH = re.compile(r"(^|/)(tests?|spec|__tests__|testdata|src/test)(/|$)|_test\.go$|\.test\.[jt]s$|Test\.java$|tests?\.rs$", re.I)
EXTS = (".go", ".java", ".ts", ".js", ".mjs", ".rs", ".kt", ".py", ".json", ".yaml", ".yml", ".toml", ".txt", ".cfg")


def scan(root):
    found = {}
    for d, dirs, files in os.walk(root):
        dirs[:] = [x for x in dirs if not x.startswith(".") and x not in ("node_modules", "target", "vendor")]
        rel_dir = os.path.relpath(d, root)
        for f in files:
            rel = os.path.normpath(os.path.join(rel_dir, f))
            if not f.endswith(EXTS) or not TEST_PATH.search(rel):
                continue
            try:
                text = open(os.path.join(d, f), encoding="utf-8", errors="ignore").read()
            except Exception:
                continue
            if len(text) > 400_000:
                continue
            for suite, pat in SUITES.items():
                if not re.search(pat, text, re.I):
                    continue
                lines = text.splitlines()
                hits = [l.strip()[:140] for l in lines if SKIP.search(l) and len(l.strip()) > 3]
                if hits:
                    found.setdefault(suite, []).append({"file": rel, "skips": len(hits), "sample": hits[:8]})
    return found


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repos", required=True)
    ap.add_argument("--langs", nargs="+", default=["Go", "Java", "TypeScript", "JavaScript", "Rust"])
    ap.add_argument("--max", type=int, default=300)
    ap.add_argument("--out", default="conf_out")
    a = ap.parse_args()
    here = os.path.dirname(os.path.abspath(__file__))
    skip = {l.split()[0].lower() for l in open(os.path.join(here, "skip_list.txt")) if l.strip() and not l.startswith(";")}
    seen, repos = set(), []
    for r in json.load(open(a.repos)):
        if r["lang"] in a.langs and r["repo"] not in seen and r["repo"].lower() not in skip:
            seen.add(r["repo"])
            repos.append(r)
    repos = repos[:a.max]
    rows = []
    with tempfile.TemporaryDirectory() as tmp:
        for i, r in enumerate(repos, 1):
            dest = os.path.join(tmp, "repo")
            ok = subprocess.run(["git", "clone", "-q", "--depth", "1", "--filter=blob:limit=2m",
                                 f"https://github.com/{r['repo']}", dest], capture_output=True, timeout=300).returncode == 0
            if ok:
                found = scan(dest)
                if found:
                    total = sum(x["skips"] for v in found.values() for x in v)
                    rows.append({"repo": r["repo"], "lang": r["lang"], "stars": r["stars"], "skips": total, "suites": found})
                    print(f"[{i}/{len(repos)}] {r['repo']}: {list(found)} ({total} skip lines)", file=sys.stderr)
            subprocess.run(["rm", "-rf", dest])
    rows.sort(key=lambda x: -x["skips"])
    json.dump(rows, open(a.out + ".json", "w"), indent=1)
    with open(a.out + ".md", "w") as f:
        f.write(f"# Conformance gaps: {len(rows)} repos with skipped spec-suite cases\n\n")
        for r in rows:
            f.write(f"## {r['repo']} ({r['lang']}, {r['stars']} stars, {r['skips']} skip lines)\n")
            for suite, entries in r["suites"].items():
                for e in entries[:2]:
                    f.write(f"- {suite} in `{e['file']}` ({e['skips']}): " + " / ".join(e["sample"][:4]).replace("|", "/") + "\n")
            f.write("\n")
    print(f"wrote {a.out}.md ({len(rows)} repos)", file=sys.stderr)


if __name__ == "__main__":
    main()
