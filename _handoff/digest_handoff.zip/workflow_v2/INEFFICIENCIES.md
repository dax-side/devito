# Inefficiencies on max_stable_dt, and the fix for each

Each row: what happened, what it cost, and the fix. "In place" means the fix is already in RUN.md, lessons.md or coverage_precheck.md.

## 1. Task design (the biggest costs)

| What happened | Cost | Fix |
|---|---|---|
| Started at full difficulty with a core that no finite search could guarantee (continuous wavenumbers) | 0/12 rollouts, 4 SQ fails, about 2 days before the deep cut | Scout for an easy, bounded, exact core first; add difficulty back one group at a time (lesson 27, RUN.md 1-2). In place |
| Sentinels (`0.0`, `inf`) promised with no range | FP round 1 failed 3 of 4 passes | Every sentinel gets a tested window, "may" outside it (lesson 30, RUN.md 4). In place |
| Reference stricter than the prompt (gridless fields refused) | a solo FP judge flag, then a solution change | List every `raise`; each is stated and tested, or loosened to match the passers (RUN.md 5). In place |
| Two sentences pulling apart (source levels, field indices) found only by FP | FP round 2 failed; 77 disagreements from 3 rules found afterwards | Sentence-by-sentence sweep before the first FP panel (lesson 32, RUN.md 11). In place |
| Speed never discussed: most failures were timeouts | pass rate held at about 10% | Decide at design time whether speed is part of the task; if it is, say so in the description as behaviour ("returns within seconds on a 40 by 40 grid") before the first rollout. Not yet in place: add to RUN.md 2 |

## 2. Check ordering (repeated reruns)

| What happened | Cost | Fix |
|---|---|---|
| VCA run after TQ and SQ passed; its patch changed the tests | one full TQ rerun | Run VCA before TQ, on the first complete version (the guide calls it most useful early) |
| Description changed in 5 separate rounds in one day (pre-check wording, Auto Review splits, FP "may" sentences, length cut, time-order qualifier) | 5 x (pre-check + TQ + SQ) | Collect every pending description change and apply them in one edit; run the length gate on every edit |
| Test patch changed 5 times in one day (0121348a, 55eb967e, 5e725ca5, 9b54c742, 089e7723) | 5 TQ runs | Run the Opus pre-check with the full pattern list (below) before the first upload, not after each TQ |
| Auto Review's High (a one-sided assertion) found late | a revision round | Pre-check pattern "exact promise pinned by a one-sided assert" existed but the pre-check was not run that round. Never skip the pre-check when tests change |
| Description reached 1087 words; pre-check caps at 1000 | an extra rewrite round | At most 950 words by `gates.py desc` (RUN.md 2). In place |

## 3. Local checks that missed things

| What happened | Cost | Fix |
|---|---|---|
| Pre-check prompt told the checker to mark "may" sentences ok; TQ flagged one as untested | one TQ round | "May" sentences need one test accepting either outcome (coverage_precheck.md). In place |
| Sonnet pre-check: 2 wrong flags; Opus on the same files: 2 real gaps | a round of doubt, then a second run | Opus for the final pre-check round (coverage_precheck.md, calibration.md). In place |
| FP screens built from the last failure, not from the description | each FP round found a new area | Probe file per sentence plus each reference `raise` (lesson 32). In place |
| Rollout replay predicted 20%; platform gave 10% | false confidence | Replay counts only past passers; also count new tests and the time cap. Treat a replay as an upper bound |
| Quick platform pre-checks misread numbers ("1e-9 below 1e-10", "eight before next" counted from current) | an extra wording round | Write boundaries as examples the tests use (lesson 31). In place |

## 4. Local runtime

| What happened | Cost | Fix |
|---|---|---|
| Full proof (including the 504-test base suite twice, about 6 min) rerun when only tests or wording changed | about 6 min per round | Base parity only when the solution changes; a test-only change needs red state + green x1 + lint (add a TESTS_ONLY switch to prove.sh) |
| Replays, screens and the proof run at once on 4 cores | one replay stuck 11 min and was killed | At most 2 heavy jobs at once; the proof alone |
| Mutants spec targeted removed code after the finite-mode rewrite | proof reruns with skips | Rebuild the mutant spec in the same edit as any core rewrite |

## 5. My own mistakes

| What happened | Cost | Fix |
|---|---|---|
| Said "advisory does not matter", then reversed after the user pushed back | lost time and trust | Decide from evidence once: close cheap advisories before Auto Review, cap at 3 rounds |
| Said a description change "resets everything" when only pre-check, TQ and SQ were being run | wrong cost reasoning, a bad recommendation | Ask which checks are actually being run before estimating the cost of a change |
| Wrong checksum in a file caption; a regex that broke blank lines (caught before delivery); unzipped over an old run folder | small confusion, rework | Print checksums from the tool output only; insert code at exact anchors, never by regex over the whole file; always unzip into a new folder |
| Long explanations when the user wanted a decision | the user's time and patience | Lead with the decision and the next step; details after |
| No single place holding the current three checksums | risk of uploading a stale file | Keep MANIFEST.txt in the delivery folder, rewritten on every change |

## Order of work for the next task (short form)

1. Five questions (CLAUDE.md) and a budget; easy, bounded, exact core; at most 385 words.
2. Every sentinel windowed; every `raise` stated and tested.
3. VCA and the Opus pre-check (full pattern list) before the first upload; fix everything cheap in one edit.
4. Proof, then upload once: pre-check, TQ, SQ.
5. Rollouts. On the first pass: sentence-by-sentence sweep on each passer, fix every disagreement in one edit.
6. DQ (fix every finding; no contesting), FP, Auto Review.

## tabulate (dropped after 50 versions, 116 agent runs, about a week)

| What happened | Cost | Fix |
|---|---|---|
| Picked a task with about 25 behaviours (two features x 36 formats x value kinds) to clear the 200-line floor | Every gate kept finding a new corner; TQ, DQ, FP and pass rate pulled against each other | Five questions at selection; about 10 behaviours that each need real code (CLAUDE.md top section) |
| Used the platform gates as the debugger, one finding per round, no budget | 50 versions | Budget agreed on day one; continue / cut / drop call at each budget point (lesson 84). G13 existed and was not applied: a rule without a budget does not bite |
| Grew scope after the scope gate (stacked group levels), later cut again | Several versions of build, test and cut | Grow scope only with features that keep the behaviour count low; never grow a layout feature |
| Tests compared whole tables; every cosmetic choice became a hidden requirement | Text grew past DQ's length gate and read as AI; 0 clean passes in 73 runs | Permissive tests: exact only at the value level (lesson 69) |
| Hidden tests rewritten after the runs were collected; descriptions changed 9 times | Stated behaviour failed 4%, unstated 54%: most failures were our text, not the agents | Freeze description and tests together before collecting runs |
| The only colour example was a case base already got right | 0 of 8 fresh runs got colour right | The example must be the trap: a case the naive approach or base helper gets wrong (lesson 78) |
| FP panel opened before sweeping the passer | 2 FP rounds | 10 pre-FP targets first (postmortem section 4) |
| Same SQ solution re-run hoping for a pass | 3 runs, 3 different mediums | A medium on a PASS is not a blocker (lesson 74) |
