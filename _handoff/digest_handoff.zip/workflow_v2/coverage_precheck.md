# Coverage pre-check (run before TQ)

Predicts TQ coverage suggestions locally. Run it in a fresh agent or session that has seen nothing but the two files below, so it reads them the way TQ does.

## Inputs
- description.txt
- the new test file (not the solution)

## Prompt (paste as is, then attach or paste the two files)

```text
You are reviewing a task description and its hidden tests. You have not seen any solution.

Split the description into atomic requirements: one row per promise. A sentence that joins two promises gives two rows; a list of cases ("in one, two and three dimensions") gives one row per listed item.

For each row, answer:
1. Quote: the exact words from the description.
2. Tests: which test functions and parameter values exercise it. "None" if nothing does.
3. Laziest wrong implementation: the simplest implementation that violates the promise but still passes every test. Look for:
   - a claim stricter than the assertion (message content, error timing, "exactly", "every", "unchanged"), so a wrong solution passes the weaker assertion;
   - an open rule ("any", "otherwise", "anything else", "every step") tested with one or a few values, so a solution hardcoded to those values passes;
   - a constant the tests never vary (the number of steps, the grid size, the dimension), so a solution hardcoded to it passes;
   - a boundary tested from one side only.
   - a property checked through one value source only (a non-finite value via a Function but never via a Constant or number);
   - a container or list form tested with a single element only (a one-element tuple, one equation);
   - an exact promise pinned by a one-sided assertion (>=, <), so a result that is too large or too small passes;
   - a promised range sampled only at or near its ends, with no interior value of a different magnitude.
   - a promised range reached through one mechanism only (one kind of scheme, one route), so a solution special-cased to that mechanism passes; sample the exact ends, an interior value, and at least two mechanisms;
   - an open set ("any form", "any Function", "whatever symbol") sampled with fewer than two structurally different members;
   - a permission ("may be X or Y", "may be ignored or refused") with no test at all: it still needs one test that passes on either allowed outcome and fails on anything else (for example, `try: r = f() except ValueError: return; assert r == expected`). Never mark a "may" sentence ok just because it permits two behaviours.
   Write "none" only if you cannot construct one. A wrong implementation must be one a real developer could plausibly write; do not count constructions that would need deliberate sabotage keyed to the exact test values.
4. Kind: "not discriminating" (claim stricter than the assertion), "single point" (open rule sampled narrowly), or "ok".
5. Cheapest fix: prefer adding parameter values to an existing test, then tightening an assertion, then narrowing the sentence. Never suggest a new test function when a parameter value would do.

Output a table with those five columns, then a count: rows ok, rows not discriminating, rows single point.
Do not comment on style, fairness or the solution. Only coverage.
```

## Reading the result
- Every "ok" row is safe.
- Each other row is a likely TQ suggestion. Fix it before uploading, using the cheapest fix the checker proposes, within CLAUDE.md rules:
  - Never state error-message content. Delete the claim instead of asserting on text.
  - For error timing, build the object outside pytest.raises and assert something on it, with only the failing call inside.
  - A widened parameter list must still fail on base (rerun the red state).
- After fixing, run the pre-check again in a fresh agent on the new files. At most 3 rounds, then stop: the checker splits the description differently each run and always finds a finer cell (moving points task: 15, 4, 1, 8, 2, 7, 2, 1 flags over 8 rounds; it bounced, it did not converge). Whatever is left after round 3 is probed once on the reference and logged as advisory.
- Peripheral gaps (extra shapes, routes, edge configurations): narrow the sentence. Core gaps (a plausible bug in the hard part, such as reading the wrong time row): add a parameter value. A stated refusal cannot be narrowed away; sample it instead.
- Closing a row adds test breadth, not scope: the promise is already in the description. Before accepting any row as advisory, write its cheapest fix as a throwaway probe and run it against the reference solution. If the reference fails, the description promises something the solution does not do. Narrow the sentence, or fix the solution; never leave it. (Round 11: 26 of 28 probe cases passed, but float32 linear injection in 2D/3D was 1 ulp off, while the sentence promised exact values for any moving point. It was narrowed to interpolation.)
- A row may be left advisory only when its probe passes on the reference and adding it would cost more runtime or risk than it is worth.
- Tests frozen for rollouts are not touched. The pre-check is for the stage before TQ, not after.

## Calibration
max_stable_dt (after VCA): every TQ suggestion had one shape, a promise sampled by one mechanism or one point: a tuple with one equation, "time step in any form" with two forms, the accuracy range at 2e-6 and 5e5 only, the range reached only through damping, and a "may" sentence with no test. The pre-check prompt had told the checker to mark "may" sentences ok; TQ flagged one as untested. Fixed above. Use Opus for the final round: on the same files Sonnet flagged two rows wrongly, Opus two real gaps.

On the reference task (derivative boundary mode), v2 had four TQ suggestions: three from an error-message content sentence and one from error timing tested with construction inside pytest.raises. Both kinds are what this checker's step 3 looks for first. v3 and v4, which dropped the message claim and built objects outside pytest.raises, had none.
