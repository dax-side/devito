# One-page summary (v2, plus v3 rules after tabulate)

v3: before any of this, the five questions and a budget (CLAUDE.md top). Most failures on tabulate came from task shape (too many behaviours, layout as output, better-than-base demands), not from the gates. See postmortems/tabulate.md.

What decides acceptance: description, solution and tests must say the same thing. TQ reads tests and description; SQ reads solution and description; Auto Review reads everything; the FP panel probes passing agent runs; humans score description, tests and solution 0-3 and count honest LOC.

How tasks fail, most expensive first:
1. A fix covers only the reported case while the same mechanism leaks through another route.
2. A sentence promises more than the code keeps ("every", "exactly", "whichever", "as today").
3. Scope inflates because tests are added for coverage suggestions.
4. New tests already pass on base.
5. Tests stricter than the prose (message text, internals, timing).
6. Behaviour that is implemented but not stated, or stated but not tested.
7. Numerical edges (signed zero, association order, precision).
8. Prose format (headings, lists, dropped clarifications).
9. Stale patches and capped test output.

The route: repo and capability -> reference solution and behaviour inventory with LOC per group -> description, one sentence per requirement -> tests, one parametrised test per requirement row -> runner GO (red, green x3, parity, lint, LOC, mutants) -> coverage pre-check (coverage_precheck.md) -> route probes for every refusal -> cheap platform checks -> TQ, SQ, DQ and Task Quality on one version -> Scope Gate -> Auto Review -> rollouts graded locally -> FP -> submit.

Rules that end loops: one owner per finding before editing; one requirement per sentence; bulbs are advisory; fix the whole mechanism on every route; retarget an existing test before adding one; narrow the sentence instead of adding tests; when the same thing is touched twice, cut it.

Files: `PROMPT.md` (paste into a session), `coverage_precheck.md` (predicts TQ coverage suggestions), `CLAUDE.md` (rules), `gates.md` (gates), `proof_runner.md` (runner usage), `lessons.md` (what went wrong and why), `calibration.md` (how often each local check predicted the platform), `PLANS_LATER.md` (work queued for after the current task), `runner/` (scripts), `runner/templates_tabulate/` (default-path differential, crash fuzz, probes, run aggregation; adapt per task), `FP_GAP_PROMPT.md`, `postmortems/`.
