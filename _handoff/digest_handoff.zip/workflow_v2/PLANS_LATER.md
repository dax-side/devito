# Plans for later

Start these only after max_stable_dt is done (approved or finally parked). Nothing here touches a task in active rollouts.

## 1. TQ calibration experiment (steps 1 to 3)
Step 0 is done: see calibration.md, "TQ trigger patterns". Remaining steps, on a parked copy of a finished task, never on one in rollouts:
1. Noise: upload one unchanged version to TQ three times and record the suggestions each time. This gives the baseline variation, without which no later result can be read.
2. One change at a time, starting from a version with zero suggestions (two TQ runs each):
   - add one unbounded "any";
   - sample a stated range at 2 points instead of 4;
   - promise an error-message detail;
   - pack three rules into one sentence;
   - list ten refusal cases instead of one per reason (expect no change).
3. For every run, record what the local pre-check predicted beside what TQ said, and compute the hit rate ("pre-check clean means TQ clean X% of the time").
Cost: about 10 to 12 TQ runs (about 3 minutes each); paste only the suggestion lines to keep tokens low.
Output: a short rule list with how often each pattern triggers a suggestion, the noise level, and the number of pre-check rounds worth running.

## 2. One-page run order (RUN.md): DONE
Built as RUN.md with 14 steps, including the FP screen (steps 11 and 12). Original plan:
Seven steps with the exact command and the pass/fail line for each: scout (easy, bounded, finite core), draft small, sq_lint, pre-check (1 to 2 rounds), proof, upload all checks once, 3 agents. The full workflow stays as the reference.

## 3. First real run of sq_lint.py: PARTLY DONE
The unbounded-words part ran on max_stable_dt (5 sentences, all already passed by SQ). The probes ran through runner/fp_screen.py on the reference: two probes were wrong (a 4D grid, which Devito does not allow, and an elastic expression that recursed), fixed in t2/fp_probes.py; the 64x64 and 16^3 random fields exceed 60 s on the reference. Remaining: fix sq_probes.py itself the same way. Original plan:
runner/sq_lint.py and t2/sq_probes.py (max_stable_dt probes: feature pairs and bounds) are written but have not been run. Run them once with the memory and time caps, fix anything the script itself gets wrong, and keep the probe file as the example for the next task.

## 4. Cheaper agents and a rollout predictor
- Pre-check model calibration: rerun one old pre-check input on haiku and on sonnet, compare their rows with the earlier result and with TQ. Keep the cheapest model that finds the same non-ok rows.
- Haiku as a Nova proxy: on the next task, before the first batch, run one haiku simulated solver (opt in with "SIMULATED SOLVERS: yes, 1") and grade it against the hidden tests. Compare its failures with the platform batch. If they overlap, it becomes the cheap rollout predictor (calibration.md's biggest blind spot).
